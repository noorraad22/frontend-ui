/* =========================================================
   العيادة الذكية — واجهة المريض
   script.js
   ملاحظة: جميع البيانات تجريبية وتُحفظ في متصفحك فقط (localStorage)
   ========================================================= */
'use strict';

/* =================== أدوات مساعدة =================== */
const $ = (sel, ctx = document) => ctx.querySelector(sel);
const $$ = (sel, ctx = document) => Array.from(ctx.querySelectorAll(sel));

const store = {
    get(key, fallback) {
        try {
            const v = localStorage.getItem('smartClinic_' + key);
            return v ? JSON.parse(v) : fallback;
        } catch (e) { return fallback; }
    },
    set(key, value) {
        try { localStorage.setItem('smartClinic_' + key, JSON.stringify(value)); } catch (e) { /* تجاهل */ }
    }
};

const pad = n => String(n).padStart(2, '0');
const toISO = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const addDays = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
const todayISO = () => toISO(new Date());
const parseISO = s => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); };

const fmtDate = (iso, opts = { weekday: 'long', day: 'numeric', month: 'long' }) =>
    new Intl.DateTimeFormat('ar-u-nu-latn', opts).format(parseISO(iso));

const fmtTime = t => {
    let [h, m] = t.split(':').map(Number);
    const s = h >= 12 ? 'مساءً' : 'صباحاً';
    h = h % 12 || 12;
    return `${pad(h)}:${pad(m)} ${s}`;
};

const fmtMoney = n => Number(n).toLocaleString('en-US') + ' د.ع';

const relDay = iso => {
    if (iso === todayISO()) return 'اليوم';
    if (iso === toISO(addDays(new Date(), 1))) return 'غداً';
    return fmtDate(iso, { weekday: 'long', day: 'numeric', month: 'short' });
};

const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const hash = str => { let h = 7; for (const ch of String(str)) h = (h * 31 + ch.charCodeAt(0)) >>> 0; return h; };

const apptDateTime = a => {
    const d = parseISO(a.date);
    const [h, m] = a.time.split(':').map(Number);
    d.setHours(h, m, 0, 0);
    return d;
};

const ageOf = birth => {
    if (!birth) return null;
    const b = parseISO(birth), n = new Date();
    let a = n.getFullYear() - b.getFullYear();
    if (n.getMonth() < b.getMonth() || (n.getMonth() === b.getMonth() && n.getDate() < b.getDate())) a--;
    return a;
};

const normalize = s => String(s)
    .replace(/[ً-ْـ]/g, '')
    .replace(/[أإآ]/g, 'ا')
    .replace(/ة/g, 'ه')
    .replace(/ى/g, 'ي')
    .toLowerCase();

const isEmail = v => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
const isPhone = v => /^07\d{9}$/.test(v.replace(/\s/g, ''));

function shake(el) {
    if (!el) return;
    el.classList.remove('shake');
    void el.offsetWidth;
    el.classList.add('shake');
}

function setLoading(btn, on) {
    if (!btn) return;
    btn.classList.toggle('loading', on);
    btn.disabled = on;
}


/* =================== البيانات التجريبية =================== */
const SPECIALTIES = {
    cardiology:    { name: 'أمراض القلب',     desc: 'صحة القلب والشرايين', icon: '♡', color: '#e5484d' },
    dermatology:   { name: 'الأمراض الجلدية',  desc: 'العناية بالبشرة',       icon: '✧', color: '#d9467a' },
    pediatrics:    { name: 'طب الأطفال',       desc: 'صحة الأطفال',           icon: '☼', color: '#f59e0b' },
    neurology:     { name: 'طب الأعصاب',       desc: 'الجهاز العصبي',         icon: '⌘', color: '#7c3aed' },
    family:        { name: 'طب الأسرة',        desc: 'الرعاية الأولية',       icon: '⌂', color: '#12b5a5' },
    dentistry:     { name: 'طب الأسنان',       desc: 'صحة الفم والأسنان',     icon: '◡', color: '#1463ff' },
    ophthalmology: { name: 'طب العيون',        desc: 'صحة البصر',             icon: '◉', color: '#0ea5e9' },
    orthopedics:   { name: 'العظام والمفاصل',  desc: 'الكسور والمفاصل',       icon: '⟂', color: '#64748b' }
};

// days: أيام الدوام (0 = الأحد ... 6 = السبت)
const DOCTORS = [
    {
        id: 1, name: 'د. سارة أحمد', avatar: '👩‍⚕️', specialty: 'cardiology', exp: 12, rating: 4.9, patients: 1800,
        bio: 'استشارية أمراض القلب والأوعية الدموية، متخصصة في تخطيط وإيكو القلب ومتابعة مرضى ضغط الدم.',
        clinics: [
            { name: 'عيادة الكرادة التخصصية', city: 'بغداد', fee: 25000 },
            { name: 'مستشفى الحياة الأهلي', city: 'بغداد', fee: 35000 }
        ],
        days: [6, 0, 1, 2, 3], hours: 'السبت – الأربعاء · 4:00 م – 9:00 م',
        slots: ['16:00', '16:30', '17:00', '17:30', '18:30', '19:00', '20:00', '20:30']
    },
    {
        id: 2, name: 'د. محمد الجبوري', avatar: '👨‍⚕️', specialty: 'pediatrics', exp: 9, rating: 4.8, patients: 2400,
        bio: 'أخصائي طب الأطفال وحديثي الولادة، ويهتم بمتابعة النمو واللقاحات وأمراض الجهاز التنفسي عند الأطفال.',
        clinics: [
            { name: 'عيادة المنصور للأطفال', city: 'بغداد', fee: 20000 },
            { name: 'مجمع اليرموك الطبي', city: 'بغداد', fee: 20000 }
        ],
        days: [6, 0, 1, 2, 3, 4], hours: 'السبت – الخميس · 3:00 م – 8:00 م',
        slots: ['15:00', '15:30', '16:00', '16:30', '17:00', '18:00', '19:00', '19:30']
    },
    {
        id: 3, name: 'د. نور الهدى كريم', avatar: '👩‍⚕️', specialty: 'dermatology', exp: 7, rating: 4.7, patients: 1300,
        bio: 'أخصائية الأمراض الجلدية والتجميل، تعالج حب الشباب والحساسية الجلدية وأمراض الشعر.',
        clinics: [
            { name: 'مركز النخبة للجلدية', city: 'البصرة', fee: 25000 }
        ],
        days: [6, 1, 3], hours: 'السبت، الإثنين، الأربعاء · 5:00 م – 9:00 م',
        slots: ['17:00', '17:30', '18:00', '18:30', '19:30', '20:00']
    },
    {
        id: 4, name: 'د. علي حسن الموسوي', avatar: '👨‍⚕️', specialty: 'neurology', exp: 15, rating: 4.9, patients: 2100,
        bio: 'استشاري الأمراض العصبية، متخصص في الصداع النصفي والصرع واضطرابات الأعصاب الطرفية.',
        clinics: [
            { name: 'مستشفى الكفيل التخصصي', city: 'النجف', fee: 40000 },
            { name: 'عيادة الكوفة الاستشارية', city: 'النجف', fee: 30000 }
        ],
        days: [0, 2, 4], hours: 'الأحد، الثلاثاء، الخميس · 4:00 م – 8:00 م',
        slots: ['16:00', '16:45', '17:30', '18:15', '19:00']
    },
    {
        id: 5, name: 'د. زينب عبد الله', avatar: '👩‍⚕️', specialty: 'family', exp: 6, rating: 4.6, patients: 950,
        bio: 'طبيبة أسرة تقدم الرعاية الأولية والفحوصات الدورية ومتابعة الأمراض المزمنة لجميع أفراد العائلة.',
        clinics: [
            { name: 'عيادة الكرادة التخصصية', city: 'بغداد', fee: 15000 },
            { name: 'مجمع اليرموك الطبي', city: 'بغداد', fee: 15000 }
        ],
        days: [0, 1, 2, 3, 4], hours: 'الأحد – الخميس · 9:00 ص – 1:00 م',
        slots: ['09:00', '09:30', '10:00', '10:30', '11:00', '11:30', '12:00', '12:30']
    },
    {
        id: 6, name: 'د. أحمد السامرائي', avatar: '👨‍⚕️', specialty: 'dentistry', exp: 10, rating: 4.8, patients: 1600,
        bio: 'أخصائي طب وجراحة الفم والأسنان، يقدم علاج العصب والتقويم وزراعة الأسنان.',
        clinics: [
            { name: 'مركز ابتسامة لطب الأسنان', city: 'أربيل', fee: 20000 }
        ],
        days: [6, 0, 1, 2, 3], hours: 'السبت – الأربعاء · 10:00 ص – 6:00 م',
        slots: ['10:00', '11:00', '12:00', '14:00', '15:00', '16:00', '17:00']
    },
    {
        id: 7, name: 'د. مريم الدليمي', avatar: '👩‍⚕️', specialty: 'ophthalmology', exp: 11, rating: 4.7, patients: 1450,
        bio: 'استشارية طب وجراحة العيون، متخصصة في فحص النظر وعلاج الماء الأبيض وأمراض الشبكية.',
        clinics: [
            { name: 'مركز النور للعيون', city: 'بغداد', fee: 30000 },
            { name: 'مجمع الأمل الطبي', city: 'البصرة', fee: 28000 }
        ],
        days: [6, 0, 2, 4], hours: 'السبت، الأحد، الثلاثاء، الخميس · 4:00 م – 8:00 م',
        slots: ['16:00', '16:30', '17:00', '18:00', '18:30', '19:30']
    },
    {
        id: 8, name: 'د. حيدر العبيدي', avatar: '👨‍⚕️', specialty: 'orthopedics', exp: 14, rating: 4.8, patients: 1750,
        bio: 'استشاري جراحة العظام والمفاصل، متخصص في إصابات الملاعب وآلام الظهر والركبة.',
        clinics: [
            { name: 'مستشفى الحياة الأهلي', city: 'بغداد', fee: 35000 },
            { name: 'مستشفى أربيل الدولي', city: 'أربيل', fee: 40000 }
        ],
        days: [6, 1, 3], hours: 'السبت، الإثنين، الأربعاء · 3:00 م – 7:00 م',
        slots: ['15:00', '15:30', '16:00', '17:00', '17:30', '18:30']
    }
];

const CITIES = ['بغداد', 'البصرة', 'أربيل', 'النجف', 'كربلاء', 'الموصل', 'السليمانية', 'ديالى'];
const RELATIONS = ['ابن', 'ابنة', 'أب', 'أم', 'زوج', 'زوجة', 'أخ', 'أخت', 'أخرى'];
const BLOOD = ['غير معروف', 'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
const DAY_NAMES = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];

const STATUS = {
    confirmed: { label: 'مؤكد', cls: 'success' },
    pending:   { label: 'بانتظار التأكيد', cls: 'warning' },
    completed: { label: 'مكتمل', cls: 'primary' },
    cancelled: { label: 'ملغى', cls: 'danger' }
};
const PAY_STATUS = {
    paid:     { label: 'مدفوع', cls: 'success' },
    unpaid:   { label: 'الدفع في العيادة', cls: 'warning' },
    refunded: { label: 'تم الاسترداد', cls: 'muted' }
};
const PAY_METHOD = { cash: 'نقداً في العيادة', card: 'بطاقة مصرفية', wallet: 'محفظة إلكترونية' };

const Q_STATUS = {
    notstarted: { label: 'لم يبدأ بعد', cls: 'muted' },
    waiting:    { label: 'في الانتظار', cls: 'warning' },
    next:       { label: 'دورك التالي', cls: 'primary' },
    in:         { label: 'داخل الاستشارة', cls: 'success' },
    done:       { label: 'اكتملت الاستشارة', cls: 'success' }
};

const DEFAULT_FAMILY = [
    { id: 'f1', name: 'علي', relation: 'ابن', birth: '2016-04-12', gender: 'm', blood: 'O+' },
    { id: 'f2', name: 'فاطمة', relation: 'أم', birth: '1965-09-03', gender: 'f', blood: 'A+' }
];

function seedAppointments() {
    const t = new Date();
    const laterToday = pad(Math.min(t.getHours() + 1, 23)) + ':30';
    return [
        {
            id: 'SC-24817', doctorId: 1, clinicIdx: 0, patientId: 'self', patientName: '',
            date: toISO(t), time: laterToday, fee: 25000, payment: 'cash', paymentStatus: 'unpaid',
            status: 'confirmed', queueNo: 'A-08', notes: ''
        },
        {
            id: 'SC-31092', doctorId: 2, clinicIdx: 0, patientId: 'f1', patientName: 'علي',
            date: toISO(addDays(t, 4)), time: '16:00', fee: 20000, payment: 'card', paymentStatus: 'paid',
            status: 'confirmed', queueNo: 'B-03', notes: ''
        },
        {
            id: 'SC-19455', doctorId: 5, clinicIdx: 0, patientId: 'self', patientName: '',
            date: toISO(addDays(t, -12)), time: '10:00', fee: 15000, payment: 'cash', paymentStatus: 'paid',
            status: 'completed', queueNo: 'E-05', notes: '',
            consult: {
                diagnosis: 'التهاب بسيط في الحلق',
                treatment: 'علاج لمدة 5 أيام مع الإكثار من السوائل الدافئة والراحة',
                followUp: 'مراجعة بعد أسبوعين في حال استمرار الأعراض'
            }
        },
        {
            id: 'SC-17730', doctorId: 3, clinicIdx: 0, patientId: 'f2', patientName: 'فاطمة',
            date: toISO(addDays(t, -25)), time: '17:00', fee: 25000, payment: 'card', paymentStatus: 'refunded',
            status: 'cancelled', queueNo: 'C-02', notes: ''
        }
    ];
}


/* =================== الحالة العامة =================== */
const state = {
    user: store.get('user', null),
    accounts: store.get('accounts', {}),
    family: store.get('family', DEFAULT_FAMILY),
    appointments: store.get('appointments', null) || seedAppointments(),
    filters: { q: '', spec: '', city: '', clinic: '' },
    apptTab: 'upcoming',
    queueAuto: true,
    queueSelected: null,
    queueSims: {},
    pendingAction: null,
    chatStarted: false
};

function save() {
    store.set('user', state.user);
    store.set('accounts', state.accounts);
    store.set('family', state.family);
    store.set('appointments', state.appointments);
}

const getDoctor = id => DOCTORS.find(d => d.id === Number(id));


/* =================== المواعيد المتاحة =================== */
function getSlots(doc, iso) {
    const date = parseISO(iso);
    if (!doc.days.includes(date.getDay())) return null; // يوم عطلة
    const now = new Date();
    const isToday = iso === todayISO();
    const taken = state.appointments
        .filter(a => a.doctorId === doc.id && a.date === iso && a.status !== 'cancelled')
        .map(a => a.time);

    return doc.slots.map(t => {
        const [h, m] = t.split(':').map(Number);
        const past = isToday && (h * 60 + m) <= now.getHours() * 60 + now.getMinutes();
        const booked = hash(doc.id + iso + t) % 4 === 0 || taken.includes(t);
        return { time: t, available: !past && !booked };
    });
}

function nextAvailable(doc) {
    for (let i = 0; i < 21; i++) {
        const iso = toISO(addDays(new Date(), i));
        const slots = getSlots(doc, iso);
        if (slots) {
            const free = slots.filter(s => s.available).map(s => s.time);
            if (free.length) return { date: iso, slots: free };
        }
    }
    return null;
}


/* =================== الإشعارات =================== */
function toast(msg, type = 'success') {
    const icons = { success: '✓', error: '!', info: 'i' };
    const el = document.createElement('div');
    el.className = `toast ${type}`;
    el.innerHTML = `<span class="toast-icon">${icons[type] || 'i'}</span><span>${msg}</span>`;
    $('#toastStack').appendChild(el);
    requestAnimationFrame(() => requestAnimationFrame(() => el.classList.add('show')));
    setTimeout(() => {
        el.classList.remove('show');
        setTimeout(() => el.remove(), 500);
    }, 3200);
}


/* =================== النافذة المنبثقة =================== */
let modalResolver = null;

function openModal(html, size = '') {
    const m = $('#modal');
    $('#modalBody').innerHTML = html;
    m.className = 'modal open ' + size;
    m.setAttribute('aria-hidden', 'false');
    document.body.classList.add('no-scroll');
    $('.modal-dialog', m).scrollTop = 0;
}

function closeModal() {
    const m = $('#modal');
    if (!m.classList.contains('open')) return;
    m.classList.remove('open');
    m.setAttribute('aria-hidden', 'true');
    document.body.classList.remove('no-scroll');
    state.pendingAction = null;
    if (modalResolver) { modalResolver(false); modalResolver = null; }
}

function confirmDialog({ title, text, ok = 'تأكيد', danger = false, icon = '⚠️' }) {
    return new Promise(resolve => {
        openModal(`
            <div class="confirm">
                <div class="confirm-icon ${danger ? 'danger' : ''}">${icon}</div>
                <h3>${title}</h3>
                <p class="muted">${text}</p>
                <div class="confirm-actions">
                    <button class="btn light" data-confirm="no">تراجع</button>
                    <button class="btn ${danger ? 'danger' : 'primary'}" data-confirm="yes">${ok}</button>
                </div>
            </div>`, 'small');
        modalResolver = resolve;
    });
}

function initModal() {
    const modal = $('#modal');
    modal.addEventListener('click', e => {
        if (e.target === modal || e.target.closest('[data-close-modal]')) closeModal();

        const c = e.target.closest('[data-confirm]');
        if (c && modalResolver) {
            const r = modalResolver;
            modalResolver = null;
            closeModal();
            r(c.dataset.confirm === 'yes');
        }

        const tab = e.target.closest('[data-auth-tab]');
        if (tab) switchAuthTab(tab.dataset.authTab);

        const tp = e.target.closest('.toggle-pass');
        if (tp) {
            const input = tp.previousElementSibling;
            input.type = input.type === 'password' ? 'text' : 'password';
            tp.textContent = input.type === 'password' ? '👁' : '🙈';
        }
    });

    $('#modalBody').addEventListener('submit', e => {
        e.preventDefault();
        const f = e.target;
        if (f.id === 'loginForm') handleLogin(f);
        else if (f.id === 'registerForm') handleRegister(f);
        else if (f.id === 'familyForm') handleFamilySave(f);
    });

    // إزالة رسالة الخطأ عند الكتابة
    $('#modalBody').addEventListener('input', e => {
        const g = e.target.closest('.form-group.has-error');
        if (g) setError(e.target, '');
    });
}

function setError(input, msg) {
    const g = input.closest('.form-group');
    if (!g) return;
    g.classList.toggle('has-error', !!msg);
    const e = $('.error-text', g);
    if (e) e.textContent = msg || '';
}


/* =================== التنقل بين الصفحات =================== */
const PAGES = ['home', 'doctors', 'booking', 'appointments', 'queue', 'profile'];
let currentPage = 'home';

const onEnter = {
    home: () => { renderSuggested(); renderAuthCta(); renderHeroCard(); },
    doctors: () => { syncFilterUI(); showSkeleton(); setTimeout(renderDoctors, 420); },
    booking: () => { if (bookingDone) resetBooking(); else renderBooking(); },
    appointments: renderAppointments,
    queue: () => renderQueue(),
    profile: renderProfile
};

function go(page) {
    if (!PAGES.includes(page)) return;
    closeMenu();
    if (page !== currentPage) {
        $$('.page').forEach(p => p.classList.toggle('active', p.id === page));
        currentPage = page;
        $$('.nav-link').forEach(l => l.classList.toggle('active', l.dataset.page === page));
        moveIndicator();
        try { history.replaceState(null, '', '#' + page); } catch (e) { /* تجاهل */ }
    }
    if (onEnter[page]) onEnter[page]();
    window.scrollTo({ top: 0, behavior: 'smooth' });
    observeReveals($('#' + page));
}

function moveIndicator() {
    const active = $('.nav-link.active');
    const ind = $('#navIndicator');
    if (!active || !ind) return;
    ind.style.width = active.offsetWidth + 'px';
    ind.style.transform = `translateX(${active.offsetLeft}px)`;
}

function closeMenu() {
    $('#mainNav').classList.remove('open');
    $('#menuToggle').classList.remove('open');
}


/* =================== الحركات العامة =================== */
const revealObserver = 'IntersectionObserver' in window
    ? new IntersectionObserver(entries => {
        entries.forEach(en => {
            if (!en.isIntersecting) return;
            en.target.classList.add('in');
            $$('[data-count]', en.target).forEach(animateCount);
            revealObserver.unobserve(en.target);
        });
    }, { threshold: 0.12 })
    : null;

function observeReveals(root = document) {
    $$('.reveal:not(.in)', root).forEach(el => {
        if (revealObserver) revealObserver.observe(el);
        else { el.classList.add('in'); $$('[data-count]', el).forEach(animateCount); }
    });
}

function animateCount(el) {
    if (el.dataset.done) return;
    el.dataset.done = '1';
    const target = Number(el.dataset.count);
    const start = performance.now(), dur = 1400;
    const step = now => {
        const p = Math.min((now - start) / dur, 1);
        el.textContent = Math.round(target * (1 - Math.pow(1 - p, 3)));
        if (p < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
}

// تأثير الموجة عند الضغط
document.addEventListener('pointerdown', e => {
    const b = e.target.closest('.btn, .specialty, .slot:not(:disabled), .choice-card');
    if (!b) return;
    const r = b.getBoundingClientRect();
    const size = Math.max(r.width, r.height);
    const s = document.createElement('span');
    s.className = 'ripple';
    s.style.width = s.style.height = size + 'px';
    s.style.left = (e.clientX - r.left - size / 2) + 'px';
    s.style.top = (e.clientY - r.top - size / 2) + 'px';
    b.appendChild(s);
    setTimeout(() => s.remove(), 650);
});


/* =================== الصفحة الرئيسية =================== */
function renderHeroCard() {
    const d = DOCTORS[0];
    const n = nextAvailable(d);
    $('#heroCard').innerHTML = `
        <div class="doctor-avatar">${d.avatar}</div>
        <h3>${d.name}</h3>
        <p>اختصاص ${SPECIALTIES[d.specialty].name}</p>
        <span class="available"><span class="pulse-dot"></span> متاحة</span>
        <hr>
        <div class="next-visit">
            <span>أقرب موعد متاح</span>
            <strong>${n ? relDay(n.date) + ' · ' + fmtTime(n.slots[0]) : 'لا يوجد حالياً'}</strong>
        </div>
        <button class="btn primary block sm" data-book="${d.id}">احجز الآن ←</button>`;
}

function renderSpecialties() {
    $('#specialtyGrid').innerHTML = Object.entries(SPECIALTIES).map(([key, s], i) => {
        const count = DOCTORS.filter(d => d.specialty === key).length;
        return `
        <button class="specialty reveal" style="--c:${s.color}; --d:${i % 4}" data-specialty="${key}">
            <span class="sp-icon">${s.icon}</span>
            <strong>${s.name}</strong>
            <small>${s.desc}</small>
            <span class="sp-count">${count} ${count === 1 ? 'طبيب' : 'أطباء'} ←</span>
        </button>`;
    }).join('');
}

function renderSuggested() {
    const top = [...DOCTORS].sort((a, b) => b.rating - a.rating || b.exp - a.exp).slice(0, 3);
    $('#suggestedDoctors').innerHTML = top.map(doctorCard).join('');
}

function renderAuthCta() {
    const box = $('#authCta');
    if (state.user) {
        const up = state.appointments.filter(isUpcoming).length;
        box.innerHTML = `
            <div>
                <h2>أهلاً ${esc(state.user.name.split(' ')[0])} 👋</h2>
                <p>لديك ${up} ${up === 1 ? 'موعد قادم' : 'مواعيد قادمة'}. تابعها أو احجز موعداً جديداً.</p>
            </div>
            <div class="hero-buttons">
                <button class="btn light" data-go="appointments">مواعيدي</button>
                <button class="btn ghost-white" data-go="booking">حجز موعد جديد ←</button>
            </div>`;
    } else {
        box.innerHTML = `
            <div>
                <h2>ابدأ رحلتك الصحية معنا</h2>
                <p>أنشئ حسابك مجاناً لإدارة مواعيدك ومواعيد عائلتك بسهولة.</p>
            </div>
            <div class="hero-buttons">
                <button class="btn light" data-auth="register">إنشاء حساب</button>
                <button class="btn ghost-white" data-auth="login">تسجيل الدخول</button>
            </div>`;
    }
}


/* =================== الأطباء =================== */
function feeRange(d) {
    const fees = d.clinics.map(c => c.fee);
    const min = Math.min(...fees), max = Math.max(...fees);
    return min === max ? fmtMoney(min) : `${fmtMoney(min)} – ${fmtMoney(max)}`;
}

function doctorCard(d, i = 0) {
    const sp = SPECIALTIES[d.specialty];
    const n = nextAvailable(d);
    const slots = n
        ? n.slots.slice(0, 4).map(s => `<span class="mini-slot">${fmtTime(s)}</span>`).join('')
        : '<span class="muted small">لا توجد مواعيد قريبة</span>';
    const cities = [...new Set(d.clinics.map(c => c.city))].join('، ');

    return `
    <article class="doctor-card card-anim" style="--i:${i}">
        <div class="dc-top">
            <div class="dc-avatar" style="--c:${sp.color}">${d.avatar}</div>
            <div class="dc-title">
                <h3>${d.name}</h3>
                <span class="tag" style="--c:${sp.color}">${sp.name}</span>
            </div>
            <span class="rating">★ ${d.rating}</span>
        </div>
        <ul class="dc-meta">
            <li><span>🏥</span>${d.clinics.map(c => c.name).join('، ')}</li>
            <li><span>📍</span>${cities}</li>
            <li><span>💳</span>أجور المعاينة: ${feeRange(d)}</li>
            <li><span>🎓</span>خبرة ${d.exp} سنة</li>
        </ul>
        <div class="dc-slots">
            <small>المواعيد المتاحة · ${n ? relDay(n.date) : '—'}</small>
            <div class="mini-slots">${slots}</div>
        </div>
        <div class="dc-actions">
            <button class="btn light sm" data-details="${d.id}">معلومات الطبيب</button>
            <button class="btn primary sm" data-book="${d.id}">احجز موعد</button>
        </div>
    </article>`;
}

function initFilters() {
    $('#specialtyFilter').innerHTML = '<option value="">جميع الاختصاصات</option>' +
        Object.entries(SPECIALTIES).map(([k, s]) => `<option value="${k}">${s.name}</option>`).join('');

    const cities = [...new Set(DOCTORS.flatMap(d => d.clinics.map(c => c.city)))];
    $('#cityFilter').innerHTML = '<option value="">جميع المدن</option>' +
        cities.map(c => `<option value="${c}">${c}</option>`).join('');

    fillClinicFilter();

    let timer;
    $('#doctorSearch').addEventListener('input', e => {
        clearTimeout(timer);
        timer = setTimeout(() => { state.filters.q = e.target.value.trim(); renderDoctors(); }, 220);
    });
    $('#specialtyFilter').addEventListener('change', e => { state.filters.spec = e.target.value; renderDoctors(); });
    $('#cityFilter').addEventListener('change', e => {
        state.filters.city = e.target.value;
        state.filters.clinic = '';
        fillClinicFilter();
        renderDoctors();
    });
    $('#clinicFilter').addEventListener('change', e => { state.filters.clinic = e.target.value; renderDoctors(); });
    $('#resetFilters').addEventListener('click', () => {
        state.filters = { q: '', spec: '', city: '', clinic: '' };
        fillClinicFilter();
        syncFilterUI();
        renderDoctors();
        toast('تمت إعادة ضبط البحث', 'info');
    });
}

function fillClinicFilter() {
    const city = state.filters.city;
    const clinics = [...new Set(DOCTORS.flatMap(d => d.clinics)
        .filter(c => !city || c.city === city)
        .map(c => c.name))];
    $('#clinicFilter').innerHTML = '<option value="">جميع العيادات</option>' +
        clinics.map(c => `<option value="${c}">${c}</option>`).join('');
    $('#clinicFilter').value = state.filters.clinic;
}

function syncFilterUI() {
    $('#doctorSearch').value = state.filters.q;
    $('#specialtyFilter').value = state.filters.spec;
    $('#cityFilter').value = state.filters.city;
    fillClinicFilter();
}

function showSkeleton() {
    $('#doctorGrid').innerHTML = Array.from({ length: 6 }, () => '<div class="skeleton"></div>').join('');
}

function renderDoctors() {
    const { q, spec, city, clinic } = state.filters;
    const nq = normalize(q);
    const list = DOCTORS.filter(d => {
        if (spec && d.specialty !== spec) return false;
        if (city && !d.clinics.some(c => c.city === city)) return false;
        if (clinic && !d.clinics.some(c => c.name === clinic)) return false;
        if (nq) {
            const hay = normalize(`${d.name} ${SPECIALTIES[d.specialty].name} ${d.clinics.map(c => c.name + ' ' + c.city).join(' ')}`);
            if (!hay.includes(nq)) return false;
        }
        return true;
    });

    $('#resultsCount').textContent = `${list.length} ${list.length === 1 ? 'طبيب' : 'أطباء'}`;
    $('#doctorGrid').innerHTML = list.length
        ? list.map(doctorCard).join('')
        : `<div class="empty-state">
               <div class="empty-icon">🔍</div>
               <h3>لا توجد نتائج مطابقة</h3>
               <p>جرّب البحث بكلمات أخرى أو غيّر الفلاتر.</p>
               <button class="btn light" id="emptyReset">إعادة ضبط البحث</button>
           </div>`;

    const er = $('#emptyReset');
    if (er) er.addEventListener('click', () => $('#resetFilters').click());
}

function openDoctor(id) {
    const d = getDoctor(id);
    if (!d) return;
    const sp = SPECIALTIES[d.specialty];
    const n = nextAvailable(d);
    const order = [6, 0, 1, 2, 3, 4, 5];
    const allSlots = n ? getSlots(d, n.date) : [];

    openModal(`
        <div class="doc-modal">
            <div class="dm-head">
                <div class="dc-avatar lg" style="--c:${sp.color}">${d.avatar}</div>
                <div>
                    <h2>${d.name}</h2>
                    <span class="tag" style="--c:${sp.color}">${sp.name}</span>
                    <div class="dm-badges">
                        <span>★ ${d.rating}</span>
                        <span>🎓 ${d.exp} سنة خبرة</span>
                        <span>👥 +${d.patients} مريض</span>
                    </div>
                </div>
            </div>

            <p class="dm-bio">${d.bio}</p>

            <h4>العيادات وأجور المعاينة</h4>
            ${d.clinics.map(c => `
                <div class="dm-clinic">
                    <div><strong>🏥 ${c.name}</strong><small>📍 ${c.city}</small></div>
                    <span class="fee">${fmtMoney(c.fee)}</span>
                </div>`).join('')}

            <h4>أوقات الدوام</h4>
            <div class="dm-hours">
                🕒 ${d.hours}
                <div class="days">${order.map(i => `<span class="${d.days.includes(i) ? 'on' : ''}">${DAY_NAMES[i]}</span>`).join('')}</div>
            </div>

            <h4>المواعيد المتاحة ${n ? '· ' + relDay(n.date) : ''}</h4>
            <div class="mini-slots">
                ${allSlots.length
                    ? allSlots.map(s => `<span class="mini-slot ${s.available ? '' : 'off'}">${fmtTime(s.time)}</span>`).join('')
                    : '<span class="muted">لا توجد مواعيد متاحة حالياً</span>'}
            </div>

            <button class="btn primary block" data-book="${d.id}">احجز موعداً مع ${d.name} ←</button>
        </div>`, 'wide');
}


/* =================== حجز موعد =================== */
const booking = { doctorId: '', clinicIdx: 0, patientId: 'self', date: '', time: '', payment: 'cash', notes: '' };
let bookingStep = 1;
let bookingDone = false;

function initBookingUI() {
    const sel = $('#bookDoctor');
    sel.innerHTML = '<option value="">— اختر الطبيب —</option>' +
        DOCTORS.map(d => `<option value="${d.id}">${d.name} · ${SPECIALTIES[d.specialty].name}</option>`).join('');

    sel.addEventListener('change', () => {
        booking.doctorId = sel.value;
        booking.clinicIdx = 0;
        booking.time = '';
        const d = getDoctor(sel.value);
        const n = d ? nextAvailable(d) : null;
        booking.date = n ? n.date : todayISO();
        renderBookingDetails();
    });

    $('#clinicOptions').addEventListener('click', e => {
        const b = e.target.closest('[data-clinic]');
        if (!b) return;
        booking.clinicIdx = Number(b.dataset.clinic);
        renderClinics();
        renderFee();
        renderSummary(true);
    });

    $('#patientOptions').addEventListener('click', e => {
        const b = e.target.closest('[data-patient]');
        if (!b) return;
        booking.patientId = b.dataset.patient;
        renderPatients();
        renderSummary(true);
    });

    $('#bookDate').addEventListener('change', e => {
        booking.date = e.target.value;
        booking.time = '';
        renderSlots();
        renderSummary(true);
    });

    $('#slotGrid').addEventListener('click', e => {
        const jump = e.target.closest('[data-jump]');
        if (jump) {
            booking.date = jump.dataset.jump;
            booking.time = '';
            $('#bookDate').value = booking.date;
            renderSlots();
            renderSummary(true);
            return;
        }
        const b = e.target.closest('.slot');
        if (!b || b.disabled) return;
        booking.time = b.dataset.time;
        $$('.slot', $('#slotGrid')).forEach(s => s.classList.toggle('selected', s === b));
        renderSummary(true);
    });

    $('#paymentOptions').addEventListener('click', e => {
        const b = e.target.closest('[data-pay]');
        if (!b) return;
        booking.payment = b.dataset.pay;
        $$('[data-pay]').forEach(x => x.classList.toggle('selected', x === b));
        renderSummary(true);
    });

    $('#bookNotes').addEventListener('input', e => { booking.notes = e.target.value; });
    $('#nextStep').addEventListener('click', nextStep);
    $('#prevStep').addEventListener('click', () => setStep(bookingStep - 1));
    $('#stepper').addEventListener('click', e => {
        const s = e.target.closest('.step-item');
        if (s && Number(s.dataset.step) < bookingStep) setStep(Number(s.dataset.step));
    });
}

function startBooking(docId) {
    const d = getDoctor(docId);
    const n = d ? nextAvailable(d) : null;
    Object.assign(booking, {
        doctorId: d ? String(d.id) : '',
        clinicIdx: 0, patientId: 'self',
        date: n ? n.date : todayISO(),
        time: '', payment: 'cash', notes: ''
    });
    bookingStep = d ? 1 : 1;
    bookingDone = false;
    $('#bookingFlow').hidden = false;
    $('#bookingSuccess').hidden = true;
    go('booking');
    if (d) toast(`تم اختيار ${d.name} — أكمل خطوات الحجز`, 'info');
}

function resetBooking() {
    bookingDone = false;
    Object.assign(booking, { doctorId: '', clinicIdx: 0, patientId: 'self', date: todayISO(), time: '', payment: 'cash', notes: '' });
    bookingStep = 1;
    $('#bookingFlow').hidden = false;
    $('#bookingSuccess').hidden = true;
    renderBooking();
}

function renderBooking() {
    $('#bookDoctor').value = booking.doctorId;
    $('#bookNotes').value = booking.notes;
    $$('[data-pay]').forEach(x => x.classList.toggle('selected', x.dataset.pay === booking.payment));
    renderBookingDetails();
    renderPatients();
    setStep(bookingStep, true);
}

function renderBookingDetails() {
    renderClinics();
    const dateInput = $('#bookDate');
    dateInput.min = todayISO();
    dateInput.max = toISO(addDays(new Date(), 60));
    dateInput.value = booking.date || todayISO();
    renderSlots();
    renderFee();
    renderSummary();
}

function renderClinics() {
    const d = getDoctor(booking.doctorId);
    const box = $('#clinicOptions');
    if (!d) {
        box.innerHTML = '<div class="hint">اختر الطبيب أولاً لعرض العيادات التي يعمل بها.</div>';
        return;
    }
    box.innerHTML = d.clinics.map((c, i) => `
        <button type="button" class="choice-card ${i === booking.clinicIdx ? 'selected' : ''}" data-clinic="${i}">
            <span class="choice-icon">🏥</span>
            <div>
                <strong>${c.name}</strong>
                <small>📍 ${c.city}</small><br>
                <span class="fee">${fmtMoney(c.fee)}</span>
            </div>
            <span class="check">✓</span>
        </button>`).join('');
}

function memberIcon(m) {
    const a = ageOf(m.birth);
    if (a !== null && a < 13) return m.gender === 'f' ? '👧' : '👦';
    if (a !== null && a >= 60) return m.gender === 'f' ? '👵' : '👴';
    return m.gender === 'f' ? '👩' : '👨';
}

function patientNameOf(id) {
    if (id === 'self') return state.user ? state.user.name : 'صاحب الحساب';
    const f = state.family.find(x => x.id === id);
    return f ? f.name : '';
}

function renderPatients() {
    if (booking.patientId !== 'self' && !state.family.find(f => f.id === booking.patientId)) booking.patientId = 'self';
    const list = [
        { id: 'self', name: state.user ? state.user.name : 'أنا (صاحب الحساب)', sub: 'صاحب الحساب', icon: '🧑' },
        ...state.family.map(f => {
            const a = ageOf(f.birth);
            return { id: f.id, name: f.name, sub: `${f.relation}${a !== null ? ' · ' + a + ' سنة' : ''}`, icon: memberIcon(f) };
        })
    ];
    $('#patientOptions').innerHTML = list.map(p => `
        <button type="button" class="choice-card ${p.id === booking.patientId ? 'selected' : ''}" data-patient="${p.id}">
            <span class="choice-icon">${p.icon}</span>
            <div><strong>${esc(p.name)}</strong><small>${esc(p.sub)}</small></div>
            <span class="check">✓</span>
        </button>`).join('');
}

function renderSlots() {
    const d = getDoctor(booking.doctorId);
    const box = $('#slotGrid');
    if (!d) { box.innerHTML = '<div class="hint">اختر الطبيب أولاً لعرض الأوقات المتاحة.</div>'; return; }
    if (!booking.date) { box.innerHTML = '<div class="hint">اختر تاريخ الموعد.</div>'; return; }

    const slots = getSlots(d, booking.date);
    const n = nextAvailable(d);
    const jumpBtn = n && n.date !== booking.date
        ? `<br><button type="button" class="btn light sm" data-jump="${n.date}">أقرب يوم متاح: ${relDay(n.date)}</button>`
        : '';

    if (!slots) {
        box.innerHTML = `<div class="hint">الطبيب لا يداوم يوم ${DAY_NAMES[parseISO(booking.date).getDay()]}.${jumpBtn}</div>`;
        return;
    }
    if (!slots.some(s => s.available)) {
        box.innerHTML = `<div class="hint">جميع الأوقات محجوزة في هذا اليوم.${jumpBtn}</div>`;
        return;
    }
    box.innerHTML = slots.map((s, i) => `
        <button type="button" class="slot ${s.time === booking.time ? 'selected' : ''}" style="--i:${i}"
            data-time="${s.time}" ${s.available ? '' : 'disabled title="محجوز / غير متاح"'}>
            ${fmtTime(s.time)}
        </button>`).join('');
}

function renderFee() {
    const d = getDoctor(booking.doctorId);
    const box = $('#feeBox');
    if (!d) { box.innerHTML = ''; return; }
    const c = d.clinics[booking.clinicIdx];
    box.innerHTML = `<span>أجور المعاينة في ${c.name}</span><strong>${fmtMoney(c.fee)}</strong>`;
}

function renderSummary(flash = false) {
    const d = getDoctor(booking.doctorId);
    const c = d ? d.clinics[booking.clinicIdx] : null;
    const row = (label, value) => `
        <div class="sum-row"><span>${label}</span><strong class="${value ? '' : 'empty'}">${value || 'لم يُحدد'}</strong></div>`;

    $('#bookingSummary').innerHTML = `
        <h3>ملخص الحجز</h3>
        ${d ? `
            <div class="sum-doc">
                <div class="dc-avatar" style="--c:${SPECIALTIES[d.specialty].color}">${d.avatar}</div>
                <div><strong>${d.name}</strong><small>${SPECIALTIES[d.specialty].name}</small></div>
            </div>` : '<div class="hint">لم يتم اختيار طبيب بعد</div><br>'}
        ${row('العيادة', c ? `${c.name} – ${c.city}` : '')}
        ${row('المريض', esc(patientNameOf(booking.patientId)))}
        ${row('التاريخ', booking.date && d ? fmtDate(booking.date) : '')}
        ${row('الوقت', booking.time ? fmtTime(booking.time) : '')}
        ${row('طريقة الدفع', PAY_METHOD[booking.payment])}
        <div class="sum-total"><span>أجور المعاينة</span><strong>${c ? fmtMoney(c.fee) : '—'}</strong></div>`;

    if (flash) {
        const box = $('#bookingSummary');
        box.classList.remove('flash');
        void box.offsetWidth;
        box.classList.add('flash');
    }
}

function setStep(n, silent = false) {
    n = Math.max(1, Math.min(4, n));
    const back = n < bookingStep;
    bookingStep = n;

    $$('.step-panel').forEach(p => {
        const active = Number(p.dataset.panel) === n;
        p.classList.toggle('active', active);
        p.classList.toggle('back', active && back);
    });
    $$('.step-item').forEach(s => {
        const i = Number(s.dataset.step);
        s.classList.toggle('current', i === n);
        s.classList.toggle('done', i < n);
        $('.step-circle', s).textContent = i < n ? '✓' : i;
    });
    $$('.step-line').forEach((l, i) => l.classList.toggle('done', i + 1 < n));

    $('#prevStep').classList.toggle('invisible', n === 1);
    $('#nextStep').innerHTML = n === 4 ? 'تأكيد الحجز ✓' : 'التالي ←';

    if (n === 2) renderPatients();
    if (n === 3) renderSlots();

    if (!silent && window.innerWidth < 1024) {
        const top = $('#stepper').getBoundingClientRect().top + window.scrollY - 90;
        window.scrollTo({ top, behavior: 'smooth' });
    }
}

function validateStep(n) {
    if (n === 1 && !getDoctor(booking.doctorId)) return 'اختر الطبيب والعيادة أولاً';
    if (n === 3 && (!booking.date || !booking.time)) return 'اختر تاريخاً ووقتاً متاحاً';
    return '';
}

function nextStep() {
    const err = validateStep(bookingStep);
    if (err) {
        toast(err, 'error');
        shake($('.step-panel.active'));
        return;
    }
    if (bookingStep < 4) setStep(bookingStep + 1);
    else confirmBooking();
}

function genId() {
    let id;
    do { id = 'SC-' + (10000 + Math.floor(Math.random() * 89999)); }
    while (state.appointments.some(a => a.id === id));
    return id;
}

function genQueueNo(doc, date) {
    const letter = 'ABCDEFGH'[doc.id - 1] || 'Z';
    const sameDay = state.appointments.filter(a => a.doctorId === doc.id && a.date === date).length;
    return `${letter}-${pad(sameDay + 3 + Math.floor(Math.random() * 6))}`;
}

function confirmBooking() {
    if (!state.user) {
        state.pendingAction = null;
        openAuth('login');
        state.pendingAction = confirmBooking;
        toast('سجّل الدخول لإتمام الحجز', 'info');
        return;
    }

    const d = getDoctor(booking.doctorId);
    const slots = getSlots(d, booking.date);
    const stillFree = slots && slots.find(s => s.time === booking.time && s.available);
    if (!stillFree) {
        toast('عذراً، هذا الوقت لم يعد متاحاً. اختر وقتاً آخر', 'error');
        booking.time = '';
        setStep(3);
        return;
    }

    const btn = $('#nextStep');
    setLoading(btn, true);

    setTimeout(() => {
        setLoading(btn, false);
        const c = d.clinics[booking.clinicIdx];
        const appt = {
            id: genId(),
            doctorId: d.id,
            clinicIdx: booking.clinicIdx,
            patientId: booking.patientId,
            patientName: patientNameOf(booking.patientId),
            date: booking.date,
            time: booking.time,
            fee: c.fee,
            payment: booking.payment,
            paymentStatus: booking.payment === 'cash' ? 'unpaid' : 'paid',
            status: 'confirmed',
            queueNo: genQueueNo(d, booking.date),
            notes: booking.notes.trim()
        };
        state.appointments.unshift(appt);
        save();
        showSuccess(appt);
    }, 1300);
}

function showSuccess(a) {
    bookingDone = true;
    const d = getDoctor(a.doctorId), c = d.clinics[a.clinicIdx];
    const colors = ['#1463ff', '#12b5a5', '#f59e0b', '#e5484d', '#7c3aed', '#22c55e'];
    const confetti = Array.from({ length: 34 }, () =>
        `<i style="left:${Math.random() * 100}%; background:${colors[Math.floor(Math.random() * colors.length)]};
            animation-delay:${(Math.random() * 0.6).toFixed(2)}s; animation-duration:${(2 + Math.random() * 1.5).toFixed(2)}s"></i>`
    ).join('');

    const box = $('#bookingSuccess');
    box.innerHTML = `
        <div class="confetti">${confetti}</div>
        <svg class="check-svg" viewBox="0 0 52 52">
            <circle class="check-circle" cx="26" cy="26" r="24"></circle>
            <path class="check-path" d="M15 27l7 7 15-16"></path>
        </svg>
        <h2>تم تأكيد حجزك بنجاح!</h2>
        <p class="muted">احتفظ برقم الحجز لمراجعة العيادة.</p>
        <div class="booking-no">${a.id}</div>
        <div class="success-details">
            <div><span>الطبيب</span><strong>${d.name}</strong></div>
            <div><span>العيادة</span><strong>${c.name} – ${c.city}</strong></div>
            <div><span>المريض</span><strong>${esc(a.patientName)}</strong></div>
            <div><span>التاريخ والوقت</span><strong>${fmtDate(a.date)} · ${fmtTime(a.time)}</strong></div>
            <div><span>رقم الدور</span><strong>${a.queueNo}</strong></div>
            <div><span>أجور المعاينة</span><strong>${fmtMoney(a.fee)}</strong></div>
            <div><span>طريقة الدفع</span><strong>${PAY_METHOD[a.payment]}</strong></div>
            <div><span>حالة الدفع</span><strong>${PAY_STATUS[a.paymentStatus].label}</strong></div>
        </div>
        <div class="hero-buttons center">
            <button class="btn primary" data-go="appointments">عرض مواعيدي</button>
            <button class="btn light" data-queue="${a.id}">متابعة الدور</button>
            <button class="btn light" id="newBooking">حجز موعد آخر</button>
        </div>`;

    $('#bookingFlow').hidden = true;
    box.hidden = false;
    $('#newBooking').addEventListener('click', resetBooking);
    window.scrollTo({ top: 0, behavior: 'smooth' });
    toast('تم الحجز بنجاح 🎉', 'success');
}


/* =================== مواعيدي =================== */
const isUpcoming = a => (a.status === 'confirmed' || a.status === 'pending') && a.date >= todayISO();
const canCancel = a => isUpcoming(a) && (apptDateTime(a) - new Date()) > 2 * 3600 * 1000;

function apptPatient(a) {
    if (a.patientId === 'self') return state.user ? state.user.name : 'صاحب الحساب';
    const f = state.family.find(x => x.id === a.patientId);
    return f ? f.name : (a.patientName || '—');
}

function initAppointmentsUI() {
    $('#apptTabs').addEventListener('click', e => {
        const t = e.target.closest('[data-tab]');
        if (!t) return;
        state.apptTab = t.dataset.tab;
        $$('.tab', $('#apptTabs')).forEach(x => x.classList.toggle('active', x === t));
        renderAppointments();
    });

    $('#appointmentList').addEventListener('click', async e => {
        const cancel = e.target.closest('[data-cancel]');
        const toggle = e.target.closest('[data-toggle-consult]');

        if (toggle) {
            const card = toggle.closest('.appt-card');
            card.classList.toggle('open');
            toggle.textContent = card.classList.contains('open') ? 'إخفاء التفاصيل' : 'تفاصيل الاستشارة';
        }

        if (cancel) {
            const a = state.appointments.find(x => x.id === cancel.dataset.cancel);
            if (!a) return;
            const ok = await confirmDialog({
                title: 'إلغاء الموعد؟',
                text: `سيتم إلغاء موعدك رقم ${a.id} مع ${getDoctor(a.doctorId).name}. ${a.paymentStatus === 'paid' ? 'سيتم استرداد المبلغ المدفوع.' : ''}`,
                ok: 'نعم، إلغاء الموعد', danger: true, icon: '🗓️'
            });
            if (!ok) return;
            a.status = 'cancelled';
            if (a.paymentStatus === 'paid') a.paymentStatus = 'refunded';
            delete state.queueSims[a.id];
            save();
            const card = cancel.closest('.appt-card');
            card.classList.add('removing');
            setTimeout(renderAppointments, 380);
            toast('تم إلغاء الموعد', 'success');
        }
    });
}

function renderAppointments() {
    const byTime = (a, b) => apptDateTime(a) - apptDateTime(b);
    const up = state.appointments.filter(isUpcoming).sort(byTime);
    const past = state.appointments.filter(a => !isUpcoming(a)).sort((a, b) => byTime(b, a));
    $('#countUpcoming').textContent = up.length;
    $('#countPast').textContent = past.length;

    const list = state.apptTab === 'upcoming' ? up : past;
    const box = $('#appointmentList');

    if (!list.length) {
        box.innerHTML = `
            <div class="empty-state">
                <div class="empty-icon">${state.apptTab === 'upcoming' ? '📅' : '🗂️'}</div>
                <h3>${state.apptTab === 'upcoming' ? 'لا توجد مواعيد قادمة' : 'لا توجد مواعيد سابقة'}</h3>
                <p>احجز موعدك الأول مع أحد أطبائنا.</p>
                <button class="btn primary" data-go="booking">احجز موعداً ←</button>
            </div>`;
        return;
    }

    box.innerHTML = list.map((a, i) => {
        const d = getDoctor(a.doctorId), c = d.clinics[a.clinicIdx];
        const st = STATUS[a.status], ps = PAY_STATUS[a.paymentStatus];
        const isPast = !isUpcoming(a);
        const dt = parseISO(a.date);
        const weekday = new Intl.DateTimeFormat('ar', { weekday: 'short' }).format(dt);
        const month = new Intl.DateTimeFormat('ar', { month: 'short' }).format(dt);

        let actions = '';
        if (!isPast) {
            if (a.date === todayISO()) actions += `<button class="btn primary sm" data-queue="${a.id}">🎫 متابعة الدور</button>`;
            actions += canCancel(a)
                ? `<button class="btn danger-light sm" data-cancel="${a.id}">إلغاء الموعد</button>`
                : `<button class="btn light sm" disabled title="لا يمكن الإلغاء قبل أقل من ساعتين من الموعد">لا يمكن الإلغاء</button>`;
        } else if (a.status === 'completed') {
            actions += `<button class="btn light sm" data-toggle-consult>تفاصيل الاستشارة</button>`;
            actions += `<button class="btn primary sm" data-book="${d.id}">حجز متابعة</button>`;
        } else {
            actions += `<button class="btn light sm" data-book="${d.id}">إعادة الحجز</button>`;
        }

        const consult = a.status === 'completed' ? `
            <div class="consult"><div>
                <div class="consult-inner">
                    ${a.consult ? `
                        <div><b>التشخيص:</b> ${esc(a.consult.diagnosis)}</div>
                        <div><b>العلاج:</b> ${esc(a.consult.treatment)}</div>
                        <div><b>المتابعة:</b> ${esc(a.consult.followUp)}</div>`
                    : '<div>لم يُضف الطبيب ملاحظات لهذه الاستشارة بعد.</div>'}
                </div>
            </div></div>` : '';

        return `
        <article class="appt-card card-anim ${isPast ? 'past' : ''}" style="--i:${i}">
            <div class="appt-date">
                <span>${weekday}</span>
                <strong>${dt.getDate()}</strong>
                <small>${month}</small>
            </div>
            <div class="appt-info">
                <div class="appt-head">
                    <h3>${d.name}</h3>
                    <span class="badge ${st.cls}">${st.label}</span>
                </div>
                <p class="muted">${SPECIALTIES[d.specialty].name} · ${c.name} – ${c.city}</p>
                <div class="appt-meta">
                    <span>🕒 ${fmtTime(a.time)}</span>
                    <span>👤 ${esc(apptPatient(a))}</span>
                    <span>🔖 ${a.id}</span>
                    <span>💳 ${fmtMoney(a.fee)}</span>
                    <span class="badge ${ps.cls}">${ps.label}</span>
                </div>
                ${consult}
            </div>
            <div class="appt-actions">${actions}</div>
        </article>`;
    }).join('');
}


/* =================== متابعة الدور =================== */
const RING_LEN = 603.19;
let lastTickSec = 0;

const queueOptions = () => state.appointments
    .filter(a => a.status !== 'cancelled' && a.date >= todayISO())
    .sort((a, b) => apptDateTime(a) - apptDateTime(b));

function ensureSim(a) {
    if (state.queueSims[a.id]) return state.queueSims[a.id];
    const isToday = a.date === todayISO();
    const ahead = isToday ? 3 + (hash(a.id) % 4) : 0;
    const sim = {
        ahead, total: ahead + 1,
        status: isToday ? (a.status === 'completed' ? 'done' : 'waiting') : 'notstarted',
        inTicks: 0, updatedAt: Date.now()
    };
    state.queueSims[a.id] = sim;
    return sim;
}

function waitText(s) {
    return {
        notstarted: 'يبدأ يوم الموعد',
        waiting: `حوالي ${Math.max(5, s.ahead * 7)} دقيقة`,
        next: 'أقل من 5 دقائق',
        in: 'الاستشارة جارية الآن',
        done: 'انتهت الزيارة'
    }[s.status];
}

function initQueueUI() {
    $('#queueSelect').addEventListener('change', e => { state.queueSelected = e.target.value; renderQueue(true); });
    $('#autoRefresh').addEventListener('change', e => {
        state.queueAuto = e.target.checked;
        toast(state.queueAuto ? 'تم تفعيل التحديث التلقائي' : 'تم إيقاف التحديث التلقائي', 'info');
    });
    $('#refreshQueue').addEventListener('click', e => {
        const btn = e.currentTarget;
        btn.classList.remove('spinning');
        void btn.offsetWidth;
        btn.classList.add('spinning');
        tickQueue();
        toast('تم تحديث معلومات الطابور', 'success');
    });
}

function renderQueue(animate = false) {
    const opts = queueOptions();
    const empty = !opts.length;
    $('#queueWrap').hidden = empty;
    $('#queueEmpty').hidden = !empty;
    if (empty) return;

    if (!state.queueSelected || !opts.find(a => a.id === state.queueSelected)) {
        state.queueSelected = (opts.find(a => a.date === todayISO()) || opts[0]).id;
    }

    $('#queueSelect').innerHTML = opts.map(a =>
        `<option value="${a.id}" ${a.id === state.queueSelected ? 'selected' : ''}>
            ${a.queueNo} · ${getDoctor(a.doctorId).name} · ${relDay(a.date)}
        </option>`).join('');

    const a = opts.find(x => x.id === state.queueSelected);
    const s = ensureSim(a);
    const d = getDoctor(a.doctorId), c = d.clinics[a.clinicIdx];
    const qs = Q_STATUS[s.status];

    const numEl = $('#queueNumber');
    numEl.textContent = a.queueNo;

    const aheadTxt = s.status === 'waiting' ? `${s.ahead} ${s.ahead === 1 ? 'مريض' : 'مرضى'} قبلك` : qs.label;
    $('#queueAheadSmall').textContent = aheadTxt;
    $('#queueDoctor').textContent = `${d.name} · ${SPECIALTIES[d.specialty].name}`;
    $('#waitTime').textContent = waitText(s);

    const badge = $('#consultStatus');
    badge.className = `badge ${qs.cls}`;
    badge.textContent = qs.label;

    const peopleEl = $('#peopleAhead');
    peopleEl.textContent = s.status === 'notstarted' ? '—' : (s.status === 'waiting' ? `${s.ahead} ${s.ahead === 1 ? 'مريض' : 'مرضى'}` : '0');
    $('#queueTime').textContent = fmtTime(a.time);
    $('#queueDate').textContent = relDay(a.date);
    $('#queueClinic').textContent = `${c.name}`;
    $('#queuePatient').textContent = apptPatient(a);

    const progress = {
        notstarted: 0.04,
        waiting: Math.max(0.08, (s.total - s.ahead) / (s.total + 2)),
        next: 0.82, in: 0.93, done: 1
    }[s.status];
    $('#ringFg').style.strokeDashoffset = RING_LEN * (1 - progress);

    $('#liveBadge').hidden = a.date !== todayISO() || s.status === 'done';

    const stepIdx = { notstarted: 0, waiting: 1, next: 2, in: 3, done: 5 }[s.status];
    const steps = ['تم الحجز', 'في الانتظار', 'دورك التالي', 'داخل الاستشارة', 'اكتملت الزيارة'];
    $('#queueTimeline').innerHTML = steps.map((t, i) => {
        const cls = i < stepIdx ? 'done' : (i === stepIdx ? 'current' : '');
        return `<div class="tl-step ${cls}"><span class="tl-dot">${i < stepIdx ? '✓' : i + 1}</span>${t}</div>`;
    }).join('');

    if (animate) {
        [numEl, peopleEl, $('#queueAheadSmall')].forEach(el => {
            el.classList.remove('bump');
            void el.offsetWidth;
            el.classList.add('bump');
        });
    }
    updateLastUpdate();
}

function updateLastUpdate() {
    const a = state.appointments.find(x => x.id === state.queueSelected);
    const el = $('#lastUpdate');
    if (!a || !el) return;
    if (a.date !== todayISO()) {
        el.textContent = 'ستُفعّل المتابعة المباشرة يوم موعدك';
        return;
    }
    const s = ensureSim(a);
    const sec = Math.floor((Date.now() - s.updatedAt) / 1000);
    el.textContent = `آخر تحديث: ${sec < 3 ? 'الآن' : 'منذ ' + sec + ' ثانية'}${state.queueAuto ? ' · يتحدث تلقائياً' : ''}`;
}

function tickQueue() {
    const today = todayISO();
    let changed = false;

    state.appointments
        .filter(a => a.date === today && a.status !== 'cancelled')
        .forEach(a => {
            const s = ensureSim(a);
            const prev = s.status, prevAhead = s.ahead;

            if (s.status === 'waiting') {
                if (Math.random() < 0.55) {
                    s.ahead = Math.max(0, s.ahead - 1);
                    if (s.ahead === 0) s.status = 'next';
                }
            } else if (s.status === 'next') {
                if (Math.random() < 0.5) s.status = 'in';
            } else if (s.status === 'in') {
                s.inTicks++;
                if (s.inTicks >= 3) {
                    s.status = 'done';
                    a.status = 'completed';
                    if (a.paymentStatus === 'unpaid') a.paymentStatus = 'paid';
                    save();
                }
            }
            s.updatedAt = Date.now();

            if (prev !== s.status || prevAhead !== s.ahead) changed = true;
            if (prev !== s.status) {
                if (s.status === 'next') toast(`🔔 اقترب دورك! رقمك ${a.queueNo}`, 'info');
                if (s.status === 'in') toast('تفضّل بالدخول إلى غرفة الطبيب', 'success');
                if (s.status === 'done') toast('اكتملت الاستشارة، نتمنى لك دوام الصحة 💙', 'success');
            }
        });

    if (currentPage === 'queue') renderQueue(changed);
}

function clockTick() {
    lastTickSec++;
    if (state.queueAuto && lastTickSec % 8 === 0) tickQueue();
    if (currentPage === 'queue') updateLastUpdate();
}


/* =================== الحساب وتسجيل الدخول =================== */
function authHTML(tab) {
    return `
    <div class="auth">
        <div class="auth-head">
            <span class="logo">✚</span>
            <h2>مرحباً بك في العيادة الذكية</h2>
            <p class="muted">سجّل دخولك أو أنشئ حساباً جديداً لإدارة مواعيدك.</p>
        </div>

        <div class="auth-tabs" data-active="${tab}">
            <span class="auth-ind"></span>
            <button type="button" class="auth-tab ${tab === 'login' ? 'active' : ''}" data-auth-tab="login">تسجيل الدخول</button>
            <button type="button" class="auth-tab ${tab === 'register' ? 'active' : ''}" data-auth-tab="register">إنشاء حساب</button>
        </div>

        <form class="auth-form ${tab === 'login' ? 'active' : ''}" id="loginForm" novalidate>
            <div class="form-group">
                <label>البريد الإلكتروني</label>
                <input class="field" name="email" type="email" placeholder="name@example.com" autocomplete="email">
                <small class="error-text"></small>
            </div>
            <div class="form-group">
                <label>كلمة المرور</label>
                <div class="pass-wrap">
                    <input class="field" name="password" type="password" placeholder="••••••" autocomplete="current-password">
                    <button type="button" class="toggle-pass">👁</button>
                </div>
                <small class="error-text"></small>
            </div>
            <button class="btn primary block" type="submit">دخول ←</button>
        </form>

        <form class="auth-form ${tab === 'register' ? 'active' : ''}" id="registerForm" novalidate>
            <div class="form-group">
                <label>الاسم الكامل</label>
                <input class="field" name="name" type="text" placeholder="مثال: نور محمد علي">
                <small class="error-text"></small>
            </div>
            <div class="form-grid">
                <div class="form-group">
                    <label>رقم الهاتف</label>
                    <input class="field" name="phone" type="tel" placeholder="07XXXXXXXXX" dir="ltr">
                    <small class="error-text"></small>
                </div>
                <div class="form-group">
                    <label>الجنس</label>
                    <select class="field" name="gender">
                        <option value="">اختر</option>
                        <option value="m">ذكر</option>
                        <option value="f">أنثى</option>
                    </select>
                    <small class="error-text"></small>
                </div>
            </div>
            <div class="form-group">
                <label>البريد الإلكتروني</label>
                <input class="field" name="email" type="email" placeholder="name@example.com" autocomplete="email">
                <small class="error-text"></small>
            </div>
            <div class="form-grid">
                <div class="form-group">
                    <label>كلمة المرور</label>
                    <div class="pass-wrap">
                        <input class="field" name="password" type="password" placeholder="6 أحرف على الأقل" autocomplete="new-password">
                        <button type="button" class="toggle-pass">👁</button>
                    </div>
                    <small class="error-text"></small>
                </div>
                <div class="form-group">
                    <label>تأكيد كلمة المرور</label>
                    <input class="field" name="confirm" type="password" placeholder="أعد كتابتها" autocomplete="new-password">
                    <small class="error-text"></small>
                </div>
            </div>
            <button class="btn primary block" type="submit">إنشاء الحساب ←</button>
        </form>

        <p class="auth-note">بيئة تجريبية: يمكنك الدخول بأي بريد صحيح وكلمة مرور من 6 أحرف أو أكثر.</p>
    </div>`;
}

function openAuth(tab = 'login') {
    openModal(authHTML(tab));
}

function switchAuthTab(tab) {
    $('.auth-tabs').dataset.active = tab;
    $$('.auth-tab').forEach(t => t.classList.toggle('active', t.dataset.authTab === tab));
    $('#loginForm').classList.toggle('active', tab === 'login');
    $('#registerForm').classList.toggle('active', tab === 'register');
}

function makeProfile({ name, email, phone = '', gender = '' }) {
    return {
        name, email: email.toLowerCase(), phone, gender,
        city: 'بغداد', birth: '',
        patientId: 'P-' + (10000 + Math.floor(Math.random() * 89999)),
        joined: todayISO()
    };
}

function handleLogin(f) {
    const email = f.elements.email.value.trim();
    const pass = f.elements.password.value;
    let ok = true;

    if (!isEmail(email)) { setError(f.elements.email, 'أدخل بريداً إلكترونياً صحيحاً'); ok = false; }
    else setError(f.elements.email, '');
    if (pass.length < 6) { setError(f.elements.password, 'كلمة المرور 6 أحرف على الأقل'); ok = false; }
    else setError(f.elements.password, '');

    if (!ok) { shake(f); return; }

    setLoading($('[type=submit]', f), true);
    setTimeout(() => {
        const acc = state.accounts[email.toLowerCase()] || makeProfile({ name: 'مريض تجريبي', email });
        loginAs(acc, false);
    }, 900);
}

function handleRegister(f) {
    const el = f.elements;
    const v = {
        name: el.name.value.trim(),
        phone: el.phone.value.trim(),
        gender: el.gender.value,
        email: el.email.value.trim(),
        password: el.password.value,
        confirm: el.confirm.value
    };
    let ok = true;
    const check = (input, cond, msg) => { if (!cond) { setError(input, msg); ok = false; } else setError(input, ''); };

    check(el.name, v.name.split(/\s+/).length >= 2, 'أدخل الاسم الثنائي على الأقل');
    check(el.phone, isPhone(v.phone), 'رقم الهاتف يجب أن يبدأ بـ 07 ويتكون من 11 رقماً');
    check(el.gender, !!v.gender, 'اختر الجنس');
    check(el.email, isEmail(v.email), 'أدخل بريداً إلكترونياً صحيحاً');
    check(el.password, v.password.length >= 6, 'كلمة المرور 6 أحرف على الأقل');
    check(el.confirm, v.confirm === v.password && v.confirm.length > 0, 'كلمتا المرور غير متطابقتين');

    if (!ok) { shake(f); return; }

    setLoading($('[type=submit]', f), true);
    setTimeout(() => {
        loginAs(makeProfile(v), true);
    }, 1000);
}

function loginAs(acc, isNew) {
    state.accounts[acc.email] = acc;
    state.user = acc;
    save();
    updateHeader();

    const action = state.pendingAction;
    state.pendingAction = null;
    closeModal();

    toast(isNew ? `تم إنشاء حسابك بنجاح، أهلاً ${acc.name.split(' ')[0]} 🎉` : `أهلاً بعودتك ${acc.name.split(' ')[0]} 👋`, 'success');
    refreshCurrentPage();
    if (action) setTimeout(action, 450);
}

function logout() {
    confirmDialog({ title: 'تسجيل الخروج؟', text: 'هل تريد تسجيل الخروج من حسابك؟', ok: 'تسجيل الخروج', danger: true, icon: '👋' })
        .then(ok => {
            if (!ok) return;
            state.user = null;
            save();
            updateHeader();
            toast('تم تسجيل الخروج', 'info');
            go('home');
        });
}

function updateHeader() {
    const btn = $('#profileBtn');
    if (state.user) {
        $('#headerName').textContent = state.user.name.split(' ')[0];
        $('#headerAvatar').textContent = state.user.name.trim().charAt(0);
        btn.classList.add('logged');
    } else {
        $('#headerName').textContent = 'تسجيل الدخول';
        $('#headerAvatar').textContent = '👤';
        btn.classList.remove('logged');
    }
    renderAuthCta();
}

function refreshCurrentPage() {
    if (currentPage === 'profile') renderProfile();
    if (currentPage === 'booking' && !bookingDone) { renderPatients(); renderSummary(); }
    if (currentPage === 'appointments') renderAppointments();
    if (currentPage === 'home') renderAuthCta();
}


/* =================== الملف الشخصي =================== */
function familyItemHTML(m) {
    const a = ageOf(m.birth);
    return `
    <div class="family-item card-anim" data-member="${m.id}">
        <div class="fm-avatar">${memberIcon(m)}</div>
        <div class="fm-info">
            <strong>${esc(m.name)}</strong>
            <small>${esc(m.relation)}${a !== null ? ' · ' + a + ' سنة' : ''} · ${m.gender === 'f' ? 'أنثى' : 'ذكر'} · فصيلة الدم: ${esc(m.blood || 'غير معروف')}</small>
        </div>
        <div class="fm-actions">
            <button class="icon-btn" data-edit-member="${m.id}" title="تعديل">✎</button>
            <button class="icon-btn danger" data-del-member="${m.id}" title="حذف">🗑</button>
        </div>
    </div>`;
}

function renderFamilyList() {
    const box = $('#familyList');
    if (!box) return;
    box.innerHTML = state.family.length
        ? state.family.map(familyItemHTML).join('')
        : '<div class="hint">لم تتم إضافة أي فرد من العائلة بعد.</div>';
}

function renderProfile() {
    const box = $('#profileContent');
    if (!state.user) {
        box.innerHTML = `
            <div class="login-prompt card-anim">
                <div class="lp-icon">🔐</div>
                <h3>سجّل الدخول لعرض ملفك الشخصي</h3>
                <p>يمكنك من خلال ملفك إدارة معلوماتك وأفراد عائلتك ومتابعة زياراتك.</p>
                <div class="hero-buttons center">
                    <button class="btn primary" data-auth="login">تسجيل الدخول</button>
                    <button class="btn light" data-auth="register">إنشاء حساب</button>
                </div>
            </div>`;
        return;
    }

    const u = state.user;
    const upcoming = state.appointments.filter(isUpcoming).length;
    const completed = state.appointments.filter(a => a.status === 'completed').length;
    const opt = (list, val) => list.map(x => `<option value="${x}" ${x === val ? 'selected' : ''}>${x}</option>`).join('');

    box.innerHTML = `
    <div class="profile-layout">
        <aside class="profile-card card-anim">
            <div class="pc-cover"></div>
            <div class="pc-avatar">${esc(u.name.trim().charAt(0))}</div>
            <h3>${esc(u.name)}</h3>
            <span class="id-chip">رقم المريض: ${u.patientId}</span>

            <div class="pc-stats">
                <div><strong>${upcoming}</strong><small>مواعيد قادمة</small></div>
                <div><strong>${completed}</strong><small>زيارات مكتملة</small></div>
                <div><strong>${state.family.length}</strong><small>أفراد العائلة</small></div>
            </div>

            <div class="pc-info">
                <div><span>📧</span>${esc(u.email)}</div>
                <div><span>📱</span>${esc(u.phone || 'لم يُضف بعد')}</div>
                <div><span>📍</span>${esc(u.city || '—')}</div>
                <div><span>📅</span>عضو منذ ${fmtDate(u.joined, { month: 'long', year: 'numeric' })}</div>
            </div>

            <button class="btn danger-light block" id="logoutBtn">تسجيل الخروج</button>
        </aside>

        <div class="profile-main">
            <div class="panel card-anim" style="--i:1">
                <div class="panel-head">
                    <h3>معلومات الحساب</h3>
                    <span class="muted small">الحقول المقفلة 🔒 لا يمكن تعديلها</span>
                </div>

                <form id="accountForm" class="form-grid" novalidate>
                    <div class="form-group">
                        <label>الاسم الكامل</label>
                        <input class="field" name="name" value="${esc(u.name)}">
                        <small class="error-text"></small>
                    </div>
                    <div class="form-group">
                        <label>رقم الهاتف</label>
                        <input class="field" name="phone" value="${esc(u.phone)}" placeholder="07XXXXXXXXX" dir="ltr">
                        <small class="error-text"></small>
                    </div>
                    <div class="form-group">
                        <label>البريد الإلكتروني</label>
                        <input class="field" name="email" type="email" value="${esc(u.email)}">
                        <small class="error-text"></small>
                    </div>
                    <div class="form-group">
                        <label>المدينة</label>
                        <select class="field" name="city">${opt(CITIES, u.city)}</select>
                    </div>
                    <div class="form-group">
                        <label>تاريخ الميلاد</label>
                        <input class="field" name="birth" type="date" value="${esc(u.birth)}" max="${todayISO()}">
                    </div>
                    <div class="form-group">
                        <label>الجنس</label>
                        <select class="field" name="gender">
                            <option value="">اختر</option>
                            <option value="m" ${u.gender === 'm' ? 'selected' : ''}>ذكر</option>
                            <option value="f" ${u.gender === 'f' ? 'selected' : ''}>أنثى</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="lock-label">رقم المريض</label>
                        <input class="field" value="${u.patientId}" readonly>
                    </div>
                    <div class="form-group">
                        <label class="lock-label">تاريخ التسجيل</label>
                        <input class="field" value="${fmtDate(u.joined, { day: 'numeric', month: 'long', year: 'numeric' })}" readonly>
                    </div>
                    <div class="full">
                        <button class="btn primary" type="submit">حفظ التغييرات ✓</button>
                    </div>
                </form>
            </div>

            <div class="panel card-anim" style="--i:2">
                <div class="panel-head">
                    <h3>أفراد العائلة</h3>
                    <button class="btn primary sm" id="addFamily">+ إضافة فرد</button>
                </div>
                <div class="family-list" id="familyList"></div>
            </div>
        </div>
    </div>`;

    renderFamilyList();
}

function initProfileUI() {
    const box = $('#profileContent');

    box.addEventListener('submit', e => {
        e.preventDefault();
        if (e.target.id !== 'accountForm') return;
        const f = e.target, el = f.elements;
        let ok = true;
        const check = (input, cond, msg) => { if (!cond) { setError(input, msg); ok = false; } else setError(input, ''); };

        check(el.name, el.name.value.trim().split(/\s+/).length >= 2, 'أدخل الاسم الثنائي على الأقل');
        check(el.phone, !el.phone.value.trim() || isPhone(el.phone.value), 'رقم هاتف غير صحيح (07XXXXXXXXX)');
        check(el.email, isEmail(el.email.value.trim()), 'بريد إلكتروني غير صحيح');
        if (!ok) { shake(f); return; }

        const btn = $('[type=submit]', f);
        setLoading(btn, true);
        setTimeout(() => {
            const oldEmail = state.user.email;
            Object.assign(state.user, {
                name: el.name.value.trim(),
                phone: el.phone.value.trim(),
                email: el.email.value.trim().toLowerCase(),
                city: el.city.value,
                birth: el.birth.value,
                gender: el.gender.value
            });
            if (oldEmail !== state.user.email) delete state.accounts[oldEmail];
            state.accounts[state.user.email] = state.user;
            save();
            updateHeader();
            setLoading(btn, false);
            renderProfile();
            toast('تم حفظ معلوماتك بنجاح', 'success');
        }, 800);
    });

    box.addEventListener('input', e => {
        const g = e.target.closest('.form-group.has-error');
        if (g) setError(e.target, '');
    });

    box.addEventListener('click', async e => {
        if (e.target.closest('#logoutBtn')) logout();
        if (e.target.closest('#addFamily')) openFamilyForm();

        const edit = e.target.closest('[data-edit-member]');
        if (edit) openFamilyForm(edit.dataset.editMember);

        const del = e.target.closest('[data-del-member]');
        if (del) {
            const m = state.family.find(x => x.id === del.dataset.delMember);
            if (!m) return;
            const ok = await confirmDialog({
                title: `حذف ${esc(m.name)}؟`,
                text: 'سيتم حذف ملف هذا الفرد من حسابك. لا يمكن التراجع عن هذا الإجراء.',
                ok: 'نعم، احذف', danger: true, icon: '🗑️'
            });
            if (!ok) return;
            const item = $(`[data-member="${m.id}"]`);
            if (item) item.classList.add('removing');
            setTimeout(() => {
                state.family = state.family.filter(x => x.id !== m.id);
                save();
                renderProfile();
                toast('تم حذف الفرد من العائلة', 'success');
            }, 350);
        }
    });
}

function openFamilyForm(id) {
    const m = id ? state.family.find(x => x.id === id) : { name: '', relation: '', birth: '', gender: '', blood: 'غير معروف' };
    if (!m) return;
    openModal(`
        <h2 class="modal-title">${id ? 'تعديل بيانات فرد' : 'إضافة فرد من العائلة'}</h2>
        <form id="familyForm" data-id="${id || ''}" novalidate>
            <div class="form-group">
                <label>الاسم</label>
                <input class="field" name="name" value="${esc(m.name)}" placeholder="اسم الفرد">
                <small class="error-text"></small>
            </div>
            <div class="form-grid">
                <div class="form-group">
                    <label>صلة القرابة</label>
                    <select class="field" name="relation">
                        <option value="">اختر</option>
                        ${RELATIONS.map(r => `<option ${r === m.relation ? 'selected' : ''}>${r}</option>`).join('')}
                    </select>
                    <small class="error-text"></small>
                </div>
                <div class="form-group">
                    <label>الجنس</label>
                    <select class="field" name="gender">
                        <option value="">اختر</option>
                        <option value="m" ${m.gender === 'm' ? 'selected' : ''}>ذكر</option>
                        <option value="f" ${m.gender === 'f' ? 'selected' : ''}>أنثى</option>
                    </select>
                    <small class="error-text"></small>
                </div>
                <div class="form-group">
                    <label>تاريخ الميلاد</label>
                    <input class="field" name="birth" type="date" value="${esc(m.birth)}" max="${todayISO()}">
                    <small class="error-text"></small>
                </div>
                <div class="form-group">
                    <label>فصيلة الدم</label>
                    <select class="field" name="blood">
                        ${BLOOD.map(b => `<option ${b === m.blood ? 'selected' : ''}>${b}</option>`).join('')}
                    </select>
                </div>
            </div>
            <button class="btn primary block" type="submit">${id ? 'حفظ التعديلات ✓' : 'إضافة ✓'}</button>
        </form>`);
}

function handleFamilySave(f) {
    const el = f.elements;
    let ok = true;
    const check = (input, cond, msg) => { if (!cond) { setError(input, msg); ok = false; } else setError(input, ''); };
    check(el.name, el.name.value.trim().length >= 2, 'أدخل اسماً صحيحاً');
    check(el.relation, !!el.relation.value, 'اختر صلة القرابة');
    check(el.gender, !!el.gender.value, 'اختر الجنس');
    check(el.birth, !!el.birth.value, 'أدخل تاريخ الميلاد');
    if (!ok) { shake(f); return; }

    const data = {
        name: el.name.value.trim(), relation: el.relation.value,
        gender: el.gender.value, birth: el.birth.value, blood: el.blood.value
    };
    const id = f.dataset.id;
    setLoading($('[type=submit]', f), true);

    setTimeout(() => {
        if (id) {
            Object.assign(state.family.find(x => x.id === id), data);
            toast('تم تعديل البيانات', 'success');
        } else {
            state.family.push({ id: 'f' + Date.now(), ...data });
            toast(`تمت إضافة ${data.name} إلى العائلة`, 'success');
        }
        save();
        closeModal();
        renderProfile();
    }, 600);
}


/* =================== المساعد الذكي «نجيب» =================== */
const KEYWORDS = {
    cardiology:    ['قلب', 'ضغط', 'صدر', 'خفقان'],
    dermatology:   ['جلد', 'بشره', 'حب الشباب', 'حكه', 'شعر'],
    pediatrics:    ['طفل', 'اطفال', 'رضيع', 'لقاح'],
    neurology:     ['اعصاب', 'صداع', 'دوخه', 'شقيقه', 'تنميل'],
    family:        ['حراره', 'زكام', 'انفلونزا', 'سعال', 'كحه', 'فحص عام'],
    dentistry:     ['سن', 'اسنان', 'ضرس', 'لثه'],
    ophthalmology: ['عين', 'عيون', 'نظر', 'رؤيه'],
    orthopedics:   ['عظم', 'مفصل', 'ظهر', 'ركبه', 'كسر', 'فقرات']
};

const chatTime = () => new Intl.DateTimeFormat('ar-u-nu-latn', { hour: '2-digit', minute: '2-digit' }).format(new Date());

function addMsg(html, who, actions = []) {
    const box = $('#chatMessages');
    const m = document.createElement('div');
    m.className = `msg ${who}`;
    m.innerHTML = `
        <div class="bubble">${html}</div>
        ${actions.length ? `<div class="msg-actions">${actions.map(a => `<button class="msg-action" ${a.attr}>${a.label}</button>`).join('')}</div>` : ''}
        <span class="msg-time">${chatTime()}</span>`;
    box.appendChild(m);
    box.scrollTop = box.scrollHeight;
}

function showTyping() {
    const box = $('#chatMessages');
    const t = document.createElement('div');
    t.className = 'typing';
    t.innerHTML = '<span></span><span></span><span></span>';
    box.appendChild(t);
    box.scrollTop = box.scrollHeight;
    return t;
}

function botSay(reply) {
    const t = showTyping();
    const delay = 650 + Math.min(1300, reply.text.length * 10);
    setTimeout(() => {
        t.remove();
        addMsg(reply.text, 'bot', reply.actions || []);
    }, delay);
}

function botReply(raw) {
    const t = normalize(raw);
    const has = (...words) => words.some(w => t.includes(normalize(w)));
    const first = state.user ? ' ' + esc(state.user.name.split(' ')[0]) : '';

    if (has('طوارئ', 'اسعاف', 'نزيف', 'اختناق', 'فقدان الوعي', 'الم شديد')) {
        return { text: '⚠️ إذا كانت حالتك <b>طارئة</b> فلا تنتظر الحجز — اتصل بالإسعاف فوراً أو توجّه إلى أقرب قسم طوارئ.' };
    }
    if (has('شكرا', 'تسلم', 'ممنون', 'مشكور', 'عاشت ايدك')) {
        return { text: `العفو${first}! 😊 سعيد بمساعدتك. هل تحتاج شيئاً آخر؟` };
    }
    if (has('السلام', 'مرحبا', 'هلا', 'اهلا', 'صباح', 'مساء', 'شلونك', 'هلو', 'هاي')) {
        return {
            text: `أهلاً وسهلاً${first}! 👋 أنا <b>نجيب</b>، مساعدك في العيادة الذكية. كيف يمكنني مساعدتك اليوم؟`,
            actions: [
                { label: '📅 حجز موعد', attr: 'data-go="booking"' },
                { label: '🔍 البحث عن طبيب', attr: 'data-go="doctors"' }
            ]
        };
    }
    if (has('الغاء', 'الغي', 'الغيت', 'كنسل')) {
        return {
            text: 'لإلغاء موعد: اذهب إلى <b>مواعيدي</b> ← المواعيد القادمة ← اضغط «إلغاء الموعد».<br><small>يمكن الإلغاء فقط قبل ساعتين على الأقل من وقت الموعد، ويُسترد المبلغ إذا كان مدفوعاً.</small>',
            actions: [{ label: 'فتح مواعيدي', attr: 'data-go="appointments"' }]
        };
    }
    if (has('دور', 'طابور', 'انتظار', 'رقمي')) {
        const today = state.appointments.find(a => a.date === todayISO() && a.status !== 'cancelled');
        if (today) {
            const s = ensureSim(today);
            const d = getDoctor(today.doctorId);
            const info = s.status === 'waiting'
                ? `أمامك <b>${s.ahead}</b> ${s.ahead === 1 ? 'مريض' : 'مرضى'}، ووقت الانتظار المتوقع ${waitText(s)}.`
                : `الحالة الآن: <b>${Q_STATUS[s.status].label}</b>.`;
            return {
                text: `رقم دورك اليوم هو <b>${today.queueNo}</b> مع ${d.name}. ${info}`,
                actions: [{ label: '🎫 فتح متابعة الدور', attr: `data-queue="${today.id}"` }]
            };
        }
        return {
            text: 'لا يوجد لديك موعد اليوم. متابعة الدور تعمل بشكل مباشر في يوم الموعد فقط.',
            actions: [{ label: 'حجز موعد', attr: 'data-go="booking"' }, { label: 'متابعة الدور', attr: 'data-go="queue"' }]
        };
    }
    if (has('اجور', 'سعر', 'اسعار', 'كلفه', 'تكلفه', 'فلوس', 'دفع', 'كم')) {
        const all = DOCTORS.flatMap(d => d.clinics.map(c => c.fee));
        return {
            text: `أجور المعاينة تختلف حسب الطبيب والعيادة، وتتراوح بين <b>${fmtMoney(Math.min(...all))}</b> و <b>${fmtMoney(Math.max(...all))}</b>.<br>طرق الدفع المتاحة: نقداً في العيادة، بطاقة مصرفية، أو محفظة إلكترونية.`,
            actions: [{ label: 'عرض الأطباء والأجور', attr: 'data-go="doctors"' }]
        };
    }
    if (has('مواعيدي', 'موعدي') && !has('احجز', 'حجز')) {
        const up = state.appointments.filter(isUpcoming);
        return {
            text: up.length
                ? `لديك <b>${up.length}</b> ${up.length === 1 ? 'موعد قادم' : 'مواعيد قادمة'}، أقربها ${relDay(up.sort((a, b) => apptDateTime(a) - apptDateTime(b))[0].date)}.`
                : 'لا توجد لديك مواعيد قادمة حالياً.',
            actions: [{ label: 'فتح مواعيدي', attr: 'data-go="appointments"' }]
        };
    }

    // اقتراح اختصاص حسب الأعراض
    for (const [key, words] of Object.entries(KEYWORDS)) {
        if (has(...words) || has(SPECIALTIES[key].name)) {
            const sp = SPECIALTIES[key];
            const docs = DOCTORS.filter(d => d.specialty === key).slice(0, 2);
            return {
                text: `يبدو أنك تحتاج إلى اختصاص <b>${sp.name}</b>. الأطباء المتاحون:<br>` +
                    docs.map(d => `• ${d.name} — ${feeRange(d)}`).join('<br>') +
                    '<br><small>هذا اقتراح تجريبي وليس تشخيصاً طبياً.</small>',
                actions: [
                    ...docs.map(d => ({ label: `احجز مع ${d.name}`, attr: `data-book="${d.id}"` })),
                    { label: 'عرض كل أطباء الاختصاص', attr: `data-specialty="${key}"` }
                ]
            };
        }
    }

    if (has('حجز', 'احجز', 'موعد')) {
        return {
            text: 'الحجز سهل جداً 👌<br>1. اختر الطبيب والعيادة<br>2. اختر المريض (أنت أو فرد من عائلتك)<br>3. حدّد التاريخ والوقت<br>4. اختر طريقة الدفع وأكّد الحجز',
            actions: [{ label: '📅 ابدأ الحجز الآن', attr: 'data-go="booking"' }]
        };
    }
    if (has('طبيب', 'دكتور', 'اطباء', 'دكتوره', 'اختصاص')) {
        return {
            text: `لدينا <b>${DOCTORS.length}</b> أطباء في ${Object.keys(SPECIALTIES).length} اختصاصات. يمكنك البحث بالاسم أو الاختصاص أو المدينة أو العيادة. أخبرني بالأعراض وسأقترح لك الاختصاص المناسب.`,
            actions: [{ label: '🔍 البحث عن طبيب', attr: 'data-go="doctors"' }]
        };
    }
    if (has('عائله', 'افراد', 'اضافه فرد')) {
        return {
            text: 'يمكنك إضافة أفراد عائلتك وتعديل بياناتهم من <b>الملف الشخصي</b>، ثم الحجز لهم مباشرة.',
            actions: [{ label: 'الملف الشخصي', attr: 'data-go="profile"' }]
        };
    }
    if (has('حساب', 'تسجيل', 'دخول', 'كلمه المرور')) {
        return state.user
            ? { text: `أنت مسجّل الدخول باسم <b>${esc(state.user.name)}</b> ✅`, actions: [{ label: 'الملف الشخصي', attr: 'data-go="profile"' }] }
            : { text: 'يمكنك تسجيل الدخول أو إنشاء حساب جديد مجاناً.', actions: [{ label: 'تسجيل الدخول', attr: 'data-auth="login"' }, { label: 'إنشاء حساب', attr: 'data-auth="register"' }] };
    }
    if (has('دوام', 'اوقات', 'متى', 'ساعات', 'يفتح')) {
        return {
            text: 'أوقات الدوام تختلف من طبيب لآخر. افتح «معلومات الطبيب» في صفحة الأطباء لرؤية أيام وساعات الدوام والمواعيد المتاحة.',
            actions: [{ label: 'صفحة الأطباء', attr: 'data-go="doctors"' }]
        };
    }

    return {
        text: 'عذراً، لم أفهم سؤالك تماماً 🤔<br>جرّب أن تسألني عن: حجز موعد، الأطباء، أجور المعاينة، متابعة الدور، أو اكتب الأعراض التي تشعر بها.',
        actions: [
            { label: 'حجز موعد', attr: 'data-go="booking"' },
            { label: 'الأطباء', attr: 'data-go="doctors"' }
        ]
    };
}

function sendChat(text) {
    text = text.trim();
    if (!text) return;
    addMsg(esc(text), 'user');
    botSay(botReply(text));
}

function toggleChat(open) {
    const box = $('#chatbox');
    const o = typeof open === 'boolean' ? open : !box.classList.contains('open');
    box.classList.toggle('open', o);
    box.setAttribute('aria-hidden', String(!o));
    $('#chatToggle').classList.toggle('active', o);
    if (o) {
        const ping = $('#chatToggle .chat-ping');
        if (ping) ping.remove();
        if (!state.chatStarted) {
            state.chatStarted = true;
            botSay({
                text: `مرحباً${state.user ? ' ' + esc(state.user.name.split(' ')[0]) : ''}! 👋 أنا <b>نجيب</b> 🤖<br>مساعدك الذكي في العيادة الذكية. أستطيع مساعدتك في البحث عن طبيب، حجز موعد، ومتابعة دورك.`
            });
        }
        if (window.innerWidth > 680) setTimeout(() => $('#chatInput').focus(), 350);
    }
}

function initChat() {
    $('#chatToggle').addEventListener('click', () => toggleChat());
    $('#chatClose').addEventListener('click', () => toggleChat(false));

    $('#chatForm').addEventListener('submit', e => {
        e.preventDefault();
        const input = $('#chatInput');
        sendChat(input.value);
        input.value = '';
    });

    $('#quickReplies').addEventListener('click', e => {
        const b = e.target.closest('[data-q]');
        if (b) sendChat(b.dataset.q);
    });

    // على الهاتف: إغلاق المحادثة عند الانتقال لصفحة
    $('#chatMessages').addEventListener('click', e => {
        if (e.target.closest('.msg-action') && window.innerWidth <= 680) toggleChat(false);
    });
}


/* =================== معالج النقرات العام =================== */
document.addEventListener('click', e => {
    const el = e.target.closest('[data-page], [data-go], [data-specialty], [data-book], [data-details], [data-auth], [data-queue]');
    if (!el) return;

    if (el.dataset.page || el.dataset.go) {
        e.preventDefault();
        go(el.dataset.page || el.dataset.go);
    } else if (el.dataset.specialty) {
        state.filters = { q: '', spec: el.dataset.specialty, city: '', clinic: '' };
        go('doctors');
    } else if (el.dataset.book) {
        closeModal();
        startBooking(el.dataset.book);
    } else if (el.dataset.details) {
        openDoctor(el.dataset.details);
    } else if (el.dataset.auth) {
        openAuth(el.dataset.auth);
    } else if (el.dataset.queue) {
        state.queueSelected = el.dataset.queue;
        go('queue');
    }
});


/* =================== التشغيل =================== */
function init() {
    renderHeroCard();
    renderSpecialties();
    renderSuggested();
    initFilters();
    initBookingUI();
    initAppointmentsUI();
    initQueueUI();
    initProfileUI();
    initChat();
    initModal();
    updateHeader();
    resetBooking();

    // زر الحساب في الأعلى
    $('#profileBtn').addEventListener('click', () => state.user ? go('profile') : openAuth('login'));

    // قائمة الهاتف
    $('#menuToggle').addEventListener('click', e => {
        e.stopPropagation();
        $('#mainNav').classList.toggle('open');
        $('#menuToggle').classList.toggle('open');
    });
    document.addEventListener('click', e => {
        if (!e.target.closest('#mainNav, #menuToggle')) closeMenu();
    });

    // ظل الشريط العلوي عند التمرير
    window.addEventListener('scroll', () => {
        $('#topbar').classList.toggle('scrolled', window.scrollY > 10);
    }, { passive: true });

    // زر Esc
    document.addEventListener('keydown', e => {
        if (e.key !== 'Escape') return;
        if ($('#modal').classList.contains('open')) closeModal();
        else if ($('#chatbox').classList.contains('open')) toggleChat(false);
    });

    window.addEventListener('resize', moveIndicator);
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(moveIndicator);

    // فتح الصفحة من الرابط (#doctors مثلاً)
    const start = location.hash.replace('#', '');
    if (PAGES.includes(start) && start !== 'home') go(start);
    else { onEnter.home(); observeReveals(); }

    moveIndicator();
    setInterval(clockTick, 1000);
}

function hideLoader() {
    const l = $('#pageLoader');
    if (l) l.classList.add('hide');
    moveIndicator();
}
window.addEventListener('load', () => setTimeout(hideLoader, 300));
setTimeout(hideLoader, 2500); // احتياط إذا تأخر تحميل الخط

init();

/* =========================================================
   العيادة الذكية — الواجهات المشتركة
   shared.js  (تسجيل الدخول، إنشاء حساب، 403، 404)
   ملاحظة: نظام دخول تجريبي يعتمد على localStorage فقط
   ========================================================= */
'use strict';

const $ = (sel, ctx = document) => ctx.querySelector(sel);
const $$ = (sel, ctx = document) => Array.from(ctx.querySelectorAll(sel));

/* =================== أدوات عامة =================== */
const store = {
    get(key, fallback, s = localStorage) {
        try { const v = s.getItem(key); return v ? JSON.parse(v) : fallback; } catch (e) { return fallback; }
    },
    set(key, value, s = localStorage) {
        try { s.setItem(key, JSON.stringify(value)); } catch (e) { /* تجاهل */ }
    },
    del(key) {
        try { localStorage.removeItem(key); sessionStorage.removeItem(key); } catch (e) { /* تجاهل */ }
    }
};

const isEmail = v => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
const isPhone = v => /^07\d{9}$/.test(v.replace(/\s/g, ''));
const params = new URLSearchParams(location.search);

// تشفير بسيط لكلمة المرور (للتجربة فقط — التشفير الحقيقي يكون في الباك إند)
const hashPass = s => { let h = 5381; for (const c of s) h = ((h << 5) + h + c.charCodeAt(0)) >>> 0; return h.toString(16); };

function toast(msg, type = 'success') {
    const icons = { success: '✓', error: '!', info: 'i' };
    const el = document.createElement('div');
    el.className = `toast ${type}`;
    el.innerHTML = `<span class="toast-icon">${icons[type] || 'i'}</span><span>${msg}</span>`;
    $('#toastStack').appendChild(el);
    requestAnimationFrame(() => requestAnimationFrame(() => el.classList.add('show')));
    setTimeout(() => { el.classList.remove('show'); setTimeout(() => el.remove(), 500); }, 3200);
}

function shake(el) { if (!el) return; el.classList.remove('shake'); void el.offsetWidth; el.classList.add('shake'); }
function setLoading(btn, on) { btn.classList.toggle('loading', on); btn.disabled = on; }

function setError(input, msg) {
    const g = input && input.closest('.form-group');
    if (!g) return !msg;
    g.classList.toggle('has-error', !!msg);
    g.classList.toggle('valid', !msg && !!input.value);
    const e = $('.error-text', g);
    if (e) e.textContent = msg || '';
    return !msg;
}

function showAlert(el, msg, type = '') {
    el.hidden = false;
    el.className = 'form-alert ' + type;
    el.innerHTML = `<span>${msg}</span>`;
}

// إظهار/إخفاء كلمة المرور
document.addEventListener('click', e => {
    const t = e.target.closest('[data-toggle]');
    if (!t) return;
    const input = document.getElementById(t.dataset.toggle);
    input.type = input.type === 'password' ? 'text' : 'password';
    t.textContent = input.type === 'password' ? '👁' : '🙈';
});

// تأثير الموجة
document.addEventListener('pointerdown', e => {
    const b = e.target.closest('.btn');
    if (!b || b.disabled) return;
    const r = b.getBoundingClientRect();
    const size = Math.max(r.width, r.height);
    const s = document.createElement('span');
    s.className = 'ripple';
    s.style.width = s.style.height = size + 'px';
    s.style.left = (e.clientX - r.left - size / 2) + 'px';
    s.style.top = (e.clientY - r.top - size / 2) + 'px';
    b.appendChild(s);
    setTimeout(() => s.remove(), 650);
});

function hideLoader() { const l = $('#pageLoader'); if (l) l.classList.add('hide'); }
window.addEventListener('load', () => setTimeout(hideLoader, 300));
setTimeout(hideLoader, 2500);

function leaveTo(url) {
    const page = $('#authPage');
    if (page) page.classList.add('leaving');
    setTimeout(() => { location.href = url; }, 520);
}


/* =================== الحسابات والجلسات =================== */
const ROLES = {
    patient: {
        label: 'مريض', email: 'patient@smartclinic.iq',
        target: '../Patient Interface/index.html',
        eyebrow: 'بوابة المرضى', title: 'رعاية أفضل.<br>انتظار أقل.',
        text: 'سجّل دخولك لإدارة مواعيدك ومواعيد عائلتك ومتابعة دورك.',
        features: [['📅', 'حجز المواعيد بسهولة'], ['🎫', 'متابعة الدور مباشرة'], ['👨‍👩‍👧', 'إدارة أفراد العائلة']]
    },
    doctor: {
        label: 'طبيب', email: 'doctor@smartclinic.iq',
        target: '../Doctor Dashboard/doctor-dashboard.html',
        eyebrow: 'بوابة الأطباء', title: 'نظّم عيادتك.<br>وركّز على مرضاك.',
        text: 'إدارة المواعيد والطابور والاستشارات والمدفوعات من مكان واحد.',
        features: [['📅', 'جدول مواعيد ذكي'], ['🩺', 'استشارة مع مؤقت ووصفة'], ['📊', 'تقارير ومدفوعات']]
    },
    admin: {
        label: 'إدارة', email: 'admin@smartclinic.iq',
        target: '../Admin Dashboard/admin-dashboard.html',
        eyebrow: 'لوحة الإدارة', title: 'تحكم كامل.<br>بنظرة واحدة.',
        text: 'إدارة الأطباء والمستخدمين والمواعيد والمدفوعات وسجل العمليات.',
        features: [['✅', 'الموافقة على الأطباء'], ['👥', 'إدارة المستخدمين'], ['🧾', 'سجل العمليات']]
    }
};
const DEMO_PASS = '123456';

function makePatientProfile({ name, email, phone = '', gender = '', city = 'بغداد', birth = '' }) {
    return {
        name, email: email.toLowerCase(), phone, gender, city, birth,
        patientId: 'P-' + (10000 + Math.floor(Math.random() * 89999)),
        joined: new Date().toISOString().slice(0, 10)
    };
}

// إنشاء جلسة متوافقة مع كل واجهة من الواجهات السابقة
function startSession(role, email, remember, profile) {
    const s = remember ? localStorage : sessionStorage;
    store.set('smartClinic_role', role);

    if (role === 'patient') {
        const accounts = store.get('smartClinic_accounts', {});
        const p = profile || accounts[email] || makePatientProfile({ name: 'مريض تجريبي', email });
        accounts[p.email] = p;
        store.set('smartClinic_accounts', accounts);
        store.set('smartClinic_user', p);
        return p.name;
    }
    if (role === 'doctor') {
        store.set('scDoctor_session', { email, at: Date.now() }, s);
        return 'د. سارة أحمد';
    }
    store.set('scAdmin_session', { name: 'أ. علي الربيعي', email, role: 'admin', at: Date.now(), fresh: true }, s);
    return 'أ. علي الربيعي';
}


/* =================== صفحة تسجيل الدخول =================== */
function initLogin() {
    let role = ROLES[params.get('role')] ? params.get('role') : 'patient';
    let fails = 0, lockUntil = 0;
    const form = $('#loginForm'), email = $('#email'), pass = $('#password'), alertEl = $('#loginAlert');

    function setRole(r, animate = true) {
        role = r;
        const i = Object.keys(ROLES).indexOf(r);
        $('#roleInd').style.transform = `translateX(${-i * 100}%) translateX(${-i * 4}px)`;
        $$('.role-btn').forEach(b => b.classList.toggle('active', b.dataset.role === r));
        const R = ROLES[r];
        $('#demoRole').textContent = R.label;
        $('#demoEmail').textContent = R.email;
        $('#registerLink').style.visibility = r === 'patient' ? 'visible' : 'hidden';
        $('#authBrand').classList.toggle('purple', r === 'admin');

        const content = $('.auth-brand-content');
        if (animate) { content.style.animation = 'none'; void content.offsetWidth; content.style.animation = 'cardIn .6s var(--ease)'; }
        $('#brandEyebrow').textContent = R.eyebrow;
        $('#brandTitle').innerHTML = R.title;
        $('#brandText').textContent = R.text;
        $('#brandFeatures').innerHTML = R.features.map(([ic, t]) => `<li><span>${ic}</span> ${t}</li>`).join('');
        alertEl.hidden = true;
    }

    $('#rolePicker').addEventListener('click', e => {
        const b = e.target.closest('[data-role]');
        if (b) setRole(b.dataset.role);
    });
    setRole(role, false);

    if (params.get('denied')) showAlert(alertEl, '🔐 انتهت الجلسة أو تحتاج لتسجيل الدخول للمتابعة.', 'info');
    if (params.get('logout')) showAlert(alertEl, '👋 تم تسجيل الخروج بنجاح.', 'success');

    $('#fillDemo').addEventListener('click', () => {
        email.value = ROLES[role].email;
        pass.value = DEMO_PASS;
        setError(email, ''); setError(pass, '');
        toast('تمت تعبئة بيانات الحساب التجريبي', 'info');
    });
    $('#forgotBtn').addEventListener('click', () =>
        showAlert(alertEl, 'ℹ️ تم إرسال رابط إعادة تعيين كلمة المرور إلى بريدك (تجريبي).', 'info'));
    [email, pass].forEach(i => i.addEventListener('input', () => setError(i, '')));

    form.addEventListener('submit', e => {
        e.preventDefault();
        if (Date.now() < lockUntil) return;

        const ev = email.value.trim().toLowerCase(), pv = pass.value;
        let ok = true;
        if (!ev) ok = setError(email, 'البريد الإلكتروني مطلوب') && ok;
        else if (!isEmail(ev)) ok = setError(email, 'صيغة البريد الإلكتروني غير صحيحة') && ok;
        else setError(email, '');
        if (!pv) ok = setError(pass, 'كلمة المرور مطلوبة') && ok;
        else if (pv.length < 6) ok = setError(pass, 'كلمة المرور 6 أحرف على الأقل') && ok;
        else setError(pass, '');
        if (!ok) { alertEl.hidden = true; shake(form); return; }

        const btn = $('#loginBtn');
        setLoading(btn, true);

        setTimeout(() => {
            setLoading(btn, false);

            // التحقق من البيانات
            const registered = store.get('smartClinic_registered', {})[ev];
            let valid = false, profile = null;
            if (role === 'patient' && registered) {
                valid = registered.pass === hashPass(pv);
                profile = registered.profile;
            } else {
                valid = ev === ROLES[role].email && pv === DEMO_PASS;
            }

            if (!valid) {
                const otherRole = Object.keys(ROLES).find(r => r !== role && ROLES[r].email === ev);
                if (otherRole) {
                    showAlert(alertEl, `⚠️ هذا البريد تابع لحساب <b>${ROLES[otherRole].label}</b>. اختر نوع الحساب الصحيح.`);
                } else {
                    fails++;
                    if (fails >= 5) {
                        lockUntil = Date.now() + 30000;
                        btn.disabled = true;
                        const t = setInterval(() => {
                            const s = Math.ceil((lockUntil - Date.now()) / 1000);
                            if (s <= 0) {
                                clearInterval(t); btn.disabled = false; fails = 0;
                                showAlert(alertEl, 'يمكنك المحاولة مجدداً الآن.', 'info');
                                return;
                            }
                            showAlert(alertEl, `🔒 تم تجاوز عدد المحاولات. حاول بعد <b>${s}</b> ثانية.`);
                        }, 250);
                    } else {
                        showAlert(alertEl, `⚠️ البريد الإلكتروني أو كلمة المرور غير صحيحة. المحاولات المتبقية: <b>${5 - fails}</b>`);
                    }
                }
                shake(form);
                return;
            }

            const name = startSession(role, ev, $('#remember').checked, profile);
            showAlert(alertEl, `✓ أهلاً ${name}، جاري توجيهك...`, 'success');
            setLoading(btn, true);
            setTimeout(() => leaveTo(ROLES[role].target), 900);
        }, 900);
    });
}


/* =================== صفحة إنشاء حساب مريض =================== */
function initRegister() {
    let step = 1;
    const birth = $('#birth');
    const today = new Date();
    birth.max = today.toISOString().slice(0, 10);
    birth.min = '1900-01-01';

    function setStep(n) {
        const back = n < step;
        step = n;
        $$('.step-panel').forEach(p => {
            const active = Number(p.dataset.panel) === n;
            p.classList.toggle('active', active);
            p.classList.toggle('back', active && back);
        });
        $$('.step-item').forEach(s => {
            const i = Number(s.dataset.step);
            s.classList.toggle('current', i === n);
            s.classList.toggle('done', i < n);
            $('.step-circle', s).textContent = i < n ? '✓' : i;
        });
        $('.step-line').classList.toggle('done', n > 1);
    }

    function validateStep1() {
        let ok = true;
        const name = $('#fullName').value.trim();
        ok = setError($('#fullName'), name.split(/\s+/).length < 2 ? 'أدخل الاسم الثنائي على الأقل' : (/[0-9]/.test(name) ? 'الاسم لا يحتوي على أرقام' : '')) && ok;
        const g = $('input[name=gender]:checked');
        ok = setError($('#genderPick'), g ? '' : 'اختر الجنس') && ok;
        const b = birth.value;
        let msg = '';
        if (!b) msg = 'تاريخ الميلاد مطلوب';
        else if (new Date(b) > today) msg = 'تاريخ الميلاد لا يمكن أن يكون في المستقبل';
        else if (today.getFullYear() - new Date(b).getFullYear() > 120) msg = 'تاريخ ميلاد غير منطقي';
        ok = setError(birth, msg) && ok;
        ok = setError($('#city'), $('#city').value ? '' : 'اختر المدينة') && ok;
        return ok;
    }

    function passScore(p) {
        const rules = {
            len: p.length >= 8,
            num: /\d/.test(p),
            letter: /[a-zA-Z]/.test(p),
            special: /[^a-zA-Z0-9؀-ۿ]/.test(p)
        };
        $$('#passRules li').forEach(li => li.classList.toggle('ok', rules[li.dataset.rule]));
        return Object.values(rules).filter(Boolean).length;
    }

    $('#regPass').addEventListener('input', e => {
        const score = e.target.value ? passScore(e.target.value) : 0;
        const colors = ['#e8edf5', '#e5484d', '#f59e0b', '#12b5a5', '#16a34a'];
        const labels = ['قوة كلمة المرور', 'ضعيفة جداً', 'ضعيفة', 'جيدة', 'قوية 💪'];
        $$('#strength i').forEach((i, idx) => { i.style.background = idx < score ? colors[score] : colors[0]; });
        $('#strengthLabel').textContent = labels[score];
        $('#strengthLabel').style.color = score ? colors[score] : '';
        if (!e.target.value) $$('#passRules li').forEach(li => li.classList.remove('ok'));
    });

    $('#registerForm').addEventListener('input', e => {
        const g = e.target.closest('.form-group.has-error');
        if (g) setError(e.target.closest('.gender-pick') || e.target, '');
    });
    $('#registerForm').addEventListener('change', e => {
        if (e.target.name === 'gender') setError($('#genderPick'), '');
        if (e.target.id === 'terms' && e.target.checked) setError(e.target, '');
    });

    $('#toStep2').addEventListener('click', () => {
        if (!validateStep1()) { shake($('.step-panel.active')); toast('أكمل المعلومات المطلوبة', 'error'); return; }
        setStep(2);
        setTimeout(() => $('#phone').focus(), 300);
    });
    $('#backStep1').addEventListener('click', () => setStep(1));

    $('#registerForm').addEventListener('submit', e => {
        e.preventDefault();
        if (step === 1) { $('#toStep2').click(); return; }

        const phone = $('#phone').value.trim();
        const email = $('#regEmail').value.trim().toLowerCase();
        const pass = $('#regPass').value, confirm = $('#regConfirm').value;
        const registered = store.get('smartClinic_registered', {});
        let ok = true;

        ok = setError($('#phone'), !phone ? 'رقم الهاتف مطلوب' : (!isPhone(phone) ? 'يجب أن يبدأ بـ 07 ويتكون من 11 رقماً' : '')) && ok;
        let emailMsg = '';
        if (!email) emailMsg = 'البريد الإلكتروني مطلوب';
        else if (!isEmail(email)) emailMsg = 'صيغة البريد الإلكتروني غير صحيحة';
        else if (registered[email] || Object.values(ROLES).some(r => r.email === email)) emailMsg = 'هذا البريد مسجل مسبقاً، جرّب تسجيل الدخول';
        ok = setError($('#regEmail'), emailMsg) && ok;
        ok = setError($('#regPass'), pass.length < 8 ? 'كلمة المرور 8 أحرف على الأقل' : (passScore(pass) < 3 ? 'كلمة المرور ضعيفة، أضف أرقاماً وحروفاً' : '')) && ok;
        ok = setError($('#regConfirm'), !confirm ? 'أعد كتابة كلمة المرور' : (confirm !== pass ? 'كلمتا المرور غير متطابقتين' : '')) && ok;
        ok = setError($('#terms'), $('#terms').checked ? '' : 'يجب الموافقة على الشروط للمتابعة') && ok;

        if (!ok) { shake($('.step-panel.active')); return; }

        const btn = $('#registerBtn');
        setLoading(btn, true);
        setTimeout(() => {
            const profile = makePatientProfile({
                name: $('#fullName').value.trim(), email, phone,
                gender: $('input[name=gender]:checked').value,
                city: $('#city').value, birth: birth.value
            });
            registered[email] = { profile, pass: hashPass(pass) };
            store.set('smartClinic_registered', registered);
            startSession('patient', email, true, profile);

            $('#registerSteps').hidden = true;
            const s = $('#regSuccess');
            s.hidden = false;
            s.innerHTML = `
                <svg class="check-svg" viewBox="0 0 52 52">
                    <circle class="check-circle" cx="26" cy="26" r="24"></circle>
                    <path class="check-path" d="M15 27l7 7 15-16"></path>
                </svg>
                <h2>تم إنشاء حسابك بنجاح! 🎉</h2>
                <p class="muted">أهلاً ${profile.name.split(' ')[0]}، رقمك كمريض في النظام:</p>
                <div class="id-chip">${profile.patientId}</div>
                <div class="redirect-bar"><i id="redirectBar"></i></div>
                <p class="muted small" id="redirectText">سيتم توجيهك إلى واجهة المريض خلال 4 ثوانٍ...</p>
                <a href="${ROLES.patient.target}" class="btn primary block" style="margin-top:12px">الانتقال الآن ←</a>`;
            toast('تم إنشاء الحساب بنجاح', 'success');
            requestAnimationFrame(() => requestAnimationFrame(() => { $('#redirectBar').style.width = '100%'; }));
            let left = 4;
            const t = setInterval(() => {
                left--;
                if (left <= 0) { clearInterval(t); leaveTo(ROLES.patient.target); return; }
                $('#redirectText').textContent = `سيتم توجيهك إلى واجهة المريض خلال ${left} ثوانٍ...`;
            }, 1000);
        }, 1100);
    });
}


/* =================== صفحات الأخطاء =================== */
function initErrorPage(code) {
    $('#goBack').addEventListener('click', () => {
        if (history.length > 1) history.back();
        else location.href = '../Patient Interface/index.html';
    });

    const from = params.get('from');
    const path = params.get('path');
    if (code === '403') {
        if (from) {
            const label = { admin: 'لوحة الإدارة', doctor: 'لوحة الطبيب' }[from] || 'هذه الصفحة';
            $('#deniedText').textContent = `حسابك الحالي لا يملك صلاحية الوصول إلى ${label}. سجّل الدخول بحساب يملك الصلاحية المناسبة.`;
            $('#switchAccount').href = `login.html?role=${from}`;
        }
        $('#errorMeta').textContent = `Error 403 · Forbidden${from ? ' · /' + from : ''}`;
    }
    if (code === '404' && path) {
        $('#errorMeta').textContent = `Error 404 · Not Found · ${path}`;
    }
}



/* =================== تسجيل عيادة جديدة =================== */
const CLINIC_REQ_KEY = 'smartClinic_clinicRequests';
const CLINIC_SPECS = ['أمراض القلب', 'طب الأطفال', 'الأمراض الجلدية', 'طب الأعصاب', 'طب الأسرة', 'طب الأسنان', 'طب العيون', 'العظام والمفاصل', 'النسائية والتوليد', 'الباطنية'];
const WEEK = [[6, 'السبت'], [0, 'الأحد'], [1, 'الإثنين'], [2, 'الثلاثاء'], [3, 'الأربعاء'], [4, 'الخميس'], [5, 'الجمعة']];
const CLINIC_DOCS = [
    { key: 'license', name: 'رخصة وزارة الصحة', required: true, icon: '📜' },
    { key: 'commercial', name: 'السجل التجاري', required: true, icon: '🏢' },
    { key: 'managerId', name: 'هوية مدير العيادة', required: true, icon: '🪪' },
    { key: 'lease', name: 'عقد الإيجار أو سند الملكية', required: true, icon: '📄' }
];
const fmt12 = t => { let [h, m] = t.split(':').map(Number); const s = h >= 12 ? 'م' : 'ص'; h = h % 12 || 12; return `${h}:${String(m).padStart(2, '0')} ${s}`; };

// حالة طلب العيادة كما سجّلتها لوحة الإدارة
function clinicRequestStatus(req) {
    const admin = store.get('scAdmin_data', null);
    const c = admin && admin.clinics ? admin.clinics.find(x => x.reqId === req.reqId) : null;
    return {
        status: c ? c.status : 'pending',
        manager: c ? c.manager.status : 'inactive',
        reason: c ? c.reason : '',
        seen: !!c
    };
}

function statusTrackHTML(req) {
    const s = clinicRequestStatus(req);
    const rows = [
        ['done', '✓', 'تم إرسال الطلب'],
        s.status === 'pending' ? ['now', '⏳', s.seen ? 'قيد المراجعة من إدارة النظام' : 'بانتظار استلام الطلب من الإدارة']
            : ['done', '✓', 'تمت المراجعة'],
        s.status === 'approved' ? ['done', '✓', 'تم قبول العيادة']
            : s.status === 'rejected' ? ['bad', '✕', `تم رفض الطلب${s.reason ? ': ' + s.reason : ''}`]
            : ['', '3', 'قرار القبول أو الرفض'],
        s.status === 'approved' && s.manager === 'active' ? ['done', '✓', 'تم تفعيل حساب مدير العيادة — يمكنك الدخول الآن']
            : s.status === 'approved' && s.manager === 'disabled' ? ['bad', '✕', 'حساب مدير العيادة معطّل']
            : s.status === 'approved' ? ['now', '⏳', 'بانتظار تفعيل حساب المدير'] : ['', '4', 'تفعيل حساب مدير العيادة']
    ];
    return `<div class="status-track">${rows.map(([c, i, t]) => `<div class="${c}"><i>${i}</i>${t}</div>`).join('')}</div>`;
}

function initClinicRegister() {
    let step = 1;
    const files = {};
    const TOTAL = 5;

    $('#specPick').innerHTML = CLINIC_SPECS.map(s => `<label><input type="checkbox" name="spec" value="${s}">${s}</label>`).join('');
    $('#dayPick').innerHTML = WEEK.map(([d, n]) => `<label><input type="checkbox" name="day" value="${d}" ${d !== 5 ? 'checked' : ''}>${n}</label>`).join('');
    $('#uploadList').innerHTML = CLINIC_DOCS.map((d, i) => `
        <div class="upload-item" data-doc="${d.key}" style="animation-delay:${i * 60}ms">
            <span class="u-icon">${d.icon}</span>
            <div class="u-info">
                <strong>${d.name} ${d.required ? '<span class="req">*</span>' : '<small>(اختياري)</small>'}</strong>
                <small class="u-name">لم يتم اختيار ملف</small>
                <div class="u-bar"><i></i></div>
            </div>
            <input type="file" id="file-${d.key}" accept=".pdf,.jpg,.jpeg,.png">
            <button type="button" class="btn light sm" data-pick="${d.key}">📎 اختيار ملف</button>
        </div>`).join('');

    // معاينة أيام الدوام
    function renderHours() {
        const days = $$('input[name=day]:checked').map(i => Number(i.value));
        const from = $('#hFrom').value, to = $('#hTo').value;
        $('#hoursPreview').innerHTML = WEEK.map(([d, n]) => `<div class="${days.includes(d) ? 'on' : ''}"><b>${n}</b>${days.includes(d) && from && to ? `${fmt12(from)}<br>${fmt12(to)}` : 'عطلة'}</div>`).join('');
    }
    renderHours();
    $('#dayPick').addEventListener('change', () => { renderHours(); setError($('#dayPick'), ''); });
    $('#hFrom').addEventListener('input', renderHours);
    $('#hTo').addEventListener('input', () => { renderHours(); setError($('#hTo'), ''); });
    $('#specPick').addEventListener('change', () => setError($('#specPick'), ''));

    // رفع الوثائق
    $('#uploadList').addEventListener('click', e => {
        const b = e.target.closest('[data-pick]');
        if (b) $(`#file-${b.dataset.pick}`).click();
    });
    $('#uploadList').addEventListener('change', e => {
        const input = e.target;
        const item = input.closest('.upload-item');
        const key = item.dataset.doc;
        const f = input.files[0];
        if (!f) return;
        const okType = /\.(pdf|jpe?g|png)$/i.test(f.name);
        const okSize = f.size <= 5 * 1024 * 1024;
        item.classList.remove('done', 'bad');
        if (!okType || !okSize) {
            delete files[key];
            item.classList.add('bad');
            $('.u-name', item).textContent = !okType ? '✕ صيغة غير مدعومة — PDF أو JPG أو PNG فقط' : '✕ حجم الملف أكبر من 5 ميغابايت';
            $('.u-bar i', item).style.width = '0';
            shake(item);
            return;
        }
        files[key] = { name: f.name, size: f.size };
        $('.u-name', item).textContent = `جارٍ الرفع... ${f.name}`;
        const bar = $('.u-bar i', item);
        bar.style.width = '0';
        requestAnimationFrame(() => requestAnimationFrame(() => { bar.style.width = '100%'; }));
        setTimeout(() => {
            item.classList.add('done');
            $('.u-name', item).textContent = `✓ ${f.name} · ${(f.size / 1024).toFixed(0)} KB`;
            $('[data-pick]', item).textContent = '🔄 تغيير';
            $('#docsError').textContent = '';
        }, 900);
    });

    // قوة كلمة المرور
    $('#mPass').addEventListener('input', e => {
        const p = e.target.value;
        const score = p ? [p.length >= 8, /\d/.test(p), /[a-zA-Z]/.test(p), /[^a-zA-Z0-9؀-ۿ]/.test(p)].filter(Boolean).length : 0;
        const colors = ['#e8edf5', '#e5484d', '#f59e0b', '#12b5a5', '#16a34a'];
        $$('#strength i').forEach((i, idx) => { i.style.background = idx < score ? colors[score] : colors[0]; });
        $('#strengthLabel').textContent = ['قوة كلمة المرور', 'ضعيفة جداً', 'ضعيفة', 'جيدة', 'قوية 💪'][score];
    });
    $('#clinicForm').addEventListener('input', e => { if (e.target.closest('.form-group.has-error') && e.target.classList.contains('field')) setError(e.target, ''); });

    const requests = () => store.get(CLINIC_REQ_KEY, []);
    const takenEmails = () => {
        const admin = store.get('scAdmin_data', null);
        return [
            'manager@karrada-clinic.iq', 'reception@karrada-clinic.iq', ...Object.values(ROLES).map(r => r.email),
            ...requests().map(r => r.manager.email),
            ...(admin && admin.clinics ? admin.clinics.map(c => c.manager.email) : [])
        ].map(x => String(x).toLowerCase());
    };

    function validate(n) {
        let ok = true;
        const v = id => $(id).value.trim();
        if (n === 1) {
            ok = setError($('#cName'), v('#cName').length < 3 ? 'اكتب اسم العيادة' : '') && ok;
            ok = setError($('#cType'), v('#cType') ? '' : 'اختر نوع المنشأة') && ok;
            ok = setError($('#cLicense'), /^[A-Za-z]{2,4}-?[A-Za-z]{0,3}-?\d{4,8}$/.test(v('#cLicense')) ? '' : 'صيغة الترخيص غير صحيحة (مثال: MOH-CL-12345)') && ok;
            ok = setError($('#cCity'), v('#cCity') ? '' : 'اختر المدينة') && ok;
            const rooms = Number(v('#cRooms'));
            ok = setError($('#cRooms'), Number.isInteger(rooms) && rooms >= 1 && rooms <= 50 ? '' : 'من 1 إلى 50') && ok;
            ok = setError($('#cAddress'), v('#cAddress').length < 6 ? 'اكتب العنوان بالتفصيل' : '') && ok;
            ok = setError($('#cPhone'), isPhone(v('#cPhone')) ? '' : 'رقم يبدأ بـ 07 ويتكون من 11 رقماً') && ok;
            ok = setError($('#cEmail'), isEmail(v('#cEmail')) ? '' : 'بريد إلكتروني غير صحيح') && ok;
            ok = setError($('#specPick'), $$('input[name=spec]:checked').length ? '' : 'اختر اختصاصاً واحداً على الأقل') && ok;
        }
        if (n === 2) {
            ok = setError($('#dayPick'), $$('input[name=day]:checked').length ? '' : 'اختر يوم عمل واحداً على الأقل') && ok;
            const f = $('#hFrom').value, t = $('#hTo').value;
            ok = setError($('#hTo'), !f || !t ? 'حدد أوقات العمل' : f >= t ? 'وقت الإغلاق يجب أن يكون بعد الفتح' : '') && ok;
        }
        if (n === 3) {
            const email = v('#mEmail').toLowerCase(), pass = $('#mPass').value;
            ok = setError($('#mName'), v('#mName').split(/\s+/).length < 2 ? 'أدخل الاسم الثنائي على الأقل' : '') && ok;
            ok = setError($('#mPhone'), isPhone(v('#mPhone')) ? '' : 'رقم يبدأ بـ 07 ويتكون من 11 رقماً') && ok;
            ok = setError($('#mEmail'), !isEmail(email) ? 'بريد إلكتروني غير صحيح' : takenEmails().includes(email) ? 'هذا البريد مستخدم لحساب آخر' : '') && ok;
            ok = setError($('#mPass'), pass.length < 8 ? 'كلمة المرور 8 أحرف على الأقل' : !(/\d/.test(pass) && /[a-zA-Z]/.test(pass)) ? 'يجب أن تحتوي على حروف إنجليزية وأرقام' : '') && ok;
            ok = setError($('#mConfirm'), $('#mConfirm').value !== pass || !pass ? 'كلمتا المرور غير متطابقتين' : '') && ok;
        }
        if (n === 4) {
            const missing = CLINIC_DOCS.filter(d => d.required && !files[d.key]);
            $('#docsError').textContent = missing.length ? `يرجى رفع: ${missing.map(d => d.name).join('، ')}` : '';
            missing.forEach(d => { const it = $(`[data-doc="${d.key}"]`); it.classList.add('bad'); shake(it); });
            ok = !missing.length;
        }
        if (n === 5) ok = setError($('#cTerms'), $('#cTerms').checked ? '' : 'يجب الإقرار والموافقة للمتابعة');
        return ok;
    }

    function collect() {
        const days = $$('input[name=day]:checked').map(i => Number(i.value));
        return {
            name: $('#cName').value.trim(), type: $('#cType').value, license: $('#cLicense').value.trim().toUpperCase(),
            city: $('#cCity').value, rooms: Number($('#cRooms').value), address: $('#cAddress').value.trim(),
            phone: $('#cPhone').value.trim(), email: $('#cEmail').value.trim().toLowerCase(),
            specialties: $$('input[name=spec]:checked').map(i => i.value),
            hours: { days, from: $('#hFrom').value, to: $('#hTo').value },
            manager: { name: $('#mName').value.trim(), phone: $('#mPhone').value.trim(), email: $('#mEmail').value.trim().toLowerCase() },
            docs: CLINIC_DOCS.filter(d => files[d.key]).map(d => ({ name: d.name, file: files[d.key].name }))
        };
    }

    function renderReview() {
        const r = collect();
        const dayNames = WEEK.filter(([d]) => r.hours.days.includes(d)).map(([, n]) => n).join('، ');
        const sec = (title, goto, rows) => `
            <div class="review-sec">
                <header><strong>${title}</strong><button type="button" class="text-button small" data-goto="${goto}">✎ تعديل</button></header>
                <div class="review-grid">${rows.map(([k, v]) => `<div><span>${k}:</span> <b>${v}</b></div>`).join('')}</div>
            </div>`;
        $('#reviewBox').innerHTML =
            sec('🏥 بيانات العيادة', 1, [['الاسم', r.name], ['النوع', r.type], ['الترخيص', r.license], ['المدينة', r.city], ['العنوان', r.address], ['الهاتف', r.phone], ['البريد', r.email], ['الغرف', r.rooms], ['الاختصاصات', r.specialties.join('، ')]]) +
            sec('🕘 الدوام', 2, [['الأيام', dayNames], ['الساعات', `${fmt12(r.hours.from)} – ${fmt12(r.hours.to)}`]]) +
            sec('👤 مدير العيادة', 3, [['الاسم', r.manager.name], ['الهاتف', r.manager.phone], ['بريد الدخول', r.manager.email]]) +
            sec('📎 الوثائق', 4, r.docs.map(d => [d.name, '✓ ' + d.file]));
    }

    function setStep(n) {
        const back = n < step;
        step = n;
        $$('.step-panel').forEach(p => {
            const a = Number(p.dataset.panel) === n;
            p.classList.toggle('active', a);
            p.classList.toggle('back', a && back);
        });
        $$('.step-item').forEach(s => {
            const i = Number(s.dataset.step);
            s.classList.toggle('current', i === n);
            s.classList.toggle('done', i < n);
            $('.step-circle', s).textContent = i < n ? '✓' : i;
        });
        $$('.step-line').forEach((l, i) => l.classList.toggle('done', i + 1 < n));
        $('#prevBtn').style.visibility = n === 1 ? 'hidden' : 'visible';
        $('#nextBtn').innerHTML = n === TOTAL ? '📨 إرسال الطلب' : 'التالي ←';
        if (n === TOTAL) renderReview();
        $('#clinicForm').scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    setStep(1);

    $('#prevBtn').addEventListener('click', () => setStep(step - 1));
    $('#stepper').addEventListener('click', e => {
        const s = e.target.closest('.step-item');
        if (s && Number(s.dataset.step) < step) setStep(Number(s.dataset.step));
    });
    $('#reviewBox').addEventListener('click', e => {
        const g = e.target.closest('[data-goto]');
        if (g) setStep(Number(g.dataset.goto));
    });
    $('#cTerms').addEventListener('change', () => setError($('#cTerms'), ''));

    $('#nextBtn').addEventListener('click', () => {
        if (!validate(step)) { shake($('.step-panel.active')); toast('يرجى تصحيح الحقول المطلوبة', 'error'); return; }
        if (step < TOTAL) { setStep(step + 1); return; }

        const btn = $('#nextBtn');
        setLoading(btn, true);
        setTimeout(() => {
            const r = collect();
            const req = {
                reqId: 'REQ-' + Date.now().toString().slice(-6),
                ...r,
                manager: { ...r.manager, pass: hashPass($('#mPass').value) },
                submittedAt: new Date().toISOString().slice(0, 10),
                submittedTs: Date.now()
            };
            const list = requests();
            list.push(req);
            store.set(CLINIC_REQ_KEY, list);
            store.set('smartClinic_lastClinicReq', req.reqId);
            showSubmitted(req);
        }, 1200);
    });
    $('#clinicForm').addEventListener('submit', e => e.preventDefault());

    function showSubmitted(req) {
        $('#regSteps').hidden = true;
        const box = $('#regSuccess');
        box.hidden = false;
        box.innerHTML = `
            <svg class="check-svg" viewBox="0 0 52 52">
                <circle class="check-circle" cx="26" cy="26" r="24"></circle>
                <path class="check-path" d="M15 27l7 7 15-16"></path>
            </svg>
            <h2>تم إرسال طلب تسجيل العيادة 🎉</h2>
            <p class="muted">${req.name} · ${req.city}</p>
            <div class="id-chip">${req.reqId}</div>
            <p class="muted small">احتفظ برقم الطلب. سيتم إشعارك على <b dir="ltr">${req.manager.email}</b> عند قبول الطلب وتفعيل الحساب.</p>
            <div id="trackBox">${statusTrackHTML(req)}</div>
            <div class="form-actions">
                <button type="button" class="btn light" id="refreshStatus">🔄 تحديث حالة الطلب</button>
                <a href="../Clinic Dashboard/clinic-dashboard.html" class="btn primary">🔑 دخول العيادة</a>
            </div>`;
        $('#refreshStatus').addEventListener('click', () => {
            $('#trackBox').innerHTML = statusTrackHTML(req);
            toast('تم تحديث حالة الطلب', 'info');
        });
        toast('تم إرسال الطلب بنجاح', 'success');
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    // إذا فتح المستخدم الصفحة وعنده طلب سابق، يظهر رابط لمتابعته
    const last = requests().find(r => r.reqId === store.get('smartClinic_lastClinicReq', ''));
    if (last) {
        const note = document.createElement('div');
        note.className = 'form-alert info';
        note.innerHTML = `<span>📨 لديك طلب سابق (${last.reqId} · ${last.name}). <button type="button" class="text-button small" id="showLast">عرض حالته</button></span>`;
        $('#stepper').before(note);
        $('#showLast').addEventListener('click', () => showSubmitted(last));
    }
}


/* =================== التشغيل =================== */
const page = document.body.dataset.page;
if (page === 'login') initLogin();
if (page === 'register') initRegister();
if (page === 'clinic-register') initClinicRegister();
if (page === '403' || page === '404') initErrorPage(page);

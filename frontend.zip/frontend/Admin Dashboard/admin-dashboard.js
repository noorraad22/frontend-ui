/* =========================================================
   العيادة الذكية — لوحة الإدارة
   admin-dashboard.js
   ملاحظة: البيانات تجريبية وتُحفظ في المتصفح فقط (localStorage)
   الإدارة لا تصل إلى أي نصوص طبية أو تشخيصات.
   ========================================================= */
'use strict';

/* =================== أدوات مساعدة =================== */
const $ = (sel, ctx = document) => ctx.querySelector(sel);
const $$ = (sel, ctx = document) => Array.from(ctx.querySelectorAll(sel));

const pad = n => String(n).padStart(2, '0');
const toISO = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const addDays = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
const todayISO = () => toISO(new Date());
const parseISO = s => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); };
const fmtDate = (iso, opts = { day: 'numeric', month: 'short', year: 'numeric' }) =>
    new Intl.DateTimeFormat('ar-u-nu-latn', opts).format(parseISO(iso));
const fmtTime = t => {
    let [h, m] = t.split(':').map(Number);
    const s = h >= 12 ? 'م' : 'ص';
    h = h % 12 || 12;
    return `${pad(h)}:${pad(m)} ${s}`;
};
const fmtStamp = ts => new Intl.DateTimeFormat('ar-u-nu-latn', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }).format(new Date(ts));
const fmtMoney = n => Number(n || 0).toLocaleString('en-US') + ' د.ع';
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const normalize = s => String(s).replace(/[ً-ْـ]/g, '').replace(/[أإآ]/g, 'ا').replace(/ة/g, 'ه').replace(/ى/g, 'ي').toLowerCase();
const relDay = iso => {
    if (iso === todayISO()) return 'اليوم';
    if (iso === toISO(addDays(new Date(), 1))) return 'غداً';
    if (iso === toISO(addDays(new Date(), -1))) return 'أمس';
    return fmtDate(iso, { weekday: 'short', day: 'numeric', month: 'short' });
};
function timeAgo(t) {
    const m = Math.floor((Date.now() - t) / 60000);
    if (m < 1) return 'الآن';
    if (m < 60) return `منذ ${m} دقيقة`;
    const h = Math.floor(m / 60);
    return h < 24 ? `منذ ${h} ساعة` : `منذ ${Math.floor(h / 24)} يوم`;
}
function shake(el) { if (!el) return; el.classList.remove('shake'); void el.offsetWidth; el.classList.add('shake'); }
function setLoading(btn, on) { if (!btn) return; btn.classList.toggle('loading', on); btn.disabled = on; }

const rawGet = (k, s = localStorage) => { try { const v = s.getItem(k); return v ? JSON.parse(v) : null; } catch (e) { return null; } };
const rawSet = (k, v, s = localStorage) => { try { s.setItem(k, JSON.stringify(v)); } catch (e) { /* تجاهل */ } };
const rawDel = k => { try { localStorage.removeItem(k); sessionStorage.removeItem(k); } catch (e) { /* تجاهل */ } };


/* =================== الثوابت =================== */
const SPECIALTIES = ['أمراض القلب', 'طب الأطفال', 'الأمراض الجلدية', 'طب الأعصاب', 'طب الأسرة', 'طب الأسنان', 'طب العيون', 'العظام والمفاصل'];
const CITIES = ['بغداد', 'البصرة', 'أربيل', 'النجف', 'كربلاء', 'الموصل'];

const DOC_STATUS = {
    pending:   { label: 'بانتظار الموافقة', cls: 'warning' },
    active:    { label: 'نشط', cls: 'success' },
    suspended: { label: 'موقوف', cls: 'danger' },
    rejected:  { label: 'مرفوض', cls: 'muted' }
};
const USER_STATUS = {
    active:   { label: 'مفعّل', cls: 'success' },
    disabled: { label: 'معطّل', cls: 'danger' },
    pending:  { label: 'بانتظار الموافقة', cls: 'warning' },
    inactive: { label: 'بانتظار التفعيل', cls: 'primary' }
};
const ROLES = {
    patient: { label: 'مريض', icon: '🧑' },
    doctor:  { label: 'طبيب', icon: '🩺' },
    admin:   { label: 'إداري', icon: '🛡️' },
    clinic:  { label: 'مدير عيادة', icon: '🏥' },
    system:  { label: 'النظام', icon: '⚙️' }
};
const APPT_STATUS = {
    confirmed: { label: 'محجوز', cls: 'primary', color: '#1463ff', icon: '📅' },
    waiting:   { label: 'في الانتظار', cls: 'warning', color: '#f59e0b', icon: '⏳' },
    in:        { label: 'داخل الاستشارة', cls: 'purple live', color: '#7c3aed', icon: '🩺' },
    completed: { label: 'مكتمل', cls: 'success', color: '#16a34a', icon: '✓' },
    noshow:    { label: 'لم يحضر', cls: 'muted', color: '#94a3b8', icon: '✕' },
    cancelled: { label: 'ملغى', cls: 'danger', color: '#e5484d', icon: '⊘' }
};
const PAY_STATUS = {
    paid:     { label: 'مدفوع', cls: 'success', color: '#16a34a', icon: '✓' },
    pending:  { label: 'بانتظار الدفع', cls: 'warning', color: '#f59e0b', icon: '⏳' },
    refunded: { label: 'مسترد', cls: 'muted', color: '#94a3b8', icon: '↩' },
    failed:   { label: 'فشل الدفع', cls: 'danger', color: '#e5484d', icon: '!' }
};
const METHODS = { cash: 'نقداً', card: 'بطاقة مصرفية', wallet: 'محفظة إلكترونية' };

const ACTIONS = {
    login:              { label: 'تسجيل دخول', cls: 'blue', icon: '🔑' },
    logout:             { label: 'تسجيل خروج', cls: 'gray', icon: '🚪' },
    approve_doctor:     { label: 'قبول طبيب', cls: 'green', icon: '✓' },
    reject_doctor:      { label: 'رفض طبيب', cls: 'red', icon: '✕' },
    review_doctor:      { label: 'إعادة مراجعة', cls: 'orange', icon: '↺' },
    suspend_account:    { label: 'تعطيل حساب', cls: 'red', icon: '⏸' },
    activate_account:   { label: 'تفعيل حساب', cls: 'green', icon: '▶' },
    create_account:     { label: 'إنشاء حساب', cls: 'purple', icon: '➕' },
    book_appointment:   { label: 'حجز موعد', cls: 'blue', icon: '📅' },
    cancel_appointment: { label: 'إلغاء موعد', cls: 'orange', icon: '⊘' },
    refund_payment:     { label: 'استرداد مبلغ', cls: 'orange', icon: '↩' },
    retry_payment:      { label: 'إعادة محاولة دفع', cls: 'blue', icon: '⟳' },
    update_policy:      { label: 'تحديث السياسات', cls: 'purple', icon: '⚙️' },
    export_data:        { label: 'تصدير بيانات', cls: 'gray', icon: '⬇' },
    submit_clinic:      { label: 'طلب تسجيل عيادة', cls: 'purple', icon: '🏥' },
    approve_clinic:     { label: 'قبول عيادة', cls: 'green', icon: '✓' },
    reject_clinic:      { label: 'رفض عيادة', cls: 'red', icon: '✕' },
    review_clinic:      { label: 'إعادة مراجعة عيادة', cls: 'orange', icon: '↺' },
    activate_manager:   { label: 'تفعيل مدير عيادة', cls: 'green', icon: '🔑' }
};

const POLICY_FIELDS = [
    { key: 'cancelHours', icon: '⏰', title: 'مهلة الإلغاء', desc: 'أقل مدة مسموحة لإلغاء الموعد من قبل المريض قبل وقته.', unit: 'ساعة', min: 0, max: 72 },
    { key: 'bookingWindow', icon: '📆', title: 'مدة الحجز المسبق', desc: 'أقصى عدد أيام يمكن الحجز فيها مقدماً.', unit: 'يوم', min: 1, max: 180 },
    { key: 'maxDaily', icon: '🔢', title: 'حجوزات المريض باليوم', desc: 'الحد الأقصى لعدد حجوزات المريض في اليوم الواحد.', unit: 'حجز', min: 1, max: 10 },
    { key: 'noShowLimit', icon: '🚫', title: 'حد عدم الحضور', desc: 'عدد مرات عدم الحضور قبل تقييد الحجز الإلكتروني للمريض.', unit: 'مرات', min: 1, max: 10 },
    { key: 'refundPercent', icon: '↩', title: 'نسبة الاسترداد', desc: 'نسبة المبلغ المسترد عند الإلغاء ضمن المهلة المسموحة.', unit: '%', min: 0, max: 100 },
    { key: 'autoCancel', icon: '⌛', title: 'الإلغاء التلقائي', desc: 'إلغاء الحجز إذا لم يكتمل الدفع الإلكتروني خلال هذه المدة.', unit: 'دقيقة', min: 5, max: 120 },
    { key: 'queueAvg', icon: '🎫', title: 'متوسط مدة الكشف', desc: 'يُستخدم لحساب وقت الانتظار المتوقع في الطوابير.', unit: 'دقيقة', min: 5, max: 60 },
    { key: 'allowFamily', icon: '👨‍👩‍👧', title: 'الحجز لأفراد العائلة', desc: 'السماح للمريض بحجز مواعيد لأفراد عائلته.', toggle: true },
    { key: 'requireOnlinePay', icon: '💳', title: 'إلزام الدفع الإلكتروني', desc: 'لا يتم تأكيد الحجز إلا بعد الدفع الإلكتروني.', toggle: true },
    { key: 'doctorCancel', icon: '🩺', title: 'إلغاء الطبيب للمواعيد', desc: 'السماح للأطباء بإلغاء مواعيد المرضى مع ذكر السبب.', toggle: true }
];
const DEFAULT_POLICIES = {
    cancelHours: 2, bookingWindow: 60, maxDaily: 2, noShowLimit: 3, refundPercent: 100,
    autoCancel: 30, queueAvg: 15, allowFamily: true, requireOnlinePay: false, doctorCancel: true
};

const PAGES = ['dashboard', 'doctors', 'clinics', 'users', 'appointments', 'payments', 'audit'];
const PAGE_INFO = {
    dashboard:    ['لوحة الإدارة', 'نظرة عامة على النظام اليوم'],
    doctors:      ['إدارة الأطباء', 'طلبات التسجيل وحالة حسابات الأطباء'],
    clinics:      ['اعتماد العيادات', 'طلبات تسجيل العيادات وتفعيل حسابات المدراء'],
    users:        ['إدارة المستخدمين', 'المرضى والأطباء والإداريون'],
    appointments: ['المواعيد والطوابير', 'متابعة الحجوزات والطوابير وسياسات الحجز'],
    payments:     ['إدارة المدفوعات', 'جميع عمليات الدفع والاسترداد'],
    audit:        ['سجل العمليات', 'من قام بماذا ومتى']
};


/* =================== توليد البيانات التجريبية =================== */
function seededRandom(seed) {
    return () => {
        seed |= 0; seed = seed + 0x6D2B79F5 | 0;
        let t = Math.imul(seed ^ seed >>> 15, 1 | seed);
        t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
        return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
}

function generateData() {
    const R = seededRandom(7331);
    const pick = a => a[Math.floor(R() * a.length)];
    const now = Date.now();
    const DOCS = ['شهادة مزاولة المهنة.pdf', 'هوية نقابة الأطباء.pdf', 'شهادة الاختصاص.pdf', 'صورة شخصية.jpg'];

    const doctorSeed = [
        ['د. سارة أحمد', 'f', 'أمراض القلب', 12, 'active', [['عيادة الكرادة التخصصية', 'بغداد', 25000], ['مستشفى الحياة الأهلي', 'بغداد', 35000]]],
        ['د. محمد الجبوري', 'm', 'طب الأطفال', 9, 'active', [['عيادة المنصور للأطفال', 'بغداد', 20000]]],
        ['د. نور الهدى كريم', 'f', 'الأمراض الجلدية', 7, 'active', [['مركز النخبة للجلدية', 'البصرة', 25000]]],
        ['د. علي حسن الموسوي', 'm', 'طب الأعصاب', 15, 'active', [['مستشفى الكفيل التخصصي', 'النجف', 40000]]],
        ['د. زينب عبد الله', 'f', 'طب الأسرة', 6, 'active', [['مجمع اليرموك الطبي', 'بغداد', 15000]]],
        ['د. أحمد السامرائي', 'm', 'طب الأسنان', 10, 'active', [['مركز ابتسامة لطب الأسنان', 'أربيل', 20000]]],
        ['د. مريم الدليمي', 'f', 'طب العيون', 11, 'active', [['مركز النور للعيون', 'بغداد', 30000]]],
        ['د. حيدر العبيدي', 'm', 'العظام والمفاصل', 14, 'active', [['مستشفى الحياة الأهلي', 'بغداد', 35000]]],
        ['د. ياسر الخفاجي', 'm', 'طب الأطفال', 5, 'pending', [['عيادة الحلة للأطفال', 'كربلاء', 20000]]],
        ['د. آمنة الشمري', 'f', 'الأمراض الجلدية', 8, 'pending', [['مركز البشرة الذهبية', 'بغداد', 30000]]],
        ['د. ليث المالكي', 'm', 'العظام والمفاصل', 4, 'pending', [['مجمع الأمل الطبي', 'البصرة', 25000]]],
        ['د. رنا العزاوي', 'f', 'طب الأسرة', 3, 'pending', [['عيادة الأسرة الحديثة', 'الموصل', 15000]]],
        ['د. باسم الحلي', 'm', 'طب الأسنان', 9, 'suspended', [['مركز الحلي لطب الأسنان', 'النجف', 20000]]],
        ['د. سامر يوسف', 'm', 'طب العيون', 2, 'rejected', [['عيادة الرؤية', 'أربيل', 25000]]]
    ];

    const doctors = doctorSeed.map(([name, gender, specialty, exp, status, clinics], i) => {
        const regDays = status === 'pending' ? i - 8 : -(60 + i * 20);
        return {
            id: `D-${201 + i}`, userId: `U-${2001 + i}`, name, gender, specialty, exp, status,
            email: `doctor${201 + i}@smartclinic.iq`,
            phone: `077${pad(Math.floor(R() * 90) + 10)}${Math.floor(1000000 + R() * 8999999)}`.slice(0, 11),
            license: `IQ-MED-${Math.floor(10000 + R() * 89999)}`,
            clinics: clinics.map(([n, c, f]) => ({ name: n, city: c, fee: f })),
            registeredAt: toISO(addDays(new Date(), status === 'pending' ? -(i - 7) : -(120 + i * 15))),
            docs: status === 'pending' && i === 10 ? DOCS.slice(0, 2) : DOCS,
            reason: status === 'suspended' ? 'شكاوى متكررة من المرضى بخصوص التأخير' : status === 'rejected' ? 'وثيقة مزاولة المهنة غير واضحة' : '',
            regDays
        };
    });

    const firsts = ['علي', 'زينب', 'محمد', 'نور', 'حيدر', 'فاطمة', 'حسين', 'مريم', 'عباس', 'رقية', 'أحمد', 'سجى', 'كرار', 'هدى', 'مصطفى', 'بنين', 'يوسف', 'تبارك', 'منتظر', 'زهراء', 'سيف', 'دعاء', 'حسن', 'آيات'];
    const lasts = ['حسن', 'كاظم', 'كريم', 'حسين', 'عبد الأمير', 'جاسم', 'علي', 'صادق', 'فاضل', 'مهدي', 'سلمان', 'رعد', 'ناصر', 'عادل', 'جواد', 'حميد'];
    const users = [];

    for (let i = 0; i < 38; i++) {
        const f = firsts[i % firsts.length];
        const name = `${f} ${pick(lasts)}`;
        const joinedDaysAgo = Math.floor(Math.pow(R(), 1.6) * 56);
        users.push({
            id: `U-${1001 + i}`, role: 'patient', name, gender: i % 2 ? 'f' : 'm',
            email: `patient${1001 + i}@mail.iq`,
            phone: `07${pick(['70', '71', '73', '80', '50'])}${Math.floor(1000000 + R() * 8999999)}`,
            city: pick(CITIES), status: R() < 0.9 ? 'active' : 'disabled',
            joined: toISO(addDays(new Date(), -joinedDaysAgo)),
            lastLogin: now - Math.floor(R() * 9 * 86400000)
        });
    }
    doctors.forEach(d => users.push({
        id: d.userId, role: 'doctor', doctorId: d.id, name: d.name, gender: d.gender,
        email: d.email, phone: d.phone, city: d.clinics[0].city,
        joined: d.registeredAt, lastLogin: d.status === 'active' ? now - Math.floor(R() * 3 * 86400000) : null
    }));
    [['أ. علي الربيعي', 'm', 'admin@smartclinic.iq', 'active'], ['م. زهراء الكعبي', 'f', 'zahraa@smartclinic.iq', 'active'], ['أ. حسن العامري', 'm', 'hassan@smartclinic.iq', 'disabled']]
        .forEach(([name, gender, email, status], i) => users.push({
            id: `U-${3001 + i}`, role: 'admin', name, gender, email,
            phone: `0780${Math.floor(1000000 + R() * 8999999)}`, city: 'بغداد', status,
            joined: toISO(addDays(new Date(), -(300 + i * 40))), lastLogin: now - Math.floor(R() * 2 * 86400000)
        }));

    // المواعيد والمدفوعات
    const patients = users.filter(u => u.role === 'patient');
    const activeDocs = doctors.filter(d => d.status === 'active');
    const appts = [];
    let idc = 52100, payc = 880100;

    for (let off = -30; off <= 3; off++) {
        const day = addDays(new Date(), off);
        if (day.getDay() === 5) continue;
        const iso = toISO(day);
        activeDocs.forEach((d, di) => {
            const n = off === 0 ? 4 + Math.floor(R() * 4) : Math.floor(R() * 5);
            const startH = d.specialty === 'طب الأسرة' || d.specialty === 'طب الأسنان' ? 10 : 16;
            const used = new Set();
            for (let k = 0; k < n; k++) {
                const time = `${pad(startH + Math.floor(k / 2))}:${k % 2 ? '30' : '00'}`;
                let p;
                do { p = pick(patients); } while (used.has(p.id) && used.size < patients.length);
                used.add(p.id);

                let status;
                if (off < 0) { const r = R(); status = r < 0.8 ? 'completed' : r < 0.9 ? 'cancelled' : 'noshow'; }
                else if (off > 0) status = R() < 0.92 ? 'confirmed' : 'cancelled';
                else status = k < 2 ? 'completed' : k === 2 ? 'in' : k < 5 ? 'waiting' : (R() < 0.85 ? 'confirmed' : 'cancelled');

                const clinicIdx = Math.floor(R() * d.clinics.length);
                const fee = d.clinics[clinicIdx].fee;
                const method = pick(['cash', 'cash', 'card', 'wallet']);
                let payStatus;
                if (status === 'completed') payStatus = R() < 0.03 ? 'failed' : 'paid';
                else if (status === 'cancelled') payStatus = method === 'cash' ? null : 'refunded';
                else if (status === 'noshow') payStatus = method === 'cash' ? null : 'paid';
                else payStatus = method === 'cash' ? 'pending' : (R() < 0.06 ? 'failed' : 'paid');

                const a = {
                    id: `SC-${idc += 1 + Math.floor(R() * 30)}`,
                    patientId: p.id, doctorId: d.id, clinicIdx, date: iso, time,
                    queueNo: `${'ABCDEFGH'[di]}-${pad(k + 1)}`, status, fee
                };
                if (payStatus) {
                    a.payment = {
                        id: `PAY-${payc += 7 + Math.floor(R() * 90)}`, method, status: payStatus, amount: fee,
                        at: day.getTime() - Math.floor(R() * 3) * 86400000,
                        refundAmount: payStatus === 'refunded' ? fee : 0
                    };
                }
                appts.push(a);
            }
        });
    }

    // سجل العمليات
    const admins = users.filter(u => u.role === 'admin');
    const actorOf = u => ({ id: u.id, name: u.name, role: u.role });
    const logs = [];
    const addSeed = (action, actor, records, details, minutesAgo) => logs.push({ action, actor, records, details, at: now - minutesAgo * 60000 });

    doctors.filter(d => d.status === 'pending').forEach((d, i) =>
        addSeed('create_account', { id: d.userId, name: d.name, role: 'doctor' }, [d.userId, d.id], `طلب تسجيل طبيب جديد — ${d.specialty}`, (i + 1) * 410));
    addSeed('suspend_account', actorOf(admins[1]), [doctors[12].userId, doctors[12].id], `تعطيل حساب ${doctors[12].name}`, 2900);
    addSeed('reject_doctor', actorOf(admins[0]), [doctors[13].userId, doctors[13].id], 'رفض طلب التسجيل: وثيقة مزاولة المهنة غير واضحة', 4300);
    addSeed('update_policy', actorOf(admins[0]), ['POLICY-BOOKING'], 'مهلة الإلغاء: 1 ← 2 ساعة', 6100);

    for (let i = 0; i < 42; i++) {
        const mins = Math.floor(R() * 7 * 24 * 60);
        const r = R();
        const a = pick(appts.filter(x => x.date <= todayISO()));
        const p = users.find(u => u.id === a.patientId);
        const d = doctors.find(x => x.id === a.doctorId);
        if (r < 0.25) addSeed('login', actorOf(pick([p, ...admins.slice(0, 2)])), [pick([p.id, admins[0].id])], 'دخول ناجح إلى النظام', mins);
        else if (r < 0.5) addSeed('book_appointment', actorOf(p), [a.id, p.id, d.id], `حجز موعد مع ${d.name}`, mins);
        else if (r < 0.65) addSeed('cancel_appointment', R() < 0.5 ? actorOf(p) : { id: d.userId, name: d.name, role: 'doctor' }, [a.id], 'إلغاء موعد ضمن المهلة المسموحة', mins);
        else if (r < 0.75 && a.payment) addSeed('refund_payment', { id: 'SYS', name: 'النظام', role: 'system' }, [a.payment.id, a.id], 'استرداد تلقائي بعد الإلغاء', mins);
        else if (r < 0.85) addSeed('create_account', actorOf(p), [p.id], 'تسجيل حساب مريض جديد', mins);
        else addSeed('export_data', actorOf(admins[1]), ['REPORT-PAYMENTS'], 'تصدير تقرير المدفوعات', mins);
    }
    logs.sort((a, b) => b.at - a.at);
    logs.forEach((l, i) => { l.id = `LOG-${pad(7400 + logs.length - i)}`; });

    const pendingCount = doctors.filter(d => d.status === 'pending').length;
    return {
        v: 1, seedDate: todayISO(), doctors, users, appts, logs,
        policies: { ...DEFAULT_POLICIES },
        policyUpdated: { by: admins[0].name, at: now - 6100 * 60000 },
        notifs: [
            { icon: '🩺', text: `${pendingCount} طلبات تسجيل أطباء بانتظار المراجعة`, t: now - 1800000, unread: true },
            { icon: '💳', text: `${appts.filter(a => a.payment && a.payment.status === 'failed').length} عمليات دفع فاشلة تحتاج متابعة`, t: now - 5400000, unread: true }
        ]
    };
}


/* =================== الحالة =================== */
const state = {
    data: null,
    session: null,
    page: '',
    pages: { users: 1, appt: 1, pay: 1, log: 1 },
    docFilter: { q: '', spec: '', status: '', sort: 'new' },
    userFilter: { q: '', role: '', status: '', city: '' },
    apptFilter: { q: '', date: todayISO(), doctor: '', status: '' },
    apptView: 'list',
    payFilter: { q: '', status: '', method: '', from: '', to: '' },
    payRange: 'today',
    logFilter: { q: '', action: '', role: '', period: '' },
    policyDraft: null,
    clinicFilter: { q: '', status: '', city: '', type: '' },
    lastQueueUpdate: Date.now(),
    newLogId: null
};

function loadData() {
    let d = rawGet('scAdmin_data');
    if (!d || d.v !== 1 || d.seedDate !== todayISO()) d = generateData();
    if (!d.clinics) addClinicsData(d);
    mergeClinicRequests(d);
    state.data = d;
    saveData();
}
const saveData = () => rawSet('scAdmin_data', state.data);

const D = () => state.data;
const getDoctor = id => D().doctors.find(d => d.id === id);
const getUser = id => D().users.find(u => u.id === id);
const me = () => getUser('U-3001');
const userStatus = u => {
    if (u.role === 'clinic') {
        const c = getClinic(u.clinicId);
        return c.status !== 'approved' ? 'pending' : c.manager.status === 'active' ? 'active' : c.manager.status === 'disabled' ? 'disabled' : 'inactive';
    }
    if (u.role !== 'doctor') return u.status;
    const s = getDoctor(u.doctorId).status;
    return s === 'active' ? 'active' : s === 'pending' ? 'pending' : 'disabled';
};
const userIcon = u => u.role === 'clinic' ? '🏥' : u.role === 'admin' ? '🛡️' : u.role === 'doctor' ? (u.gender === 'f' ? '👩‍⚕️' : '👨‍⚕️') : (u.gender === 'f' ? '👩' : '👨');
const payments = () => D().appts.filter(a => a.payment);
const byTime = (a, b) => (a.date + a.time).localeCompare(b.date + b.time);


/* =================== الإشعارات والنوافذ =================== */
function toast(msg, type = 'success') {
    const icons = { success: '✓', error: '!', info: 'i', warning: '!' };
    const el = document.createElement('div');
    el.className = `toast ${type}`;
    el.innerHTML = `<span class="toast-icon">${icons[type] || 'i'}</span><span>${msg}</span>`;
    $('#toastStack').appendChild(el);
    requestAnimationFrame(() => requestAnimationFrame(() => el.classList.add('show')));
    setTimeout(() => { el.classList.remove('show'); setTimeout(() => el.remove(), 500); }, 3300);
}

let modalResolver = null;
function openModal(html, size = '') {
    const m = $('#modal');
    $('#modalBody').innerHTML = html;
    m.className = 'modal open ' + size;
    m.setAttribute('aria-hidden', 'false');
    document.body.classList.add('no-scroll');
}
function closeModal() {
    const m = $('#modal');
    if (!m.classList.contains('open')) return;
    m.classList.remove('open');
    m.setAttribute('aria-hidden', 'true');
    if (!$('#drawer').classList.contains('open')) document.body.classList.remove('no-scroll');
    if (modalResolver) { const r = modalResolver; modalResolver = null; r(false); }
}
function confirmDialog({ title, text, ok = 'تأكيد', danger = false, icon = '⚠️' }) {
    return new Promise(resolve => {
        openModal(`
            <div class="confirm">
                <div class="confirm-icon ${danger ? 'danger' : ''}">${icon}</div>
                <h3>${title}</h3>
                <p class="muted">${text}</p>
                <div class="confirm-actions">
                    <button class="btn light" data-confirm="no">تراجع</button>
                    <button class="btn ${danger ? 'danger' : 'primary'}" data-confirm="yes">${ok}</button>
                </div>
            </div>`);
        modalResolver = resolve;
    });
}
function openDrawer(html) {
    $('#drawerBody').innerHTML = html;
    $('#drawer').classList.add('open');
    document.body.classList.add('no-scroll');
    $('.drawer-panel').scrollTop = 0;
}
function closeDrawer() {
    $('#drawer').classList.remove('open');
    if (!$('#modal').classList.contains('open')) document.body.classList.remove('no-scroll');
}
function setError(input, msg) {
    const g = input && input.closest('.form-group');
    if (!g) return !msg;
    g.classList.toggle('has-error', !!msg);
    const e = $('.error-text', g);
    if (e) e.textContent = msg || '';
    return !msg;
}

function notify(icon, text) {
    D().notifs.unshift({ icon, text, t: Date.now(), unread: true });
    D().notifs = D().notifs.slice(0, 20);
    saveData();
    renderNotifs();
    const b = $('#notifBtn');
    b.classList.remove('ring'); void b.offsetWidth; b.classList.add('ring');
}
function renderNotifs() {
    const list = D().notifs;
    const unread = list.filter(n => n.unread).length;
    $('#notifCount').hidden = !unread;
    $('#notifCount').textContent = unread;
    $('#notifList').innerHTML = list.length
        ? list.map(n => `<div class="notif-item ${n.unread ? 'unread' : ''}"><span class="ni-icon">${n.icon}</span><div>${esc(n.text)}<small>${timeAgo(n.t)}</small></div></div>`).join('')
        : '<div class="notif-empty">لا توجد إشعارات 🎉</div>';
}


/* =================== سجل العمليات (كتابة) =================== */
function addLog(action, records, details, actor) {
    const a = actor || { id: me().id, name: me().name, role: 'admin' };
    const max = Math.max(7400, ...D().logs.map(l => Number(l.id.split('-')[1])));
    const entry = { id: `LOG-${max + 1}`, action, actor: a, records, details, at: Date.now() };
    D().logs.unshift(entry);
    state.newLogId = entry.id;
    saveData();
    return entry;
}


/* =================== التحميل (Skeleton) =================== */
function tableSkeleton(tbody, cols, rows = 6) {
    tbody.innerHTML = Array.from({ length: rows }, () =>
        `<tr>${Array.from({ length: cols }, () => `<td><div class="sk-line" style="width:${50 + Math.random() * 45}%"></div></td>`).join('')}</tr>`).join('');
}
function withLoading(showSkeleton, render, delay = 450) {
    showSkeleton();
    clearTimeout(state.loadTimer);
    state.loadTimer = setTimeout(render, delay);
}


/* =================== الترقيم =================== */
function paginate(list, key, size) {
    const pages = Math.max(1, Math.ceil(list.length / size));
    if (state.pages[key] > pages) state.pages[key] = pages;
    const page = state.pages[key];
    return { rows: list.slice((page - 1) * size, page * size), page, pages, total: list.length, size };
}
function renderPager(el, key, { page, pages, total, size }) {
    if (!total) { el.innerHTML = ''; return; }
    const from = (page - 1) * size + 1, to = Math.min(total, page * size);
    let nums = [];
    const start = Math.max(1, Math.min(page - 2, pages - 4));
    for (let i = start; i <= Math.min(pages, start + 4); i++) nums.push(i);
    el.innerHTML = `
        <span>عرض ${from}–${to} من ${total}</span>
        <div class="pager-btns">
            <button data-pg="${key}" data-to="${page - 1}" ${page <= 1 ? 'disabled' : ''}>→</button>
            ${nums.map(n => `<button data-pg="${key}" data-to="${n}" class="${n === page ? 'active' : ''}">${n}</button>`).join('')}
            <button data-pg="${key}" data-to="${page + 1}" ${page >= pages ? 'disabled' : ''}>←</button>
        </div>`;
}


/* =================== الرسوم =================== */
function renderBarChart(el, items, color = '#7c3aed') {
    const max = Math.max(1, ...items.map(x => x.value));
    el.classList.remove('ready');
    el.innerHTML =
        `<div class="grid-line" style="bottom:calc(30px + (100% - 56px) * .5)"></div>
         <div class="grid-line" style="bottom:calc(30px + (100% - 56px))"></div>` +
        items.map((x, i) => {
            const pct = (x.value / max) * 100;
            return `
            <div class="bar-col" data-tip="${esc(x.tip)}">
                <span class="bar-val" data-b="${pct}">${x.value}</span>
                <div class="bar" style="--i:${i}; background:${color}" data-h="${pct}"></div>
                <span class="bar-label">${x.label}</span>
            </div>`;
        }).join('');
    requestAnimationFrame(() => requestAnimationFrame(() => {
        $$('.bar', el).forEach(b => { b.style.height = `max(${b.dataset.h}%, ${b.dataset.h > 0 ? 4 : 2}px)`; });
        $$('.bar-val', el).forEach(v => { v.style.bottom = v.dataset.b + '%'; });
        el.classList.add('ready');
    }));
}
function renderStack(el, parts, money = false) {
    const total = parts.reduce((s, p) => s + p.value, 0);
    if (!total) { el.innerHTML = '<p class="chart-empty muted">لا توجد بيانات في هذه الفترة</p>'; return; }
    el.innerHTML = `
        <div class="stack-bar">${parts.filter(p => p.value).map(p => `<i style="background:${p.color}" data-w="${(p.value / total) * 100}" title="${p.label}"></i>`).join('')}</div>
        <div class="legend">
            ${parts.map(p => `
                <div class="legend-row">
                    <i class="sw" style="background:${p.color}"></i>
                    <span>${p.icon} ${p.label}${p.count !== undefined ? ` <small class="muted">(${p.count})</small>` : ''}</span>
                    <b>${money ? fmtMoney(p.value) : p.value}</b>
                    <em>${Math.round((p.value / total) * 100)}%</em>
                </div>`).join('')}
        </div>`;
    requestAnimationFrame(() => requestAnimationFrame(() => {
        $$('.stack-bar i', el).forEach(i => { i.style.width = i.dataset.w + '%'; });
    }));
}
function statCard({ icon, label, value, sub, color, money = false }, i) {
    return `
    <div class="stat-card card-anim" style="--c:${color}; --i:${i}">
        <div class="stat-top"><span class="stat-icon">${icon}</span></div>
        <p>${label}</p>
        <h2 data-count="${value}" data-money="${money ? 1 : ''}">0</h2>
        <small>${sub}</small>
    </div>`;
}
function animateCounts(root) {
    $$('[data-count]', root).forEach(el => {
        const target = Number(el.dataset.count), money = !!el.dataset.money;
        const start = performance.now();
        const step = now => {
            const p = Math.min((now - start) / 1100, 1);
            const v = Math.round(target * (1 - Math.pow(1 - p, 3)));
            el.textContent = money ? fmtMoney(v) : v;
            if (p < 1) requestAnimationFrame(step);
        };
        requestAnimationFrame(step);
    });
}
function bindChartTips() {
    const tip = $('#chartTip');
    document.addEventListener('mousemove', e => {
        const col = e.target.closest('.bar-col');
        if (!col) { tip.classList.remove('show'); return; }
        const r = col.getBoundingClientRect();
        tip.textContent = col.dataset.tip;
        tip.style.left = (r.left + r.width / 2) + 'px';
        tip.style.top = (r.top + 18) + 'px';
        tip.classList.add('show');
    });
}


/* =================== التنقل =================== */
function go(page) {
    if (!PAGES.includes(page)) {
        location.href = `../Shared/404.html?path=${encodeURIComponent('/admin#' + page)}`;
        return;
    }
    document.body.classList.remove('sidebar-open');
    if (page !== state.page) {
        $$('.page').forEach(p => p.classList.toggle('active', p.dataset.page === page));
        $$('.side-link').forEach(l => l.classList.toggle('active', l.dataset.page === page));
        state.page = page;
        moveIndicator();
        try { history.replaceState(null, '', '#' + page); } catch (e) { /* تجاهل */ }
        const [t, s] = PAGE_INFO[page];
        $('#pageTitle').textContent = t;
        $('#pageSub').textContent = s;
        const tt = $('.topbar-title');
        tt.classList.remove('swap'); void tt.offsetWidth; tt.classList.add('swap');
    }
    renderPage(page, true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function renderPage(page = state.page, withSkeleton = false) {
    const fns = {
        dashboard: () => renderDashboard(),
        doctors: () => withSkeleton
            ? withLoading(() => { $('#docGrid').innerHTML = '<div class="sk-card"></div>'.repeat(6); }, renderDoctors)
            : renderDoctors(),
        clinics: () => withSkeleton
            ? withLoading(() => { $('#clinicGrid').innerHTML = '<div class="sk-card"></div>'.repeat(6); }, renderClinics)
            : renderClinics(),
        users: () => withSkeleton ? withLoading(() => tableSkeleton($('#usersList'), 7), renderUsers) : renderUsers(),
        appointments: () => renderApptView(withSkeleton),
        payments: () => withSkeleton ? withLoading(() => tableSkeleton($('#payList'), 8), renderPayments) : renderPayments(),
        audit: () => withSkeleton ? withLoading(() => tableSkeleton($('#logList'), 6), renderAudit) : renderAudit()
    };
    fns[page]();
    updateBadges();
}

function moveIndicator() {
    const a = $('.side-link.active'), ind = $('#sideIndicator');
    if (!a || !ind) return;
    ind.style.height = a.offsetHeight + 'px';
    ind.style.transform = `translateY(${a.offsetTop}px)`;
}
function updateBadges() {
    const n = D().doctors.filter(d => d.status === 'pending').length;
    $('#badgePending').textContent = n || '';
    $('#badgeClinics').textContent = D().clinics.filter(c => c.status === 'pending' || (c.status === 'approved' && c.manager.status === 'inactive')).length || '';
}


/* =================== 17. لوحة الإدارة =================== */
function renderDashboard() {
    const h = new Date().getHours();
    const doctors = D().doctors, users = D().users;
    const pending = doctors.filter(d => d.status === 'pending');
    const today = D().appts.filter(a => a.date === todayISO());
    const todayActive = today.filter(a => a.status !== 'cancelled');
    const failed = payments().filter(a => a.payment.status === 'failed').length;

    $('#todayLabel').textContent = fmtDate(todayISO(), { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
    $('#greeting').textContent = `${h < 12 ? 'صباح الخير' : 'مساء الخير'} ${me().name.split(' ').slice(0, 2).join(' ')} 👋`;
    const pendingClinics = D().clinics.filter(c => c.status === 'pending').length;
    $('#welcomeSub').textContent = `لديك ${pending.length} طلبات أطباء و ${pendingClinics} طلبات عيادات بانتظار المراجعة، و ${todayActive.length} موعداً اليوم.`;

    const activeToday = users.filter(u => u.lastLogin && Date.now() - u.lastLogin < 86400000).length;
    $('#welcomeSide').innerHTML = `
        <small>حالة النظام</small>
        <strong><span class="online-dot" style="display:inline-block"></span> يعمل بشكل طبيعي</strong>
        <div class="wc-row"><span>مستخدمون نشطون اليوم</span><b>${activeToday}</b></div>
        <div class="wc-row"><span>عيادات بانتظار الموافقة</span><b>${pendingClinics}</b></div>
        <div class="wc-row"><span>مدفوعات فاشلة</span><b>${failed}</b></div>
        <button class="btn light sm block" data-go="payments">مراجعة المدفوعات ←</button>`;

    const counts = r => users.filter(u => u.role === r).length;
    $('#dashStats').innerHTML = [
        { icon: '👥', label: 'إجمالي المستخدمين', value: users.length, sub: `${counts('patient')} مريض · ${counts('doctor')} طبيب · ${counts('admin')} إداري`, color: '#1463ff' },
        { icon: '🩺', label: 'عدد الأطباء', value: doctors.filter(d => d.status === 'active').length, sub: `نشط · ${doctors.filter(d => d.status === 'suspended').length} موقوف`, color: '#12b5a5' },
        { icon: '⏳', label: 'أطباء بانتظار الموافقة', value: pending.length, sub: 'طلبات تسجيل جديدة', color: '#f59e0b' },
        { icon: '📅', label: 'مواعيد اليوم', value: todayActive.length, sub: `${today.filter(a => a.status === 'completed').length} مكتملة · ${today.filter(a => a.status === 'cancelled').length} ملغاة`, color: '#7c3aed' }
    ].map(statCard).join('');
    animateCounts($('#dashStats'));

    renderPayStatusSummary();

    $('#pendingMini').innerHTML = pending.length ? pending.slice(0, 4).map((d, i) => `
        <div class="mini-item" style="--i:${i}">
            <span class="pt-avatar">${d.gender === 'f' ? '👩‍⚕️' : '👨‍⚕️'}</span>
            <div class="up-info">
                <button class="link-btn" data-act="doc-view" data-id="${d.id}">${esc(d.name)}</button>
                <small>${d.specialty} · ${d.clinics[0].city} · ${relDay(d.registeredAt)}</small>
            </div>
            <button class="btn teal xs" data-act="doc-approve" data-id="${d.id}">✓ قبول</button>
            <button class="btn danger-light xs" data-act="doc-reject" data-id="${d.id}">✕</button>
        </div>`).join('')
        : '<div class="empty-state"><div class="empty-icon">✅</div><h3>لا توجد طلبات معلقة</h3><p>تمت مراجعة جميع طلبات الأطباء.</p></div>';

    // التسجيلات الأسبوعية
    const weeks = [];
    for (let w = 7; w >= 0; w--) {
        const end = addDays(new Date(), -w * 7), start = addDays(end, -6);
        const s = toISO(start), e = toISO(end);
        const v = users.filter(u => u.role === 'patient' && u.joined >= s && u.joined <= e).length;
        weeks.push({ label: fmtDate(s, { day: 'numeric', month: 'numeric' }), value: v, tip: `أسبوع ${fmtDate(s, { day: 'numeric', month: 'short' })} – ${fmtDate(e, { day: 'numeric', month: 'short' })}: ${v} مريض جديد` });
    }
    renderBarChart($('#signupChart'), weeks);

    renderStack($('#todayStatus'), ['completed', 'in', 'waiting', 'confirmed', 'noshow', 'cancelled'].map(k => ({
        label: APPT_STATUS[k].label, icon: APPT_STATUS[k].icon, color: APPT_STATUS[k].color,
        value: today.filter(a => a.status === k).length
    })));

    $('#recentLogs').innerHTML = D().logs.slice(0, 6).map((l, i) => {
        const A = ACTIONS[l.action];
        return `
        <div class="mini-item" style="--i:${i}">
            <span class="act-badge ${A.cls}">${A.icon} ${A.label}</span>
            <div class="up-info"><strong>${esc(l.actor.name)}</strong><small>${esc(l.details)}</small></div>
            <small class="muted">${timeAgo(l.at)}</small>
        </div>`;
    }).join('');
}

function renderPayStatusSummary() {
    const from = state.payRange === 'today' ? todayISO() : toISO(addDays(new Date(), -29));
    const list = payments().filter(a => a.date >= from && a.date <= todayISO());
    renderStack($('#payStatusSummary'), Object.entries(PAY_STATUS).map(([k, s]) => {
        const items = list.filter(a => a.payment.status === k);
        return { label: s.label, icon: s.icon, color: s.color, count: items.length, value: items.reduce((x, a) => x + a.payment.amount, 0) };
    }), true);
}


/* =================== 18. إدارة الأطباء =================== */
function bindDoctors() {
    $('#docSpec').innerHTML = '<option value="">جميع الاختصاصات</option>' + SPECIALTIES.map(s => `<option>${s}</option>`).join('');
    let t;
    $('#docSearch').addEventListener('input', e => { clearTimeout(t); t = setTimeout(() => { state.docFilter.q = e.target.value.trim(); renderDoctors(); }, 200); });
    $('#docSpec').addEventListener('change', e => { state.docFilter.spec = e.target.value; renderDoctors(); });
    $('#docSort').addEventListener('change', e => { state.docFilter.sort = e.target.value; renderDoctors(); });
    $('#docChips').addEventListener('click', e => {
        const c = e.target.closest('[data-status]');
        if (c) { state.docFilter.status = c.dataset.status; renderDoctors(); }
    });
}

function docActions(d, compact = false) {
    const b = (cls, act, label) => `<button class="btn ${cls} ${compact ? 'xs' : 'sm'}" data-act="${act}" data-id="${d.id}">${label}</button>`;
    const view = compact ? b('light', 'doc-view', '👁 البيانات') : '';
    switch (d.status) {
        case 'pending': return view + b('success', 'doc-approve', '✓ قبول') + b('danger-light', 'doc-reject', '✕ رفض');
        case 'active': return view + b('warn', 'doc-suspend', '⏸ إيقاف الحساب');
        case 'suspended': return view + b('teal', 'doc-activate', '▶ إعادة التفعيل');
        case 'rejected': return view + b('light', 'doc-review', '↺ إعادة المراجعة');
    }
    return view;
}

function renderDoctors() {
    const f = state.docFilter;
    $('#docSearch').value = f.q;
    $('#docSpec').value = f.spec;
    $('#docSort').value = f.sort;

    const base = D().doctors.filter(d => !f.spec || d.specialty === f.spec);
    $('#docChips').innerHTML = [['', 'الكل', base.length], ...Object.entries(DOC_STATUS).map(([k, s]) => [k, s.label, base.filter(d => d.status === k).length])]
        .map(([k, l, n]) => `<button class="chip ${f.status === k ? 'active' : ''}" data-status="${k}">${l} <b>${n}</b></button>`).join('');

    const q = normalize(f.q);
    let list = base.filter(d => !f.status || d.status === f.status)
        .filter(d => !q || normalize(`${d.name} ${d.email} ${d.license} ${d.id} ${d.specialty}`).includes(q));
    if (f.sort === 'new') list.sort((a, b) => b.registeredAt.localeCompare(a.registeredAt));
    if (f.sort === 'name') list.sort((a, b) => a.name.localeCompare(b.name, 'ar'));
    if (f.sort === 'exp') list.sort((a, b) => b.exp - a.exp);
    // الطلبات المعلقة أولاً
    list.sort((a, b) => (a.status === 'pending' ? 0 : 1) - (b.status === 'pending' ? 0 : 1));

    $('#docGrid').innerHTML = list.length ? list.map((d, i) => {
        const st = DOC_STATUS[d.status];
        return `
        <article class="doc-card ${d.status === 'pending' ? 'pending' : ''}" style="--i:${i}" data-card="${d.id}">
            ${d.status === 'pending' ? '<span class="ribbon">طلب جديد</span>' : ''}
            <div class="dc-head">
                <span class="pt-avatar">${d.gender === 'f' ? '👩‍⚕️' : '👨‍⚕️'}</span>
                <div>
                    <button class="link-btn" data-act="doc-view" data-id="${d.id}"><strong>${esc(d.name)}</strong></button>
                    <small>${d.id} · ${d.specialty}</small>
                </div>
            </div>
            <span class="badge ${st.cls}" style="align-self:flex-start">${st.label}</span>
            <div class="dc-meta">
                <div>رقم الترخيص<b dir="ltr">${d.license}</b></div>
                <div>الخبرة<b>${d.exp} سنة</b></div>
                <div>العيادات<b>${d.clinics.length} · ${d.clinics[0].city}</b></div>
                <div>تاريخ التسجيل<b>${relDay(d.registeredAt)}</b></div>
            </div>
            ${d.reason ? `<small class="muted">📝 ${esc(d.reason)}</small>` : ''}
            <div class="dc-actions">${docActions(d, true)}</div>
        </article>`;
    }).join('') : '<div class="empty-state" style="grid-column:1/-1"><div class="empty-icon">🔍</div><h3>لا يوجد أطباء مطابقون</h3><p>غيّر البحث أو الفلاتر.</p></div>';
}

function openDoctorDrawer(id) {
    const d = getDoctor(id);
    if (!d) return;
    const st = DOC_STATUS[d.status];
    const appts = D().appts.filter(a => a.doctorId === id);
    const revenue = appts.filter(a => a.payment && a.payment.status === 'paid').reduce((s, a) => s + a.payment.amount, 0);
    const logs = D().logs.filter(l => l.records.includes(d.id)).slice(0, 5);

    openDrawer(`
        <div class="drawer-head">
            <span class="pt-avatar">${d.gender === 'f' ? '👩‍⚕️' : '👨‍⚕️'}</span>
            <div>
                <h2>${esc(d.name)}</h2>
                <span class="muted small">${d.id} · ${d.userId}</span><br>
                <span class="badge ${st.cls}">${st.label}</span>
            </div>
        </div>
        <p class="access-note">🔒 تعرض الإدارة البيانات المهنية والإدارية فقط، دون أي معلومات طبية للمرضى.</p>

        <div class="drawer-section">
            <h4>بيانات الطبيب</h4>
            <div class="detail-grid">
                <div><span>الاختصاص</span><b>${d.specialty}</b></div>
                <div><span>سنوات الخبرة</span><b>${d.exp} سنة</b></div>
                <div><span>رقم الترخيص</span><b dir="ltr">${d.license}</b></div>
                <div><span>تاريخ التسجيل</span><b>${fmtDate(d.registeredAt)}</b></div>
                <div><span>البريد الإلكتروني</span><b dir="ltr">${d.email}</b></div>
                <div><span>الهاتف</span><b dir="ltr">${d.phone}</b></div>
            </div>
            ${d.reason ? `<div class="alert-box ${d.status === 'suspended' ? 'danger' : 'note'}">📝 <b>السبب:</b> ${esc(d.reason)}</div>` : ''}
        </div>

        <div class="drawer-section">
            <h4>العيادات وأجور المعاينة</h4>
            <div class="mini-list">
                ${d.clinics.map(c => `<div class="mini-item"><span>🏥</span><div class="up-info"><strong>${esc(c.name)}</strong><small>📍 ${c.city}</small></div><b>${fmtMoney(c.fee)}</b></div>`).join('')}
            </div>
        </div>

        <div class="drawer-section">
            <h4>الوثائق المرفقة (${d.docs.length})</h4>
            <div class="docs-list">
                ${d.docs.map(x => `<a href="#" data-doc="${esc(x)}">${x.endsWith('.pdf') ? '📄' : '🖼️'} ${esc(x)} <small>معاينة</small></a>`).join('')}
            </div>
            ${d.status === 'pending' && d.docs.length < 4 ? '<div class="alert-box note mt">⚠️ بعض الوثائق المطلوبة غير مرفقة.</div>' : ''}
        </div>

        ${d.status === 'active' || d.status === 'suspended' ? `
        <div class="drawer-section">
            <h4>إحصائيات إدارية</h4>
            <div class="detail-grid">
                <div><span>إجمالي المواعيد (30 يوم)</span><b>${appts.length}</b></div>
                <div><span>المكتملة</span><b>${appts.filter(a => a.status === 'completed').length}</b></div>
                <div><span>الملغاة</span><b>${appts.filter(a => a.status === 'cancelled').length}</b></div>
                <div><span>المدفوعات المستلمة</span><b>${fmtMoney(revenue)}</b></div>
            </div>
        </div>` : ''}

        <div class="drawer-section">
            <h4>آخر العمليات على الحساب</h4>
            <div class="mini-list">
                ${logs.length ? logs.map(l => `<div class="mini-item"><span class="act-badge ${ACTIONS[l.action].cls}">${ACTIONS[l.action].icon}</span><div class="up-info"><strong>${ACTIONS[l.action].label}</strong><small>${esc(l.actor.name)} · ${timeAgo(l.at)}</small></div></div>`).join('') : '<p class="muted small">لا توجد عمليات مسجلة.</p>'}
            </div>
        </div>

        <div class="hero-buttons">${docActions(d)}</div>`);
}

function syncDoctorUi(d, verb) {
    const card = $(`[data-card="${d.id}"]`);
    if (card && state.docFilter.status && state.docFilter.status !== d.status) {
        card.classList.add('leaving');
        setTimeout(() => refreshAll(), 320);
    } else refreshAll();
    if ($('#drawer').classList.contains('open')) openDoctorDrawer(d.id);
    toast(verb, 'success');
}

async function doctorAction(act, id) {
    const d = getDoctor(id);
    if (!d) return;

    if (act === 'doc-approve') {
        const ok = await confirmDialog({ title: `قبول ${d.name}؟`, text: `سيتم تفعيل حساب الطبيب وظهوره للمرضى في قائمة ${d.specialty}.`, ok: '✓ قبول الطلب', icon: '🩺' });
        if (!ok) return;
        d.status = 'active'; d.reason = '';
        addLog('approve_doctor', [d.userId, d.id], `قبول طلب تسجيل ${d.name} — ${d.specialty}`);
        notify('✅', `تم قبول ${d.name}`);
        saveData();
        syncDoctorUi(d, `تم قبول ${d.name} وتفعيل حسابه`);
    }
    if (act === 'doc-reject' || act === 'doc-suspend') openReasonModal(d, act);
    if (act === 'doc-activate') {
        const ok = await confirmDialog({ title: `إعادة تفعيل ${d.name}؟`, text: 'سيتمكن الطبيب من تسجيل الدخول واستقبال الحجوزات مجدداً.', ok: '▶ تفعيل', icon: '▶' });
        if (!ok) return;
        d.status = 'active'; d.reason = '';
        addLog('activate_account', [d.userId, d.id], `إعادة تفعيل حساب ${d.name}`);
        saveData();
        syncDoctorUi(d, 'تم تفعيل الحساب');
    }
    if (act === 'doc-review') {
        const ok = await confirmDialog({ title: 'إعادة الطلب للمراجعة؟', text: `سيعود طلب ${d.name} إلى قائمة الطلبات المعلقة.`, ok: '↺ إعادة المراجعة', icon: '↺' });
        if (!ok) return;
        d.status = 'pending'; d.reason = '';
        addLog('review_doctor', [d.userId, d.id], `إعادة طلب ${d.name} للمراجعة`);
        saveData();
        syncDoctorUi(d, 'أُعيد الطلب إلى قائمة المراجعة');
    }
}

function openReasonModal(d, act) {
    const reject = act === 'doc-reject';
    const reasons = reject
        ? ['وثيقة مزاولة المهنة غير واضحة', 'رقم الترخيص غير مطابق', 'وثائق ناقصة', 'أخرى']
        : ['شكاوى متكررة من المرضى', 'انتهاء صلاحية الترخيص', 'مخالفة سياسات النظام', 'أخرى'];
    openModal(`
        <div class="confirm">
            <div class="confirm-icon danger">${reject ? '✕' : '⏸'}</div>
            <h3>${reject ? 'رفض طلب' : 'إيقاف حساب'} ${esc(d.name)}</h3>
            <p class="muted">${reject ? 'سيتم إبلاغ الطبيب بسبب الرفض.' : 'لن يتمكن الطبيب من الدخول أو استقبال حجوزات جديدة.'}</p>
            <form id="reasonForm" data-id="${d.id}" data-act="${act}" novalidate>
                <div class="form-group">
                    <div class="reason-list">${reasons.map(r => `<label><input type="radio" name="reason" value="${r}"> ${r}</label>`).join('')}</div>
                    <small class="error-text"></small>
                </div>
                <div class="form-group">
                    <textarea class="field" name="note" rows="2" placeholder="ملاحظة إضافية (مطلوبة عند اختيار «أخرى»)"></textarea>
                    <small class="error-text"></small>
                </div>
                <div class="confirm-actions">
                    <button type="button" class="btn light" data-close-modal>تراجع</button>
                    <button type="submit" class="btn danger">${reject ? 'تأكيد الرفض' : 'تأكيد الإيقاف'}</button>
                </div>
            </form>
        </div>`);
}

function submitReason(form) {
    const d = getDoctor(form.dataset.id);
    const reason = form.elements.reason.value, note = form.elements.note.value.trim();
    let ok = setError($('.reason-list', form), reason ? '' : 'اختر السبب');
    ok = setError(form.elements.note, reason === 'أخرى' && note.length < 3 ? 'اكتب السبب' : '') && ok;
    if (!ok) { shake(form); return; }

    setLoading($('[type=submit]', form), true);
    setTimeout(() => {
        const text = reason === 'أخرى' ? note : reason + (note ? ` — ${note}` : '');
        const reject = form.dataset.act === 'doc-reject';
        d.status = reject ? 'rejected' : 'suspended';
        d.reason = text;
        addLog(reject ? 'reject_doctor' : 'suspend_account', [d.userId, d.id], `${reject ? 'رفض طلب' : 'إيقاف حساب'} ${d.name}: ${text}`);
        saveData();
        closeModal();
        syncDoctorUi(d, reject ? 'تم رفض الطلب وإبلاغ الطبيب' : 'تم إيقاف حساب الطبيب');
    }, 650);
}


/* =================== 20. إدارة المستخدمين =================== */
function bindUsers() {
    $('#userCity').innerHTML = '<option value="">جميع المدن</option>' + CITIES.map(c => `<option>${c}</option>`).join('');
    let t;
    const f = state.userFilter;
    const reset = () => { state.pages.users = 1; renderUsers(); };
    $('#userSearch').addEventListener('input', e => { clearTimeout(t); t = setTimeout(() => { f.q = e.target.value.trim(); reset(); }, 200); });
    $('#userStatus').addEventListener('change', e => { f.status = e.target.value; reset(); });
    $('#userCity').addEventListener('change', e => { f.city = e.target.value; reset(); });
    $('#userChips').addEventListener('click', e => {
        const c = e.target.closest('[data-role]');
        if (c) { f.role = c.dataset.role; reset(); }
    });

    // تفعيل / تعطيل الحساب
    $('#usersList').addEventListener('click', async e => {
        const input = e.target.closest('input[data-user-toggle]');
        if (!input) return;
        e.preventDefault();
        const u = getUser(input.dataset.userToggle);
        const active = userStatus(u) === 'active';
        const ok = await confirmDialog({
            title: `${active ? 'تعطيل' : 'تفعيل'} حساب ${u.name}؟`,
            text: active ? 'لن يتمكن المستخدم من تسجيل الدخول حتى إعادة التفعيل.' : 'سيتمكن المستخدم من تسجيل الدخول واستخدام النظام.',
            ok: active ? '⏸ تعطيل الحساب' : '▶ تفعيل الحساب', danger: active, icon: active ? '⏸' : '▶'
        });
        if (!ok) return;
        if (u.role === 'doctor') {
            const d = getDoctor(u.doctorId);
            d.status = active ? 'suspended' : 'active';
            d.reason = active ? 'تعطيل من إدارة المستخدمين' : '';
        } else if (u.role === 'clinic') {
            getClinic(u.clinicId).manager.status = active ? 'disabled' : 'active';
        } else u.status = active ? 'disabled' : 'active';
        addLog(active ? 'suspend_account' : 'activate_account', [u.id, ...(u.doctorId ? [u.doctorId] : []), ...(u.clinicId ? [u.clinicId] : [])], `${active ? 'تعطيل' : 'تفعيل'} حساب ${ROLES[u.role].label}: ${u.name}`);
        saveData();
        renderUsers();
        updateBadges();
        toast(active ? 'تم تعطيل الحساب' : 'تم تفعيل الحساب', 'success');
    });
}

function renderUsers() {
    const f = state.userFilter;
    $('#userSearch').value = f.q;
    $('#userStatus').value = f.status;
    $('#userCity').value = f.city;

    const all = D().users;
    $('#userChips').innerHTML = [['', 'الكل', all.length], ...['patient', 'doctor', 'clinic', 'admin'].map(r => [r, ROLES[r].icon + ' ' + ({ admin: 'الإداريون', doctor: 'الأطباء', clinic: 'مدراء العيادات', patient: 'المرضى' })[r], all.filter(u => u.role === r).length])]
        .map(([k, l, n]) => `<button class="chip ${f.role === k ? 'active' : ''}" data-role="${k}">${l} <b>${n}</b></button>`).join('');

    const q = normalize(f.q);
    const list = all
        .filter(u => !f.role || u.role === f.role)
        .filter(u => !f.status || userStatus(u) === f.status)
        .filter(u => !f.city || u.city === f.city)
        .filter(u => !q || normalize(`${u.name} ${u.email} ${u.phone} ${u.id}`).includes(q))
        .sort((a, b) => b.joined.localeCompare(a.joined));

    const pg = paginate(list, 'users', 10);
    $('#usersList').innerHTML = pg.rows.length ? pg.rows.map((u, i) => {
        const st = userStatus(u), S = USER_STATUS[st];
        const isMe = u.id === me().id;
        const canToggle = !isMe && st !== 'pending' && st !== 'inactive' && !(u.role === 'doctor' && getDoctor(u.doctorId).status === 'rejected');
        return `
        <tr style="--i:${i}">
            <td>
                <div class="pt-cell">
                    <span class="pt-avatar">${userIcon(u)}</span>
                    <div><button class="link-btn" data-act="user-view" data-id="${u.id}">${esc(u.name)}</button>${isMe ? '<small>(أنت)</small>' : ''}</div>
                </div>
            </td>
            <td><code>${u.id}</code></td>
            <td><span class="role-badge ${u.role}">${ROLES[u.role].icon} ${ROLES[u.role].label}</span></td>
            <td><small dir="ltr">${u.phone}</small><br><small class="muted" dir="ltr">${u.email}</small></td>
            <td>${fmtDate(u.joined)}</td>
            <td><small>${u.lastLogin ? timeAgo(u.lastLogin) : '—'}</small></td>
            <td>
                ${canToggle ? `
                <label class="switch-cell" title="${st === 'active' ? 'تعطيل الحساب' : 'تفعيل الحساب'}">
                    <span class="switch table-switch">
                        <input type="checkbox" data-user-toggle="${u.id}" ${st === 'active' ? 'checked' : ''}>
                        <span class="slider"></span>
                    </span>
                    <span class="badge ${S.cls}">${S.label}</span>
                </label>` : `<span class="badge ${S.cls}" title="${isMe ? 'لا يمكنك تعطيل حسابك' : ''}">${S.label}${isMe ? ' 🔒' : ''}</span>
                ${st === 'pending' ? `<button class="text-button small" data-go="${u.role === 'clinic' ? 'clinics' : 'doctors'}">مراجعة</button>` : ''}
                ${st === 'inactive' ? `<button class="btn teal xs" data-act="clinic-activate" data-id="${u.clinicId}">🔑 تفعيل</button>` : ''}`}
            </td>
        </tr>`;
    }).join('') : '<tr class="table-empty"><td colspan="7"><div class="empty-state"><div class="empty-icon">🔍</div><h3>لا يوجد مستخدمون مطابقون</h3></div></td></tr>';
    renderPager($('#usersPager'), 'users', pg);
}

function openUserDrawer(id) {
    const u = getUser(id);
    if (!u) return;
    if (u.role === 'doctor') { openDoctorDrawer(u.doctorId); return; }
    if (u.role === 'clinic') { openClinicDrawer(u.clinicId); return; }
    const st = USER_STATUS[userStatus(u)];
    const appts = D().appts.filter(a => a.patientId === id);
    const logs = D().logs.filter(l => l.records.includes(id) || l.actor.id === id).slice(0, 6);
    openDrawer(`
        <div class="drawer-head">
            <span class="pt-avatar">${userIcon(u)}</span>
            <div>
                <h2>${esc(u.name)}</h2>
                <span class="role-badge ${u.role}">${ROLES[u.role].icon} ${ROLES[u.role].label}</span>
                <span class="badge ${st.cls}">${st.label}</span>
            </div>
        </div>
        <p class="access-note">🔒 لا تعرض الإدارة السجلات الطبية أو التشخيصات — البيانات الإدارية فقط.</p>
        <div class="drawer-section">
            <h4>معلومات الحساب</h4>
            <div class="detail-grid">
                <div><span>المعرف</span><b>${u.id}</b></div>
                <div><span>المدينة</span><b>${u.city}</b></div>
                <div><span>البريد</span><b dir="ltr">${u.email}</b></div>
                <div><span>الهاتف</span><b dir="ltr">${u.phone}</b></div>
                <div><span>تاريخ التسجيل</span><b>${fmtDate(u.joined)}</b></div>
                <div><span>آخر دخول</span><b>${u.lastLogin ? timeAgo(u.lastLogin) : '—'}</b></div>
            </div>
        </div>
        ${u.role === 'patient' ? `
        <div class="drawer-section">
            <h4>إحصائيات الحجز</h4>
            <div class="detail-grid">
                <div><span>إجمالي الحجوزات</span><b>${appts.length}</b></div>
                <div><span>المكتملة</span><b>${appts.filter(a => a.status === 'completed').length}</b></div>
                <div><span>الملغاة</span><b>${appts.filter(a => a.status === 'cancelled').length}</b></div>
                <div><span>عدم الحضور</span><b>${appts.filter(a => a.status === 'noshow').length} / ${D().policies.noShowLimit}</b></div>
            </div>
        </div>` : ''}
        <div class="drawer-section">
            <h4>سجل العمليات</h4>
            <div class="mini-list">
                ${logs.length ? logs.map(l => `<div class="mini-item"><span class="act-badge ${ACTIONS[l.action].cls}">${ACTIONS[l.action].icon}</span><div class="up-info"><strong>${ACTIONS[l.action].label}</strong><small>${esc(l.actor.name)} · ${timeAgo(l.at)}</small></div></div>`).join('') : '<p class="muted small">لا توجد عمليات مسجلة.</p>'}
            </div>
        </div>`);
}


/* =================== 21. المواعيد والطوابير والسياسات =================== */
function bindAppointments() {
    const f = state.apptFilter;
    const reset = () => { state.pages.appt = 1; renderApptList(); };
    $('#apptDoctor').innerHTML = '<option value="">جميع الأطباء</option>' + D().doctors.filter(d => d.status !== 'pending' && d.status !== 'rejected').map(d => `<option value="${d.id}">${d.name}</option>`).join('');

    $('#apptTabs').addEventListener('click', e => {
        const b = e.target.closest('[data-view]');
        if (!b) return;
        if (state.apptView === 'policies' && b.dataset.view !== 'policies' && policyChanged().length) {
            toast('لديك تغييرات غير محفوظة في السياسات', 'warning');
        }
        state.apptView = b.dataset.view;
        renderApptView(true);
    });

    let t;
    $('#apptSearch').addEventListener('input', e => { clearTimeout(t); t = setTimeout(() => { f.q = e.target.value.trim(); reset(); }, 200); });
    $('#apptDate').addEventListener('change', e => { if (e.target.value) { f.date = e.target.value; reset(); } });
    $('#apptDoctor').addEventListener('change', e => { f.doctor = e.target.value; reset(); });
    $('#datePrev').addEventListener('click', () => { f.date = toISO(addDays(parseISO(f.date), -1)); reset(); });
    $('#dateNext').addEventListener('click', () => { f.date = toISO(addDays(parseISO(f.date), 1)); reset(); });
    $('#dateToday').addEventListener('click', () => { f.date = todayISO(); reset(); });
    $('#apptChips').addEventListener('click', e => {
        const c = e.target.closest('[data-status]');
        if (c) { f.status = c.dataset.status; reset(); }
    });

    bindPolicies();
}

function renderApptView(withSkeleton = false) {
    $$('#apptTabs button').forEach(b => b.classList.toggle('active', b.dataset.view === state.apptView));
    ['list', 'queues', 'policies'].forEach(v => { $(`#view-${v}`).hidden = v !== state.apptView; });
    if (state.apptView === 'list') {
        if (withSkeleton) withLoading(() => tableSkeleton($('#apptList'), 8), renderApptList);
        else renderApptList();
    }
    if (state.apptView === 'queues') {
        if (withSkeleton) withLoading(() => { $('#queueBoard').innerHTML = '<div class="sk-card"></div>'.repeat(4); }, renderQueues);
        else renderQueues();
    }
    if (state.apptView === 'policies') renderPolicies();
}

function renderApptList() {
    const f = state.apptFilter;
    $('#apptDate').value = f.date;
    $('#apptDoctor').value = f.doctor;

    const base = D().appts.filter(a => a.date === f.date && (!f.doctor || a.doctorId === f.doctor));
    $('#apptChips').innerHTML = `<span class="muted small" style="align-self:center">📅 ${fmtDate(f.date, { weekday: 'long', day: 'numeric', month: 'long' })}</span>` +
        [['', 'الكل', base.length], ...Object.entries(APPT_STATUS).map(([k, s]) => [k, s.label, base.filter(a => a.status === k).length])]
            .filter(([k, , n]) => !k || n)
            .map(([k, l, n]) => `<button class="chip ${f.status === k ? 'active' : ''}" data-status="${k}">${l} <b>${n}</b></button>`).join('');

    const q = normalize(f.q);
    const list = base
        .filter(a => !f.status || a.status === f.status)
        .filter(a => !q || normalize(`${a.id} ${getUser(a.patientId).name} ${getDoctor(a.doctorId).name}`).includes(q))
        .sort((a, b) => a.time.localeCompare(b.time) || a.doctorId.localeCompare(b.doctorId));

    const pg = paginate(list, 'appt', 10);
    $('#apptList').innerHTML = pg.rows.length ? pg.rows.map((a, i) => {
        const p = getUser(a.patientId), d = getDoctor(a.doctorId), st = APPT_STATUS[a.status];
        const ps = a.payment ? PAY_STATUS[a.payment.status] : null;
        return `
        <tr style="--i:${i}">
            <td><b>${a.id}</b></td>
            <td><button class="link-btn" data-act="user-view" data-id="${p.id}">${esc(p.name)}</button></td>
            <td>${esc(d.name)}<br><small class="muted">${esc(d.clinics[a.clinicIdx].name)}</small></td>
            <td>${fmtTime(a.time)}</td>
            <td><span class="q-no">${a.queueNo}</span></td>
            <td>${ps ? `<span class="badge ${ps.cls}">${ps.label}</span>` : '<span class="muted small">—</span>'}</td>
            <td><span class="badge ${st.cls}">${st.label}</span></td>
            <td><button class="btn light xs" data-act="appt-view" data-id="${a.id}">التفاصيل</button></td>
        </tr>`;
    }).join('') : '<tr class="table-empty"><td colspan="8"><div class="empty-state"><div class="empty-icon">🗓️</div><h3>لا توجد مواعيد مطابقة</h3><p>غيّر التاريخ أو الفلاتر.</p></div></td></tr>';
    renderPager($('#apptPager'), 'appt', pg);
}

function openApptModal(id) {
    const a = D().appts.find(x => x.id === id);
    if (!a) return;
    const p = getUser(a.patientId), d = getDoctor(a.doctorId), c = d.clinics[a.clinicIdx];
    const st = APPT_STATUS[a.status];
    openModal(`
        <h2 class="modal-title">تفاصيل الحجز ${a.id}</h2>
        <div class="detail-grid">
            <div><span>المريض</span><b>${esc(p.name)} <small class="muted">${p.id}</small></b></div>
            <div><span>الطبيب</span><b>${esc(d.name)}</b></div>
            <div><span>العيادة</span><b>${esc(c.name)} – ${c.city}</b></div>
            <div><span>التاريخ والوقت</span><b>${fmtDate(a.date)} · ${fmtTime(a.time)}</b></div>
            <div><span>رقم الطابور</span><b>${a.queueNo}</b></div>
            <div><span>الحالة</span><b><span class="badge ${st.cls}">${st.label}</span></b></div>
            <div><span>أجور المعاينة</span><b>${fmtMoney(a.fee)}</b></div>
            <div><span>الدفع</span><b>${a.payment ? `${METHODS[a.payment.method]} · <span class="badge ${PAY_STATUS[a.payment.status].cls}">${PAY_STATUS[a.payment.status].label}</span>` : 'لا يوجد'}</b></div>
        </div>
        <div class="privacy-note">🔒 تفاصيل الاستشارة والتشخيص غير متاحة للإدارة.</div>
        <div class="confirm-actions">
            <button class="btn light" data-close-modal>إغلاق</button>
            ${a.payment ? `<button class="btn primary" data-act="pay-find" data-id="${a.payment.id}">عرض عملية الدفع ←</button>` : `<button class="btn primary" data-act="user-view" data-id="${p.id}">حساب المريض ←</button>`}
        </div>`, 'wide');
}

function renderQueues() {
    const avg = D().policies.queueAvg;
    const today = D().appts.filter(a => a.date === todayISO());
    const docs = D().doctors.filter(d => today.some(a => a.doctorId === d.id));
    $('#queueUpdated').textContent = `آخر تحديث: ${timeAgo(state.lastQueueUpdate)} · متوسط الكشف ${avg} د`;

    $('#queueBoard').innerHTML = docs.length ? docs.map((d, i) => {
        const list = today.filter(a => a.doctorId === d.id && a.status !== 'cancelled');
        const cur = list.find(a => a.status === 'in');
        const waiting = list.filter(a => a.status === 'waiting').sort((a, b) => a.queueNo.localeCompare(b.queueNo));
        const done = list.filter(a => a.status === 'completed' || a.status === 'noshow').length;
        const remaining = list.filter(a => a.status === 'confirmed').length;
        return `
        <div class="q-tile" style="--i:${i}">
            <div class="q-tile-head">
                <span class="pt-avatar">${d.gender === 'f' ? '👩‍⚕️' : '👨‍⚕️'}</span>
                <div><strong>${esc(d.name)}</strong><small>${d.specialty} · ${esc(d.clinics[0].name)}</small></div>
            </div>
            <div class="q-now ${cur ? '' : 'idle'}">
                <div><small>${cur ? 'داخل الاستشارة الآن' : 'لا يوجد مريض حالياً'}</small><b class="${cur ? 'bump' : ''}">${cur ? cur.queueNo : '—'}</b></div>
                ${cur ? '<span class="badge purple live" style="background:rgba(255,255,255,.2);color:#fff">مباشر</span>' : ''}
            </div>
            <div class="q-stats">
                <div><b>${waiting.length}</b>في الانتظار</div>
                <div><b>${done}</b>انتهى</div>
                <div><b>${remaining}</b>لم يصلوا</div>
            </div>
            <div class="q-next">${waiting.slice(0, 4).map(w => `<span>${w.queueNo}</span>`).join('') || '<small class="muted">لا يوجد منتظرون</small>'}</div>
            <small class="muted">⏱ الانتظار المتوقع لآخر مريض: ~${waiting.length * avg} دقيقة</small>
            <div class="q-progress"><i style="width:${list.length ? (done / list.length) * 100 : 0}%"></i></div>
        </div>`;
    }).join('') : '<div class="empty-state" style="grid-column:1/-1"><div class="empty-icon">🎫</div><h3>لا توجد طوابير اليوم</h3></div>';
}

function tickQueues() {
    const today = D().appts.filter(a => a.date === todayISO() && a.status !== 'cancelled');
    const docIds = [...new Set(today.map(a => a.doctorId))];
    if (!docIds.length) return;
    const docId = docIds[Math.floor(Math.random() * docIds.length)];
    const list = today.filter(a => a.doctorId === docId);
    const cur = list.find(a => a.status === 'in');
    const next = list.filter(a => a.status === 'waiting').sort((a, b) => a.queueNo.localeCompare(b.queueNo))[0];
    const arriving = list.filter(a => a.status === 'confirmed').sort(byTime)[0];

    if (cur) {
        cur.status = 'completed';
        if (cur.payment && cur.payment.status === 'pending') { cur.payment.status = 'paid'; cur.payment.at = Date.now(); }
    }
    if (next) next.status = 'in';
    if (arriving && Math.random() < 0.6) arriving.status = 'waiting';
    state.lastQueueUpdate = Date.now();
    saveData();

    if (state.page === 'appointments' && state.apptView === 'queues') renderQueues();
    if (state.page === 'dashboard') renderDashboard();
}

/* ---------- السياسات ---------- */
function policyChanged() {
    const p = D().policies, dft = state.policyDraft;
    if (!dft) return [];
    return POLICY_FIELDS.filter(f => p[f.key] !== dft[f.key]);
}

function renderPolicies() {
    if (!state.policyDraft) state.policyDraft = { ...D().policies };
    const dft = state.policyDraft;
    const up = D().policyUpdated;
    $('#policyMeta').textContent = up ? `آخر تحديث: ${up.by} · ${timeAgo(up.at)}` : '';
    $('#policyGrid').innerHTML = POLICY_FIELDS.map((f, i) => `
        <div class="policy-item card-anim ${D().policies[f.key] !== dft[f.key] ? 'changed' : ''}" style="--i:${i}" data-policy="${f.key}">
            <label class="title" for="pol-${f.key}">${f.icon} ${f.title}</label>
            <p>${f.desc}</p>
            ${f.toggle ? `
                <label class="switch-wrap" style="justify-content:flex-start">
                    <span class="switch"><input type="checkbox" id="pol-${f.key}" data-key="${f.key}" ${dft[f.key] ? 'checked' : ''}><span class="slider"></span></span>
                    <span>${dft[f.key] ? 'مفعّل' : 'معطّل'}</span>
                </label>` : `
                <div class="form-group" style="margin:0">
                    <div class="policy-input">
                        <input type="number" class="field" id="pol-${f.key}" data-key="${f.key}" min="${f.min}" max="${f.max}" value="${dft[f.key]}">
                        <span class="muted">${f.unit}</span>
                        <small class="muted">(${f.min}–${f.max})</small>
                    </div>
                    <small class="error-text"></small>
                </div>`}
        </div>`).join('');
    updatePolicyStatus();
}

function updatePolicyStatus() {
    const n = policyChanged().length;
    $('#policyChanged').textContent = n ? `⚠️ ${n} تغييرات غير محفوظة` : 'لا توجد تغييرات غير محفوظة';
    $('#policyChanged').style.color = n ? 'var(--warning)' : '';
    $('#policySave').disabled = !n;
    $('#policyReset').disabled = !n;
}

function validatePolicy(input) {
    const f = POLICY_FIELDS.find(x => x.key === input.dataset.key);
    const v = Number(input.value);
    if (input.value === '' || !Number.isInteger(v)) return setError(input, 'أدخل رقماً صحيحاً');
    if (v < f.min || v > f.max) return setError(input, `القيمة يجب أن تكون بين ${f.min} و ${f.max}`);
    return setError(input, '');
}

function bindPolicies() {
    const grid = $('#policyGrid');
    grid.addEventListener('input', e => {
        const input = e.target.closest('input[data-key]');
        if (!input || input.type === 'checkbox') return;
        if (validatePolicy(input)) state.policyDraft[input.dataset.key] = Number(input.value);
        input.closest('.policy-item').classList.toggle('changed', D().policies[input.dataset.key] !== Number(input.value));
        updatePolicyStatus();
    });
    grid.addEventListener('change', e => {
        const input = e.target.closest('input[type=checkbox][data-key]');
        if (!input) return;
        state.policyDraft[input.dataset.key] = input.checked;
        input.closest('.switch-wrap').lastElementChild.textContent = input.checked ? 'مفعّل' : 'معطّل';
        input.closest('.policy-item').classList.toggle('changed', D().policies[input.dataset.key] !== input.checked);
        updatePolicyStatus();
    });
    $('#policyReset').addEventListener('click', () => {
        state.policyDraft = { ...D().policies };
        renderPolicies();
        toast('تم التراجع عن التغييرات', 'info');
    });
    $('#policyForm').addEventListener('submit', async e => {
        e.preventDefault();
        const inputs = $$('#policyGrid input[type=number]');
        const valid = inputs.map(validatePolicy).every(Boolean);
        if (!valid) { shake($('#policyForm')); toast('صحّح القيم غير الصحيحة أولاً', 'error'); return; }
        const changed = policyChanged();
        if (!changed.length) return;

        const fmtVal = (f, v) => f.toggle ? (v ? 'مفعّل' : 'معطّل') : `${v} ${f.unit}`;
        const summary = changed.map(f => `${f.title}: ${fmtVal(f, D().policies[f.key])} ← ${fmtVal(f, state.policyDraft[f.key])}`);
        const ok = await confirmDialog({
            title: 'حفظ سياسات الحجز والإلغاء؟',
            text: `سيتم تطبيق ${changed.length} تغييرات على جميع الحجوزات الجديدة:<br><small>${summary.map(esc).join('<br>')}</small>`,
            ok: '💾 حفظ وتطبيق', icon: '⚙️'
        });
        if (!ok) return;

        const btn = $('#policySave');
        setLoading(btn, true);
        setTimeout(() => {
            D().policies = { ...state.policyDraft };
            D().policyUpdated = { by: me().name, at: Date.now() };
            addLog('update_policy', ['POLICY-BOOKING'], summary.join(' · '));
            saveData();
            setLoading(btn, false);
            renderPolicies();
            toast('تم حفظ السياسات وتطبيقها', 'success');
        }, 700);
    });
}


/* =================== 22. إدارة المدفوعات =================== */
function bindPayments() {
    const f = state.payFilter;
    const reset = () => { state.pages.pay = 1; renderPayments(); };
    let t;
    $('#paySearch').addEventListener('input', e => { clearTimeout(t); t = setTimeout(() => { f.q = e.target.value.trim(); reset(); }, 200); });
    $('#payMethod').addEventListener('change', e => { f.method = e.target.value; reset(); });
    const onRange = () => {
        const a = $('#payFrom').value, b = $('#payTo').value;
        if (a && b && a > b) {
            toast('تاريخ البداية يجب أن يكون قبل تاريخ النهاية', 'error');
            shake($('#payFrom').parentElement);
            $('#payFrom').value = f.from; $('#payTo').value = f.to;
            return;
        }
        f.from = a; f.to = b; reset();
    };
    $('#payFrom').addEventListener('change', onRange);
    $('#payTo').addEventListener('change', onRange);
    $('#payChips').addEventListener('click', e => {
        const c = e.target.closest('[data-status]');
        if (c) { f.status = c.dataset.status; reset(); }
    });
    $('#payExport').addEventListener('click', exportPayments);
}

function filteredPayments(ignoreStatus = false) {
    const f = state.payFilter, q = normalize(f.q);
    return payments()
        .filter(a => ignoreStatus || !f.status || a.payment.status === f.status)
        .filter(a => !f.method || a.payment.method === f.method)
        .filter(a => (!f.from || a.date >= f.from) && (!f.to || a.date <= f.to))
        .filter(a => !q || normalize(`${a.payment.id} ${a.id} ${getUser(a.patientId).name} ${getDoctor(a.doctorId).name}`).includes(q))
        .sort((a, b) => byTime(b, a));
}

function renderPayments() {
    const f = state.payFilter;
    $('#paySearch').value = f.q;
    $('#payMethod').value = f.method;
    $('#payFrom').value = f.from;
    $('#payTo').value = f.to;

    const base = filteredPayments(true);
    const sum = s => base.filter(a => a.payment.status === s).reduce((x, a) => x + (s === 'refunded' ? a.payment.refundAmount || a.payment.amount : a.payment.amount), 0);
    $('#payStats').innerHTML = [
        { icon: '✓', label: 'المبالغ المستلمة', value: sum('paid'), sub: `${base.filter(a => a.payment.status === 'paid').length} عملية`, color: '#16a34a', money: true },
        { icon: '⏳', label: 'بانتظار الدفع', value: sum('pending'), sub: 'تُدفع في العيادة', color: '#f59e0b', money: true },
        { icon: '↩', label: 'المبالغ المستردة', value: sum('refunded'), sub: `${base.filter(a => a.payment.status === 'refunded').length} عملية`, color: '#94a3b8', money: true },
        { icon: '!', label: 'عمليات فاشلة', value: base.filter(a => a.payment.status === 'failed').length, sub: 'تحتاج متابعة', color: '#e5484d' }
    ].map(statCard).join('');
    animateCounts($('#payStats'));

    $('#payChips').innerHTML = [['', 'الكل', base.length], ...Object.entries(PAY_STATUS).map(([k, s]) => [k, s.label, base.filter(a => a.payment.status === k).length])]
        .map(([k, l, n]) => `<button class="chip ${f.status === k ? 'active' : ''}" data-status="${k}">${l} <b>${n}</b></button>`).join('');

    const pg = paginate(filteredPayments(), 'pay', 10);
    $('#payList').innerHTML = pg.rows.length ? pg.rows.map((a, i) => {
        const P = a.payment, s = PAY_STATUS[P.status];
        let action = '<span class="muted small">—</span>';
        if (P.status === 'paid') action = `<button class="btn warn xs" data-act="pay-refund" data-id="${P.id}">↩ استرداد</button>`;
        if (P.status === 'failed') action = `<button class="btn light xs" data-act="pay-retry" data-id="${P.id}">⟳ إعادة المحاولة</button>`;
        return `
        <tr style="--i:${i}" data-pay-row="${P.id}">
            <td><b>${P.id}</b><br><small class="muted">${a.id}</small></td>
            <td>${fmtDate(a.date, { day: 'numeric', month: 'short' })}<br><small class="muted">${fmtTime(a.time)}</small></td>
            <td><button class="link-btn" data-act="user-view" data-id="${a.patientId}">${esc(getUser(a.patientId).name)}</button></td>
            <td>${esc(getDoctor(a.doctorId).name)}</td>
            <td>${METHODS[P.method]}</td>
            <td><b>${fmtMoney(P.amount)}</b>${P.status === 'refunded' && P.refundAmount !== P.amount ? `<br><small class="muted">مسترد ${fmtMoney(P.refundAmount)}</small>` : ''}</td>
            <td><span class="badge ${s.cls}">${s.label}</span></td>
            <td>${action}</td>
        </tr>`;
    }).join('') : '<tr class="table-empty"><td colspan="8"><div class="empty-state"><div class="empty-icon">💳</div><h3>لا توجد عمليات مطابقة</h3></div></td></tr>';
    renderPager($('#payPager'), 'pay', pg);
}

function findPayment(payId) { return payments().find(a => a.payment.id === payId); }

function openRefund(payId) {
    const a = findPayment(payId);
    if (!a) return;
    const pct = D().policies.refundPercent;
    const amount = Math.round(a.payment.amount * pct / 100);
    openModal(`
        <div class="confirm">
            <div class="confirm-icon">↩</div>
            <h3>استرداد المبلغ للعملية ${payId}</h3>
            <p class="muted">${esc(getUser(a.patientId).name)} · ${METHODS[a.payment.method]} · الحجز ${a.id}</p>
        </div>
        <form id="refundForm" data-id="${payId}" novalidate>
            <div class="form-group mt">
                <label>مبلغ الاسترداد (د.ع) <span class="req">*</span></label>
                <input type="number" class="field" name="amount" min="1" max="${a.payment.amount}" value="${amount}">
                <small class="muted">حسب السياسة الحالية: ${pct}% · الحد الأقصى ${fmtMoney(a.payment.amount)}</small>
                <small class="error-text"></small>
            </div>
            <div class="form-group">
                <label>سبب الاسترداد <span class="req">*</span></label>
                <select class="field" name="reason">
                    <option value="">اختر السبب</option>
                    <option>إلغاء الموعد من قبل العيادة</option>
                    <option>دفع مكرر</option>
                    <option>طلب المريض ضمن المهلة</option>
                    <option>خطأ تقني في الدفع</option>
                </select>
                <small class="error-text"></small>
            </div>
            <div class="confirm-actions">
                <button type="button" class="btn light" data-close-modal>تراجع</button>
                <button type="submit" class="btn primary">تأكيد الاسترداد</button>
            </div>
        </form>`);
}

function submitRefund(form) {
    const a = findPayment(form.dataset.id);
    const amount = Number(form.elements.amount.value), reason = form.elements.reason.value;
    let ok = setError(form.elements.amount, !Number.isInteger(amount) || amount < 1 || amount > a.payment.amount ? `أدخل مبلغاً بين 1 و ${a.payment.amount}` : '');
    ok = setError(form.elements.reason, reason ? '' : 'اختر سبب الاسترداد') && ok;
    if (!ok) { shake(form); return; }
    setLoading($('[type=submit]', form), true);
    setTimeout(() => {
        a.payment.status = 'refunded';
        a.payment.refundAmount = amount;
        addLog('refund_payment', [a.payment.id, a.id, a.patientId], `استرداد ${fmtMoney(amount)} — ${reason}`);
        saveData();
        closeModal();
        renderPayments();
        flashRow(a.payment.id);
        toast(`تم استرداد ${fmtMoney(amount)} بنجاح`, 'success');
    }, 800);
}

function retryPayment(payId, btn) {
    const a = findPayment(payId);
    setLoading(btn, true);
    setTimeout(() => {
        const ok = Math.random() < 0.7;
        if (ok) { a.payment.status = 'paid'; a.payment.at = Date.now(); }
        addLog('retry_payment', [a.payment.id, a.id], ok ? 'نجحت إعادة محاولة الدفع' : 'فشلت إعادة محاولة الدفع');
        saveData();
        renderPayments();
        flashRow(payId);
        toast(ok ? 'تمت عملية الدفع بنجاح' : 'فشلت المحاولة مجدداً، تواصل مع المريض', ok ? 'success' : 'error');
    }, 1200);
}

function flashRow(payId) {
    const row = $(`[data-pay-row="${payId}"]`);
    if (row) { row.classList.remove('flash'); void row.offsetWidth; row.classList.add('flash'); }
}

function downloadCsv(name, header, rows) {
    const csv = '﻿' + [header, ...rows].map(r => r.map(v => `"${String(v).replace(/"/g, '""')}"`).join(',')).join('\n');
    const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
    const link = document.createElement('a');
    link.href = url; link.download = name;
    document.body.appendChild(link); link.click(); link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function exportPayments() {
    const list = filteredPayments();
    if (!list.length) { toast('لا توجد بيانات للتصدير', 'error'); return; }
    downloadCsv(`المدفوعات-${todayISO()}.csv`,
        ['رقم العملية', 'رقم الحجز', 'التاريخ', 'المريض', 'الطبيب', 'الطريقة', 'المبلغ', 'الحالة', 'المبلغ المسترد'],
        list.map(a => [a.payment.id, a.id, a.date, getUser(a.patientId).name, getDoctor(a.doctorId).name, METHODS[a.payment.method], a.payment.amount, PAY_STATUS[a.payment.status].label, a.payment.refundAmount || 0]));
    addLog('export_data', ['REPORT-PAYMENTS'], `تصدير ${list.length} عملية دفع`);
    saveData();
    toast(`تم تصدير ${list.length} عملية`, 'success');
}


/* =================== 23. سجل العمليات =================== */
function bindAudit() {
    $('#logAction').innerHTML = '<option value="">كل أنواع العمليات</option>' + Object.entries(ACTIONS).map(([k, a]) => `<option value="${k}">${a.icon} ${a.label}</option>`).join('');
    const f = state.logFilter;
    const reset = () => { state.pages.log = 1; renderAudit(); };
    let t;
    $('#logSearch').addEventListener('input', e => { clearTimeout(t); t = setTimeout(() => { f.q = e.target.value.trim(); reset(); }, 200); });
    $('#logAction').addEventListener('change', e => { f.action = e.target.value; reset(); });
    $('#logRole').addEventListener('change', e => { f.role = e.target.value; reset(); });
    $('#logPeriod').addEventListener('change', e => { f.period = e.target.value; reset(); });
    $('#logExport').addEventListener('click', () => {
        const list = filteredLogs();
        if (!list.length) { toast('لا توجد بيانات للتصدير', 'error'); return; }
        downloadCsv(`سجل-العمليات-${todayISO()}.csv`,
            ['المعرف', 'المنفذ', 'الدور', 'نوع العملية', 'التفاصيل', 'السجلات المرتبطة', 'الوقت'],
            list.map(l => [l.id, l.actor.name, ROLES[l.actor.role].label, ACTIONS[l.action].label, l.details, l.records.join(' | '), new Date(l.at).toLocaleString('en-GB')]));
        addLog('export_data', ['AUDIT-LOG'], `تصدير ${list.length} سجل عملية`);
        renderAudit();
        toast(`تم تصدير ${list.length} سجلاً`, 'success');
    });
}

function filteredLogs() {
    const f = state.logFilter, q = normalize(f.q);
    return D().logs
        .filter(l => !f.action || l.action === f.action)
        .filter(l => !f.role || l.actor.role === f.role)
        .filter(l => !f.period || Date.now() - l.at <= Number(f.period) * 86400000)
        .filter(l => !q || normalize(`${l.actor.name} ${l.id} ${l.records.join(' ')} ${l.details}`).includes(q));
}

function renderAudit() {
    const f = state.logFilter;
    $('#logSearch').value = f.q;
    $('#logAction').value = f.action;
    $('#logRole').value = f.role;
    $('#logPeriod').value = f.period;

    const pg = paginate(filteredLogs(), 'log', 12);
    $('#logList').innerHTML = pg.rows.length ? pg.rows.map((l, i) => {
        const A = ACTIONS[l.action];
        return `
        <tr style="--i:${i}" class="${l.id === state.newLogId ? 'new-row' : ''}">
            <td><code>${l.id}</code></td>
            <td>
                <strong>${esc(l.actor.name)}</strong><br>
                <span class="role-badge ${l.actor.role}">${ROLES[l.actor.role].icon} ${ROLES[l.actor.role].label}</span>
            </td>
            <td><span class="act-badge ${A.cls}">${A.icon} ${A.label}</span></td>
            <td style="max-width:280px"><small>${esc(l.details)}</small></td>
            <td>${l.records.map(r => `<span class="rec-chip">${esc(r)}</span>`).join('')}</td>
            <td class="log-time"><b>${fmtStamp(l.at)}</b><small>${timeAgo(l.at)}</small></td>
        </tr>`;
    }).join('') : '<tr class="table-empty"><td colspan="6"><div class="empty-state"><div class="empty-icon">🧾</div><h3>لا توجد عمليات مطابقة</h3></div></td></tr>';
    renderPager($('#logPager'), 'log', pg);
    state.newLogId = null;
}


/* =================== اعتماد العيادات (Clinic Approval) =================== */
const CLINIC_STATUS = {
    pending:  { label: 'بانتظار المراجعة', cls: 'warning' },
    approved: { label: 'مقبولة', cls: 'success' },
    rejected: { label: 'مرفوضة', cls: 'danger' }
};
const MANAGER_STATUS = {
    inactive: { label: 'بانتظار التفعيل', cls: 'primary' },
    active:   { label: 'الحساب مفعّل', cls: 'success' },
    disabled: { label: 'الحساب معطّل', cls: 'danger' }
};
const REQUIRED_DOCS = ['رخصة وزارة الصحة', 'السجل التجاري', 'هوية مدير العيادة', 'عقد الإيجار أو سند الملكية'];

function getClinic(id) { return D().clinics.find(c => c.id === id); }

// إضافة بيانات العيادات التجريبية (تُستدعى أيضاً للبيانات المحفوظة سابقاً دون حذف أي تغييرات)
function addClinicsData(d) {
    const now = Date.now(), day = 86400000;
    const iso = n => toISO(addDays(new Date(), n));
    const mk = (i, o) => ({
        id: `CL-${pad(i)}`, docs: REQUIRED_DOCS.slice(), reason: '', reviewedAt: null, reviewedBy: '', rooms: 4,
        hours: 'السبت – الخميس · 9:00 ص – 10:00 م', ...o
    });
    d.clinics = [
        mk(1, { name: 'عيادة الكرادة التخصصية', type: 'عيادة تخصصية', city: 'بغداد', address: 'الكرادة داخل · قرب ساحة كهرمانة', license: 'MOH-CL-20871', phone: '07801234567', email: 'manager@karrada-clinic.iq', specialties: ['أمراض القلب', 'طب الأسرة', 'طب العيون', 'العظام والمفاصل'], rooms: 6, status: 'approved', submittedAt: iso(-410), reviewedAt: now - 405 * day, reviewedBy: 'أ. علي الربيعي', manager: { name: 'أ. كريم الساعدي', gender: 'm', status: 'active' } }),
        mk(2, { name: 'مجمع اليرموك الطبي', type: 'مجمع طبي', city: 'بغداد', address: 'اليرموك · شارع المستشفى', license: 'MOH-CL-19442', phone: '07709876543', email: 'admin@yarmouk-medical.iq', specialties: ['طب الأطفال', 'طب الأسرة'], rooms: 10, hours: 'يومياً · 8:00 ص – 11:00 م', status: 'approved', submittedAt: iso(-330), reviewedAt: now - 328 * day, reviewedBy: 'م. زهراء الكعبي', manager: { name: 'د. ضياء الحسني', gender: 'm', status: 'active' } }),
        mk(3, { name: 'مركز النخبة للجلدية', type: 'مركز تخصصي', city: 'البصرة', address: 'العشار · شارع الكورنيش', license: 'MOH-CL-23016', phone: '07803344556', email: 'info@nukhba-derma.iq', specialties: ['الأمراض الجلدية'], rooms: 3, status: 'approved', submittedAt: iso(-4), reviewedAt: now - 2 * day, reviewedBy: 'أ. علي الربيعي', manager: { name: 'م. ريام عبد الكريم', gender: 'f', status: 'inactive' } }),
        mk(4, { name: 'مركز الشفاء التخصصي', type: 'مركز تخصصي', city: 'كربلاء', address: 'حي الحسين · شارع الإسكان', license: 'MOH-CL-24107', phone: '07714455889', email: 'contact@shifa-karbala.iq', specialties: ['طب الأطفال', 'طب الأعصاب', 'طب الأسرة'], rooms: 5, status: 'pending', submittedAt: iso(-1), manager: { name: 'أ. حيدر الكربلائي', gender: 'm', status: 'inactive' } }),
        mk(5, { name: 'عيادة الأمل لطب الأسنان', type: 'عيادة تخصصية', city: 'الموصل', address: 'الجانب الأيسر · حي الزهور', license: 'MOH-CL-24188', phone: '07502233667', email: 'amal.dental@mail.iq', specialties: ['طب الأسنان'], rooms: 2, status: 'pending', submittedAt: iso(-3), docs: REQUIRED_DOCS.slice(0, 2), manager: { name: 'د. سرى الطائي', gender: 'f', status: 'inactive' } }),
        mk(6, { name: 'مجمع دجلة الطبي', type: 'مجمع طبي', city: 'بغداد', address: 'الأعظمية · شارع عمر بن عبد العزيز', license: 'MOH-CL-24215', phone: '07901122998', email: 'info@dijla-medical.iq', specialties: ['أمراض القلب', 'العظام والمفاصل', 'طب العيون', 'طب الأطفال'], rooms: 12, hours: 'يومياً · 8:00 ص – 12:00 ص', status: 'pending', submittedAt: iso(0), manager: { name: 'أ. مهند العبيدي', gender: 'm', status: 'inactive' } }),
        mk(7, { name: 'عيادة النور العامة', type: 'عيادة عامة', city: 'النجف', address: 'حي الأمير', license: 'MOH-CL-21950', phone: '07816677112', email: 'alnoor.clinic@mail.iq', specialties: ['طب الأسرة'], rooms: 2, status: 'rejected', submittedAt: iso(-15), reviewedAt: now - 12 * day, reviewedBy: 'م. زهراء الكعبي', reason: 'رخصة وزارة الصحة منتهية الصلاحية', manager: { name: 'أ. جعفر النجفي', gender: 'm', status: 'inactive' } })
    ];

    d.clinics.forEach((c, i) => {
        c.manager.userId = `U-${4001 + i}`;
        c.manager.email = c.email;
        c.manager.phone = c.phone;
        if (!d.users.some(u => u.id === c.manager.userId)) {
            d.users.push({
                id: c.manager.userId, role: 'clinic', clinicId: c.id, name: c.manager.name, gender: c.manager.gender,
                email: c.email, phone: c.phone, city: c.city, joined: c.submittedAt,
                lastLogin: c.manager.status === 'active' ? now - (i + 2) * 3600000 : null
            });
        }
    });

    // سجل العمليات الخاص بالعيادات
    const admin = id => { const u = d.users.find(x => x.id === id); return { id: u.id, name: u.name, role: 'admin' }; };
    const mgr = c => ({ id: c.manager.userId, name: c.manager.name, role: 'clinic' });
    d.clinics.filter(c => c.status === 'pending' || c.id === 'CL-03' || c.id === 'CL-07').forEach((c, i) => {
        d.logs.push({ action: 'submit_clinic', actor: mgr(c), records: [c.id, c.manager.userId], details: `تقديم طلب تسجيل ${c.name} — ${c.city}`, at: parseISO(c.submittedAt).getTime() + (9 + i) * 3600000 });
    });
    d.logs.push({ action: 'approve_clinic', actor: admin('U-3001'), records: ['CL-03', 'U-4003'], details: 'قبول طلب مركز النخبة للجلدية (حساب المدير غير مفعّل بعد)', at: now - 2 * day });
    d.logs.push({ action: 'reject_clinic', actor: admin('U-3002'), records: ['CL-07', 'U-4007'], details: 'رفض طلب عيادة النور العامة: رخصة وزارة الصحة منتهية الصلاحية', at: now - 12 * day });
    d.logs = d.logs.filter(l => l.at <= now).sort((a, b) => b.at - a.at);
    d.logs.forEach((l, i) => { l.id = `LOG-${7400 + d.logs.length - i}`; });

    d.notifs.unshift({ icon: '🏥', text: `${d.clinics.filter(c => c.status === 'pending').length} طلبات تسجيل عيادات بانتظار المراجعة`, t: now - 600000, unread: true });
}

// دمج طلبات التسجيل المرسلة من صفحة «تسجيل عيادة» (Shared/clinic-register.html)
function mergeClinicRequests(d) {
    const reqs = rawGet('smartClinic_clinicRequests') || [];
    const WD = { 6: 'السبت', 0: 'الأحد', 1: 'الإثنين', 2: 'الثلاثاء', 3: 'الأربعاء', 4: 'الخميس', 5: 'الجمعة' };
    const t12 = t => fmtTime(t).replace(/^0/, '');
    let added = 0;
    reqs.forEach(r => {
        if (d.clinics.some(c => c.reqId === r.reqId)) return;
        const num = Math.max(...d.clinics.map(c => Number(c.id.split('-')[1]))) + 1;
        const id = `CL-${pad(num)}`;
        let uid = `U-${4000 + num}`;
        while (d.users.some(u => u.id === uid)) uid = `U-${Number(uid.split('-')[1]) + 1}`;
        const docNames = (r.docs || []).map(x => x.name);
        const days = [6, 0, 1, 2, 3, 4, 5].filter(x => r.hours.days.includes(x)).map(x => WD[x]);
        d.clinics.push({
            id, reqId: r.reqId, name: r.name, type: r.type, city: r.city, address: r.address, license: r.license,
            phone: r.phone, email: r.email, specialties: r.specialties, rooms: r.rooms,
            hours: `${days.length > 3 ? days[0] + ' – ' + days[days.length - 1] : days.join('، ')} · ${t12(r.hours.from)} – ${t12(r.hours.to)}`,
            docs: REQUIRED_DOCS.filter(n => docNames.includes(n)),
            status: 'pending', submittedAt: r.submittedAt, reviewedAt: null, reviewedBy: '', reason: '',
            manager: { name: r.manager.name, gender: 'm', status: 'inactive', userId: uid, email: r.manager.email, phone: r.manager.phone }
        });
        d.users.push({ id: uid, role: 'clinic', clinicId: id, name: r.manager.name, gender: 'm', email: r.manager.email, phone: r.manager.phone, city: r.city, joined: r.submittedAt, lastLogin: null });
        const max = Math.max(7400, ...d.logs.map(l => Number(l.id.split('-')[1])));
        d.logs.unshift({ id: `LOG-${max + 1}`, action: 'submit_clinic', actor: { id: uid, name: r.manager.name, role: 'clinic' }, records: [id, uid, r.reqId], details: `تقديم طلب تسجيل ${r.name} — ${r.city}`, at: r.submittedTs || Date.now() });
        d.notifs.unshift({ icon: '🏥', text: `طلب تسجيل عيادة جديد: ${r.name} (${r.city})`, t: Date.now(), unread: true });
        added++;
    });
    return added;
}

function fillClinicFilters() {
    const f = state.clinicFilter;
    $('#clinicCity').innerHTML = '<option value="">جميع المدن</option>' + [...new Set(D().clinics.map(c => c.city))].map(c => `<option>${c}</option>`).join('');
    $('#clinicType').innerHTML = '<option value="">جميع الأنواع</option>' + [...new Set(D().clinics.map(c => c.type))].map(c => `<option>${c}</option>`).join('');
    $('#clinicCity').value = f.city;
    $('#clinicType').value = f.type;
}

function bindClinics() {
    // طلب جديد من تبويب آخر يظهر فوراً
    window.addEventListener('storage', e => {
        if (e.key !== 'smartClinic_clinicRequests') return;
        const n = mergeClinicRequests(D());
        if (!n) return;
        saveData();
        renderNotifs();
        updateBadges();
        const b = $('#notifBtn');
        b.classList.remove('ring'); void b.offsetWidth; b.classList.add('ring');
        toast(`🏥 وصل ${n === 1 ? 'طلب تسجيل عيادة جديد' : n + ' طلبات تسجيل عيادات'}`, 'info');
        if (['clinics', 'dashboard'].includes(state.page)) refreshAll();
    });
    const f = state.clinicFilter;
    let t;
    $('#clinicSearch').addEventListener('input', e => { clearTimeout(t); t = setTimeout(() => { f.q = e.target.value.trim(); renderClinics(); }, 200); });
    $('#clinicCity').addEventListener('change', e => { f.city = e.target.value; renderClinics(); });
    $('#clinicType').addEventListener('change', e => { f.type = e.target.value; renderClinics(); });
    $('#clinicChips').addEventListener('click', e => {
        const c = e.target.closest('[data-status]');
        if (c) { f.status = c.dataset.status; renderClinics(); }
    });
}

function clinicMatches(c, key) {
    if (!key) return true;
    if (key === 'inactive') return c.status === 'approved' && c.manager.status === 'inactive';
    return c.status === key;
}

function clinicActions(c, compact = true) {
    const sz = compact ? 'xs' : 'sm';
    const b = (cls, act, label) => `<button class="btn ${cls} ${sz}" data-act="${act}" data-id="${c.id}">${label}</button>`;
    const view = compact ? b('light', 'clinic-view', '👁 مراجعة البيانات') : '';
    if (c.status === 'pending') return view + b('success', 'clinic-approve', '✓ قبول') + b('danger-light', 'clinic-reject', '✕ رفض');
    if (c.status === 'rejected') return view + b('light', 'clinic-review', '↺ إعادة المراجعة');
    if (c.manager.status === 'inactive') return view + b('teal', 'clinic-activate', '🔑 تفعيل حساب المدير');
    if (c.manager.status === 'disabled') return view + b('teal', 'clinic-activate', '▶ إعادة تفعيل المدير');
    return view + b('warn', 'clinic-disable', '⏸ تعطيل حساب المدير');
}

function renderClinics() {
    const f = state.clinicFilter;
    $('#clinicSearch').value = f.q;
    fillClinicFilters();

    const base = D().clinics.filter(c => (!f.city || c.city === f.city) && (!f.type || c.type === f.type));
    $('#clinicChips').innerHTML = [['', 'الكل'], ['pending', 'بانتظار المراجعة'], ['approved', 'مقبولة'], ['rejected', 'مرفوضة'], ['inactive', '🔑 مدراء بانتظار التفعيل']]
        .map(([k, l]) => `<button class="chip ${f.status === k ? 'active' : ''}" data-status="${k}">${l} <b>${base.filter(c => clinicMatches(c, k)).length}</b></button>`).join('');

    const q = normalize(f.q);
    const list = base
        .filter(c => clinicMatches(c, f.status))
        .filter(c => !q || normalize(`${c.name} ${c.id} ${c.license} ${c.manager.name} ${c.email} ${c.city}`).includes(q))
        .sort((a, b) => (a.status === 'pending' ? 0 : 1) - (b.status === 'pending' ? 0 : 1) || b.submittedAt.localeCompare(a.submittedAt));

    $('#clinicGrid').innerHTML = list.length ? list.map((c, i) => {
        const S = CLINIC_STATUS[c.status], M = MANAGER_STATUS[c.manager.status];
        const docsOk = c.docs.length, docsPct = Math.round((docsOk / REQUIRED_DOCS.length) * 100);
        return `
        <article class="doc-card ${c.status === 'pending' ? 'pending' : ''}" style="--i:${i}" data-ccard="${c.id}">
            ${c.status === 'pending' ? '<span class="ribbon">طلب جديد</span>' : ''}
            <div class="dc-head">
                <span class="pt-avatar">🏥</span>
                <div>
                    <button class="link-btn" data-act="clinic-view" data-id="${c.id}"><strong>${esc(c.name)}</strong></button>
                    <small>${c.id} · ${c.type} · ${c.city}</small>
                </div>
            </div>
            <div class="hero-buttons">
                <span class="badge ${S.cls}">${S.label}</span>
                ${c.status === 'approved' ? `<span class="badge ${M.cls}">${M.label}</span>` : ''}
            </div>
            <div class="dc-meta">
                <div>رقم الترخيص<b dir="ltr">${c.license}</b></div>
                <div>تاريخ التقديم<b>${relDay(c.submittedAt)}</b></div>
                <div>مدير العيادة<b>${esc(c.manager.name)}</b></div>
                <div>الاختصاصات<b>${c.specialties.length} · ${c.rooms} غرف</b></div>
            </div>
            <div class="docs-meter">
                <span>الوثائق ${docsOk}/${REQUIRED_DOCS.length}</span>
                <div class="hbar-track"><i style="background:${docsPct === 100 ? 'var(--success)' : 'var(--orange)'}" data-w="${docsPct}"></i></div>
            </div>
            ${c.reason ? `<small class="muted">📝 ${esc(c.reason)}</small>` : ''}
            <div class="dc-actions">${clinicActions(c)}</div>
        </article>`;
    }).join('') : '<div class="empty-state" style="grid-column:1/-1"><div class="empty-icon">🏥</div><h3>لا توجد عيادات مطابقة</h3><p>غيّر البحث أو الفلاتر.</p></div>';

    requestAnimationFrame(() => requestAnimationFrame(() => {
        $$('#clinicGrid .docs-meter i').forEach(x => { x.style.width = x.dataset.w + '%'; });
    }));
}

function openClinicDrawer(id) {
    const c = getClinic(id);
    if (!c) return;
    const S = CLINIC_STATUS[c.status], M = MANAGER_STATUS[c.manager.status];
    const missing = REQUIRED_DOCS.filter(x => !c.docs.includes(x));
    const logs = D().logs.filter(l => l.records.includes(c.id)).slice(0, 5);
    openDrawer(`
        <div class="drawer-head">
            <span class="pt-avatar">🏥</span>
            <div>
                <h2>${esc(c.name)}</h2>
                <span class="muted small">${c.id} · ${c.type}</span><br>
                <span class="badge ${S.cls}">${S.label}</span>
                ${c.status === 'approved' ? `<span class="badge ${M.cls}">${M.label}</span>` : ''}
            </div>
        </div>
        <p class="access-note">📋 راجع بيانات العيادة والوثائق قبل اتخاذ القرار. ${c.reviewedAt ? `آخر مراجعة: ${esc(c.reviewedBy)} · ${timeAgo(c.reviewedAt)}` : `قُدّم الطلب ${relDay(c.submittedAt)}`}</p>
        ${c.reason ? `<div class="alert-box danger">📝 <b>سبب الرفض:</b> ${esc(c.reason)}</div>` : ''}

        <div class="drawer-section">
            <h4>بيانات العيادة</h4>
            <div class="detail-grid">
                <div><span>نوع المنشأة</span><b>${c.type}</b></div>
                <div><span>رقم الترخيص</span><b dir="ltr">${c.license}</b></div>
                <div><span>المدينة</span><b>${c.city}</b></div>
                <div><span>العنوان</span><b>${esc(c.address)}</b></div>
                <div><span>الهاتف</span><b dir="ltr">${c.phone}</b></div>
                <div><span>البريد الإلكتروني</span><b dir="ltr">${c.email}</b></div>
                <div><span>عدد الغرف</span><b>${c.rooms}</b></div>
                <div><span>أوقات العمل</span><b>${c.hours}</b></div>
            </div>
            <div class="pt-tags">${c.specialties.map(s => `<span class="tag info">${s}</span>`).join('')}</div>
        </div>

        <div class="drawer-section">
            <h4>مدير العيادة</h4>
            <div class="detail-grid">
                <div><span>الاسم</span><b>${esc(c.manager.name)}</b></div>
                <div><span>معرف الحساب</span><b>${c.manager.userId}</b></div>
                <div><span>البريد (اسم الدخول)</span><b dir="ltr">${c.manager.email}</b></div>
                <div><span>حالة الحساب</span><b><span class="badge ${M.cls}">${M.label}</span></b></div>
            </div>
            ${c.status !== 'approved' ? '<div class="alert-box info">ℹ️ لا يمكن تفعيل حساب المدير قبل قبول طلب العيادة.</div>' : ''}
        </div>

        <div class="drawer-section">
            <h4>الوثائق المطلوبة (${c.docs.length}/${REQUIRED_DOCS.length})</h4>
            <div class="docs-list">
                ${REQUIRED_DOCS.map(x => c.docs.includes(x)
                    ? `<a href="#" data-doc="${esc(x)}.pdf">✅ ${x} <small>معاينة</small></a>`
                    : `<a href="#" class="missing" onclick="return false">❌ ${x} <small>غير مرفقة</small></a>`).join('')}
            </div>
            ${missing.length ? `<div class="alert-box danger mt">⚠️ وثائق ناقصة: ${missing.join('، ')} — لا يمكن قبول الطلب قبل استكمالها.</div>` : ''}
        </div>

        <div class="drawer-section">
            <h4>سجل العمليات على العيادة</h4>
            <div class="mini-list">
                ${logs.length ? logs.map(l => `<div class="mini-item"><span class="act-badge ${ACTIONS[l.action].cls}">${ACTIONS[l.action].icon}</span><div class="up-info"><strong>${ACTIONS[l.action].label}</strong><small>${esc(l.actor.name)} · ${timeAgo(l.at)}</small></div></div>`).join('') : '<p class="muted small">لا توجد عمليات مسجلة.</p>'}
            </div>
        </div>

        <div class="hero-buttons">${clinicActions(c, false)}</div>`);
}

function syncClinicUi(c, msg) {
    const card = $(`[data-ccard="${c.id}"]`);
    if (card && state.clinicFilter.status && !clinicMatches(c, state.clinicFilter.status)) {
        card.classList.add('leaving');
        setTimeout(refreshAll, 320);
    } else refreshAll();
    if ($('#drawer').classList.contains('open')) openClinicDrawer(c.id);
    toast(msg, 'success');
}

async function clinicAction(act, id) {
    const c = getClinic(id);
    if (!c) return;
    if (act === 'clinic-view') { openClinicDrawer(id); return; }
    if (act === 'clinic-approve') { openClinicApprove(c); return; }
    if (act === 'clinic-reject') { openClinicReject(c); return; }

    if (act === 'clinic-activate') {
        if (c.status !== 'approved') { toast('يجب قبول طلب العيادة أولاً', 'error'); return; }
        const re = c.manager.status === 'disabled';
        const ok = await confirmDialog({
            title: `${re ? 'إعادة تفعيل' : 'تفعيل'} حساب مدير العيادة؟`,
            text: `سيتمكن ${esc(c.manager.name)} من الدخول إلى لوحة ${esc(c.name)}${re ? '' : `، وسيتم إرسال بيانات الدخول إلى <b dir="ltr">${c.manager.email}</b>`}.`,
            ok: '🔑 تفعيل الحساب', icon: '🔑'
        });
        if (!ok) return;
        c.manager.status = 'active';
        addLog('activate_manager', [c.id, c.manager.userId], `${re ? 'إعادة تفعيل' : 'تفعيل'} حساب مدير ${c.name}: ${c.manager.name}`);
        notify('🔑', `تم تفعيل حساب مدير ${c.name}`);
        saveData();
        syncClinicUi(c, re ? 'تمت إعادة تفعيل حساب المدير' : 'تم تفعيل الحساب وإرسال بيانات الدخول ✉️');
    }

    if (act === 'clinic-disable') {
        const ok = await confirmDialog({
            title: 'تعطيل حساب مدير العيادة؟',
            text: `لن يتمكن ${esc(c.manager.name)} من الدخول إلى لوحة ${esc(c.name)} حتى إعادة التفعيل. تبقى العيادة وأطباؤها ومواعيدها كما هي.`,
            ok: '⏸ تعطيل', danger: true, icon: '⏸'
        });
        if (!ok) return;
        c.manager.status = 'disabled';
        addLog('suspend_account', [c.manager.userId, c.id], `تعطيل حساب مدير ${c.name}: ${c.manager.name}`);
        saveData();
        syncClinicUi(c, 'تم تعطيل حساب مدير العيادة');
    }

    if (act === 'clinic-review') {
        const ok = await confirmDialog({ title: 'إعادة الطلب للمراجعة؟', text: `سيعود طلب ${esc(c.name)} إلى قائمة الطلبات المعلقة.`, ok: '↺ إعادة المراجعة', icon: '↺' });
        if (!ok) return;
        c.status = 'pending'; c.reason = ''; c.reviewedAt = Date.now(); c.reviewedBy = me().name;
        addLog('review_clinic', [c.id, c.manager.userId], `إعادة طلب ${c.name} للمراجعة`);
        saveData();
        syncClinicUi(c, 'أُعيد الطلب إلى قائمة المراجعة');
    }
}

function openClinicApprove(c) {
    const missing = REQUIRED_DOCS.filter(x => !c.docs.includes(x));
    const checks = [
        ['license', 'الترخيص الصحي ساري ومطابق لبيانات العيادة'],
        ['address', 'العنوان ومعلومات التواصل صحيحة'],
        ['docs', 'جميع الوثائق المطلوبة مرفقة وواضحة'],
        ['manager', 'بيانات مدير العيادة صحيحة ومطابقة للهوية']
    ];
    openModal(`
        <div class="confirm">
            <div class="confirm-icon success">🏥</div>
            <h3>قبول طلب ${esc(c.name)}</h3>
            <p class="muted">${c.license} · ${c.city} · ${c.manager.name}</p>
        </div>
        <form id="clinicApproveForm" data-id="${c.id}" novalidate>
            <div class="form-group mt">
                <label>قائمة التحقق قبل القبول <span class="req">*</span></label>
                <div class="checklist">
                    ${checks.map(([k, l]) => {
                        const blocked = k === 'docs' && missing.length;
                        return `<label class="check-wrap ${blocked ? 'blocked' : ''}"><input type="checkbox" name="chk" value="${k}" ${blocked ? 'disabled' : ''}><span class="check-box"></span> ${l}${blocked ? ` <small>(ناقصة: ${missing.join('، ')})</small>` : ''}</label>`;
                    }).join('')}
                </div>
                <small class="error-text"></small>
            </div>
            <div class="form-group">
                <label class="check-wrap activate-opt"><input type="checkbox" name="activate" checked><span class="check-box"></span> تفعيل حساب مدير العيادة مباشرة وإرسال بيانات الدخول إلى <b dir="ltr">${c.manager.email}</b></label>
            </div>
            <div class="confirm-actions">
                <button type="button" class="btn light" data-close-modal>تراجع</button>
                <button type="submit" class="btn success" ${missing.length ? 'disabled title="الوثائق ناقصة"' : ''}>✓ قبول العيادة</button>
            </div>
        </form>`);
}

function submitClinicApprove(form) {
    const c = getClinic(form.dataset.id);
    const boxes = $$('input[name=chk]', form);
    const group = boxes[0].closest('.form-group');
    if (!boxes.every(b => b.checked)) {
        setError(boxes[0], 'أكمل جميع عناصر قائمة التحقق قبل القبول');
        shake(form);
        return;
    }
    setError(boxes[0], '');
    const activate = form.elements.activate.checked;
    setLoading($('[type=submit]', form), true);
    setTimeout(() => {
        c.status = 'approved'; c.reason = '';
        c.reviewedAt = Date.now(); c.reviewedBy = me().name;
        c.manager.status = activate ? 'active' : 'inactive';
        addLog('approve_clinic', [c.id, c.manager.userId], `قبول طلب ${c.name} — ${c.city}${activate ? '' : ' (حساب المدير غير مفعّل بعد)'}`);
        if (activate) addLog('activate_manager', [c.id, c.manager.userId], `تفعيل حساب مدير ${c.name}: ${c.manager.name}`);
        notify('✅', `تم قبول ${c.name}`);
        saveData();
        closeModal();
        syncClinicUi(c, activate ? 'تم قبول العيادة وتفعيل حساب المدير 🎉' : 'تم قبول العيادة — حساب المدير بانتظار التفعيل');
        void group;
    }, 700);
}

function openClinicReject(c) {
    const reasons = ['رخصة وزارة الصحة غير سارية', 'وثائق ناقصة أو غير واضحة', 'بيانات العيادة غير مطابقة', 'أخرى'];
    openModal(`
        <div class="confirm">
            <div class="confirm-icon danger">✕</div>
            <h3>رفض طلب ${esc(c.name)}</h3>
            <p class="muted">سيتم إبلاغ مدير العيادة بسبب الرفض عبر البريد الإلكتروني.</p>
            <form id="clinicRejectForm" data-id="${c.id}" novalidate>
                <div class="form-group">
                    <div class="reason-list">${reasons.map(r => `<label><input type="radio" name="reason" value="${r}"> ${r}</label>`).join('')}</div>
                    <small class="error-text"></small>
                </div>
                <div class="form-group">
                    <textarea class="field" name="note" rows="2" placeholder="ملاحظة للعيادة (مطلوبة عند اختيار «أخرى»)"></textarea>
                    <small class="error-text"></small>
                </div>
                <div class="confirm-actions">
                    <button type="button" class="btn light" data-close-modal>تراجع</button>
                    <button type="submit" class="btn danger">تأكيد الرفض</button>
                </div>
            </form>
        </div>`);
}

function submitClinicReject(form) {
    const c = getClinic(form.dataset.id);
    const reason = form.elements.reason.value, note = form.elements.note.value.trim();
    let ok = setError($('.reason-list', form), reason ? '' : 'اختر سبب الرفض');
    ok = setError(form.elements.note, reason === 'أخرى' && note.length < 3 ? 'اكتب السبب' : '') && ok;
    if (!ok) { shake(form); return; }
    setLoading($('[type=submit]', form), true);
    setTimeout(() => {
        const text = reason === 'أخرى' ? note : reason + (note ? ` — ${note}` : '');
        c.status = 'rejected'; c.reason = text;
        c.reviewedAt = Date.now(); c.reviewedBy = me().name;
        c.manager.status = 'inactive';
        addLog('reject_clinic', [c.id, c.manager.userId], `رفض طلب ${c.name}: ${text}`);
        saveData();
        closeModal();
        syncClinicUi(c, 'تم رفض الطلب وإبلاغ العيادة');
    }, 650);
}


/* =================== الأحداث العامة =================== */
function refreshAll() { renderPage(state.page); }

function handleAction(act, id, el) {
    if (act.startsWith('clinic-')) { clinicAction(act, id); return; }
    if (act.startsWith('doc-') && act !== 'doc-view') { doctorAction(act, id); return; }
    switch (act) {
        case 'doc-view': openDoctorDrawer(id); break;
        case 'user-view': openUserDrawer(id); break;
        case 'appt-view': openApptModal(id); break;
        case 'pay-refund': openRefund(id); break;
        case 'pay-retry': retryPayment(id, el); break;
        case 'pay-find':
            state.payFilter = { q: id, status: '', method: '', from: '', to: '' };
            state.pages.pay = 1;
            go('payments');
            break;
    }
}

document.addEventListener('click', e => {
    const inModal = e.target.closest('#modal');

    const pg = e.target.closest('[data-pg]');
    if (pg && !pg.disabled) {
        state.pages[pg.dataset.pg] = Number(pg.dataset.to);
        ({ users: renderUsers, appt: renderApptList, pay: renderPayments, log: renderAudit })[pg.dataset.pg]();
        return;
    }

    const nav = e.target.closest('a[data-page], [data-go]');
    if (nav) {
        e.preventDefault();
        if (inModal) closeModal();
        closeDrawer();
        go(nav.dataset.page || nav.dataset.go);
        return;
    }

    const act = e.target.closest('[data-act]');
    if (act && !act.disabled && act.tagName !== 'FORM') {
        if (inModal) closeModal();
        const keepDrawer = ['doc-view', 'user-view'].includes(act.dataset.act) || act.dataset.act.startsWith('doc-') || act.dataset.act.startsWith('clinic-');
        if (!keepDrawer) closeDrawer();
        handleAction(act.dataset.act, act.dataset.id, act);
    }

    const docLink = e.target.closest('[data-doc]');
    if (docLink) { e.preventDefault(); toast(`معاينة «${docLink.dataset.doc}» (تجريبي)`, 'info'); }
});

document.addEventListener('pointerdown', e => {
    const b = e.target.closest('.btn');
    if (!b || b.disabled) return;
    const r = b.getBoundingClientRect();
    const size = Math.max(r.width, r.height);
    const s = document.createElement('span');
    s.className = 'ripple';
    s.style.width = s.style.height = size + 'px';
    s.style.left = (e.clientX - r.left - size / 2) + 'px';
    s.style.top = (e.clientY - r.top - size / 2) + 'px';
    b.appendChild(s);
    setTimeout(() => s.remove(), 650);
});

function bindApp() {
    const modal = $('#modal');
    modal.addEventListener('click', e => {
        if (e.target === modal || e.target.closest('[data-close-modal]')) { closeModal(); return; }
        const c = e.target.closest('[data-confirm]');
        if (c && modalResolver) {
            const r = modalResolver;
            modalResolver = null;
            closeModal();
            r(c.dataset.confirm === 'yes');
        }
    });
    $('#modalBody').addEventListener('submit', e => {
        e.preventDefault();
        if (e.target.id === 'reasonForm') submitReason(e.target);
        if (e.target.id === 'refundForm') submitRefund(e.target);
        if (e.target.id === 'clinicApproveForm') submitClinicApprove(e.target);
        if (e.target.id === 'clinicRejectForm') submitClinicReject(e.target);
    });
    $('#modalBody').addEventListener('change', e => {
        if (e.target.name === 'reason' && e.target.type === 'radio') setError($('.reason-list'), '');
        else if (e.target.closest('.form-group.has-error')) setError(e.target, '');
    });
    $('#modalBody').addEventListener('input', e => {
        if (e.target.closest('.form-group.has-error')) setError(e.target, '');
    });

    const drawer = $('#drawer');
    drawer.addEventListener('click', e => {
        if (e.target === drawer || e.target.closest('[data-close-drawer]')) closeDrawer();
    });

    $('#menuToggle').addEventListener('click', () => document.body.classList.toggle('sidebar-open'));
    $('#sidebarOverlay').addEventListener('click', () => document.body.classList.remove('sidebar-open'));

    $('#notifBtn').addEventListener('click', e => {
        e.stopPropagation();
        const panel = $('#notifPanel');
        panel.classList.toggle('open');
        if (panel.classList.contains('open')) {
            setTimeout(() => { D().notifs.forEach(n => { n.unread = false; }); saveData(); $('#notifCount').hidden = true; }, 1200);
        } else renderNotifs();
    });
    $('#clearNotifs').addEventListener('click', () => { D().notifs = []; saveData(); renderNotifs(); });
    document.addEventListener('click', e => {
        if (!e.target.closest('.notif-wrap') && $('#notifPanel').classList.contains('open')) {
            $('#notifPanel').classList.remove('open');
            renderNotifs();
        }
    });

    $('#paySeg').addEventListener('click', e => {
        const b = e.target.closest('[data-range]');
        if (!b) return;
        state.payRange = b.dataset.range;
        $$('#paySeg button').forEach(x => x.classList.toggle('active', x === b));
        renderPayStatusSummary();
    });

    $('#logoutBtn').addEventListener('click', logout);
    $('#resetData').addEventListener('click', async () => {
        const ok = await confirmDialog({ title: 'إعادة ضبط البيانات؟', text: 'سيتم حذف جميع التغييرات وإعادة إنشاء البيانات التجريبية.', ok: 'إعادة الضبط', danger: true, icon: '↺' });
        if (!ok) return;
        state.data = generateData();
        addClinicsData(state.data);
        state.policyDraft = null;
        saveData();
        renderNotifs();
        refreshAll();
        toast('تمت إعادة ضبط البيانات التجريبية', 'success');
    });

    window.addEventListener('scroll', () => $('#topbar').classList.toggle('scrolled', window.scrollY > 8), { passive: true });
    window.addEventListener('resize', moveIndicator);
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(moveIndicator);
    window.addEventListener('hashchange', () => {
        const h = location.hash.replace('#', '');
        if (h && h !== state.page) go(h);
    });
    window.addEventListener('beforeunload', e => {
        if (policyChanged().length) { e.preventDefault(); e.returnValue = ''; }
    });

    document.addEventListener('keydown', e => {
        if (e.key !== 'Escape') return;
        if ($('#modal').classList.contains('open')) closeModal();
        else if ($('#drawer').classList.contains('open')) closeDrawer();
        else { $('#notifPanel').classList.remove('open'); document.body.classList.remove('sidebar-open'); }
    });

    bindDoctors();
    bindUsers();
    bindAppointments();
    bindPayments();
    bindAudit();
    bindClinics();
    bindChartTips();
}


/* =================== الجلسة وتسجيل الخروج =================== */
function checkSession() {
    const s = rawGet('scAdmin_session') || rawGet('scAdmin_session', sessionStorage);
    if (s && s.role === 'admin') return s;
    window.__adminBooted = true; // جاري التحويل لصفحة الدخول
    const role = rawGet('smartClinic_role');
    if (role && role !== 'admin') location.replace('../Shared/403.html?from=admin');
    else location.replace('../Shared/login.html?role=admin&denied=1');
    return null;
}

function logout() {
    confirmDialog({ title: 'تسجيل الخروج؟', text: 'سيتم إنهاء جلستك في لوحة الإدارة.', ok: 'تسجيل الخروج', danger: true, icon: '🚪' })
        .then(ok => {
            if (!ok) return;
            addLog('logout', [me().id], 'خروج من لوحة الإدارة');
            saveData();
            rawDel('scAdmin_session');
            rawDel('smartClinic_role');
            $('#pageLoader').classList.remove('hide');
            setTimeout(() => location.replace('../Shared/login.html?role=admin&logout=1'), 600);
        });
}


/* =================== التشغيل =================== */
let secCounter = 0;
function tick() {
    $('#liveClock').textContent = new Intl.DateTimeFormat('ar-u-nu-latn', { hour: '2-digit', minute: '2-digit', second: '2-digit' }).format(new Date());
    secCounter++;
    if (secCounter % 15 === 0 && $('#simToggle').checked) tickQueues();
    if (secCounter % 5 === 0 && state.page === 'appointments' && state.apptView === 'queues') {
        $('#queueUpdated').textContent = `آخر تحديث: ${timeAgo(state.lastQueueUpdate)} · متوسط الكشف ${D().policies.queueAvg} د`;
    }
}

function init() {
    state.session = checkSession();
    if (!state.session) return;

    loadData();
    const admin = me();
    if (state.session.fresh) {
        addLog('login', [admin.id], 'دخول ناجح إلى لوحة الإدارة');
        state.session.fresh = false;
        const store = rawGet('scAdmin_session') ? localStorage : sessionStorage;
        rawSet('scAdmin_session', state.session, store);
        saveData();
    }

    $('#adminApp').hidden = false;
    const initial = admin.name.replace('أ. ', '').charAt(0);
    $('#sideAvatar').textContent = $('#topAvatar').textContent = initial;
    $('#sideName').textContent = $('#topName').textContent = admin.name;

    bindApp();
    renderNotifs();

    const start = location.hash.replace('#', '') || 'dashboard';
    go(start);
    requestAnimationFrame(moveIndicator);
    setInterval(tick, 1000);
    tick();
    window.__adminBooted = true;
}

function hideLoader() {
    if (!window.__adminBooted) return; // إبقاء رسالة الخطأ ظاهرة إن فشل التشغيل
    const l = $('#pageLoader'); if (l) l.classList.add('hide'); moveIndicator();
}
window.addEventListener('load', () => setTimeout(hideLoader, 300));
setTimeout(hideLoader, 2500);

init();
hideLoader();

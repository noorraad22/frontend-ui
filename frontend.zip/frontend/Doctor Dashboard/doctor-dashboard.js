/* =========================================================
   العيادة الذكية — لوحة تحكم الطبيب
   doctor-dashboard.js
   ملاحظة: جميع البيانات تجريبية وتُحفظ في متصفحك فقط (localStorage)
   ========================================================= */
'use strict';

/* =================== أدوات مساعدة =================== */
const $ = (sel, ctx = document) => ctx.querySelector(sel);
const $$ = (sel, ctx = document) => Array.from(ctx.querySelectorAll(sel));

const pad = n => String(n).padStart(2, '0');
const toISO = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const addDays = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
const todayISO = () => toISO(new Date());
const parseISO = s => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); };
const fmtDate = (iso, opts = { weekday: 'long', day: 'numeric', month: 'long' }) =>
    new Intl.DateTimeFormat('ar-u-nu-latn', opts).format(parseISO(iso));
const fmtTime = t => {
    let [h, m] = t.split(':').map(Number);
    const s = h >= 12 ? 'م' : 'ص';
    h = h % 12 || 12;
    return `${pad(h)}:${pad(m)} ${s}`;
};
const hmOf = ts => { const d = new Date(ts); return fmtTime(`${pad(d.getHours())}:${pad(d.getMinutes())}`); };
const fmtMoney = n => Number(n || 0).toLocaleString('en-US') + ' د.ع';
const fmtClock = sec => { sec = Math.max(0, Math.floor(sec)); return `${pad(Math.floor(sec / 60))}:${pad(sec % 60)}`; };
const relDay = iso => {
    const t = todayISO();
    if (iso === t) return 'اليوم';
    if (iso === toISO(addDays(new Date(), 1))) return 'غداً';
    if (iso === toISO(addDays(new Date(), -1))) return 'أمس';
    return fmtDate(iso, { weekday: 'short', day: 'numeric', month: 'short' });
};
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const normalize = s => String(s).replace(/[ً-ْـ]/g, '').replace(/[أإآ]/g, 'ا').replace(/ة/g, 'ه').replace(/ى/g, 'ي').toLowerCase();
const ageOf = birth => {
    const b = parseISO(birth), n = new Date();
    let a = n.getFullYear() - b.getFullYear();
    if (n.getMonth() < b.getMonth() || (n.getMonth() === b.getMonth() && n.getDate() < b.getDate())) a--;
    return a;
};
const isEmail = v => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);

function shake(el) { if (!el) return; el.classList.remove('shake'); void el.offsetWidth; el.classList.add('shake'); }
function setLoading(btn, on) { if (!btn) return; btn.classList.toggle('loading', on); btn.disabled = on; }

const storeOf = s => ({
    get(k, d) { try { const v = s.getItem('scDoctor_' + k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
    set(k, v) { try { s.setItem('scDoctor_' + k, JSON.stringify(v)); } catch (e) { /* تجاهل */ } },
    del(k) { try { s.removeItem('scDoctor_' + k); } catch (e) { /* تجاهل */ } }
});
const LS = storeOf(window.localStorage);
const SS = storeOf(window.sessionStorage);


/* =================== البيانات الثابتة =================== */
const DOCTOR = {
    name: 'د. سارة أحمد', first: 'سارة', title: 'دكتورة',
    specialty: 'أمراض القلب', email: 'doctor@smartclinic.iq', password: '123456'
};

const CLINICS = [
    { id: 'c1', name: 'عيادة الكرادة التخصصية', city: 'بغداد', fee: 25000, prefix: 'A' },
    { id: 'c2', name: 'مستشفى الحياة الأهلي', city: 'بغداد', fee: 35000, prefix: 'H' }
];

const PATIENTS = [
    { id: 'P-10231', name: 'علي حسن', gender: 'm', birth: '1978-03-14', phone: '07701234567', blood: 'O+', allergies: ['البنسلين'], chronic: ['ارتفاع ضغط الدم'] },
    { id: 'P-10244', name: 'زينب كاظم', gender: 'f', birth: '1985-07-22', phone: '07801122334', blood: 'A+', allergies: [], chronic: [] },
    { id: 'P-10258', name: 'محمد كريم', gender: 'm', birth: '1962-11-02', phone: '07709988776', blood: 'B+', allergies: [], chronic: ['السكري النوع الثاني', 'ارتفاع الكوليسترول'] },
    { id: 'P-10263', name: 'نور حسين', gender: 'f', birth: '1994-01-30', phone: '07512233445', blood: 'AB+', allergies: ['الأسبرين'], chronic: [] },
    { id: 'P-10277', name: 'حيدر عبد الأمير', gender: 'm', birth: '1955-05-18', phone: '07714455667', blood: 'O-', allergies: [], chronic: ['قصور القلب', 'ارتفاع ضغط الدم'] },
    { id: 'P-10281', name: 'فاطمة جاسم', gender: 'f', birth: '1958-09-09', phone: '07823344556', blood: 'A-', allergies: [], chronic: ['ارتفاع ضغط الدم'] },
    { id: 'P-10295', name: 'حسين علي', gender: 'm', birth: '1989-12-12', phone: '07735566778', blood: 'B-', allergies: [], chronic: [] },
    { id: 'P-10302', name: 'مريم صادق', gender: 'f', birth: '2001-04-05', phone: '07506677889', blood: 'O+', allergies: ['اللاكتوز'], chronic: [] },
    { id: 'P-10318', name: 'عباس فاضل', gender: 'm', birth: '1970-08-25', phone: '07747788990', blood: 'A+', allergies: [], chronic: ['ارتفاع الكوليسترول'] },
    { id: 'P-10326', name: 'رقية مهدي', gender: 'f', birth: '1966-02-17', phone: '07838899001', blood: 'B+', allergies: [], chronic: ['السكري النوع الثاني'] },
    { id: 'P-10339', name: 'أحمد سلمان', gender: 'm', birth: '1983-06-21', phone: '07759900112', blood: 'AB-', allergies: [], chronic: [] },
    { id: 'P-10345', name: 'سجى رعد', gender: 'f', birth: '1997-10-10', phone: '07520011223', blood: 'A+', allergies: ['السلفا'], chronic: [] },
    { id: 'P-10357', name: 'كرار ناصر', gender: 'm', birth: '1992-03-03', phone: '07761122334', blood: 'O+', allergies: [], chronic: [] },
    { id: 'P-10364', name: 'هدى عادل', gender: 'f', birth: '1949-12-29', phone: '07852233445', blood: 'O+', allergies: [], chronic: ['اضطراب نظم القلب', 'ارتفاع ضغط الدم'] },
    { id: 'P-10371', name: 'مصطفى جواد', gender: 'm', birth: '1975-01-16', phone: '07773344556', blood: 'B+', allergies: [], chronic: [] },
    { id: 'P-10386', name: 'بنين حميد', gender: 'f', birth: '2010-07-07', phone: '07534455667', blood: 'A-', allergies: [], chronic: [] }
];

const DIAGNOSES = [
    'ارتفاع ضغط الدم', 'خفقان قلب حميد', 'ألم صدر غير قلبي المنشأ', 'متابعة قصور القلب',
    'اضطراب نظم القلب البسيط', 'ارتفاع الكوليسترول', 'فحص دوري للقلب — طبيعي'
];
const DRUGS = [
    { drug: 'Amlodipine', dose: '5 mg', freq: 'مرة يومياً', days: 30 },
    { drug: 'Bisoprolol', dose: '2.5 mg', freq: 'مرة يومياً', days: 30 },
    { drug: 'Atorvastatin', dose: '20 mg', freq: 'مساءً', days: 30 },
    { drug: 'Aspirin', dose: '81 mg', freq: 'مرة يومياً', days: 30 },
    { drug: 'Omeprazole', dose: '20 mg', freq: 'مرة يومياً', days: 14 },
    { drug: 'Paracetamol', dose: '500 mg', freq: 'عند الحاجة', days: 5 }
];
const FREQS = ['مرة يومياً', 'مرتين يومياً', 'ثلاث مرات يومياً', 'مساءً', 'عند الحاجة'];
const NOTES = [
    'الضغط ضمن المعدل المقبول، الاستمرار على العلاج.',
    'تخطيط القلب طبيعي. يُنصح بتقليل الملح والمشي يومياً.',
    'طُلب تحليل دهون شامل قبل المراجعة القادمة.',
    'تحسن ملحوظ مقارنة بالزيارة السابقة.',
    'يُنصح بإجراء إيكو للقلب.'
];
const REASONS = ['كشف جديد', 'مراجعة', 'متابعة نتائج تحاليل', 'متابعة علاج'];
const CANCEL_REASONS = ['ظرف طارئ لدى الطبيب', 'بطلب من المريض', 'تعارض في جدول العيادة', 'أخرى'];

const STATUS = {
    confirmed: { label: 'محجوز', cls: 'primary', color: '#1463ff', icon: '📅' },
    waiting:   { label: 'في الانتظار', cls: 'warning', color: '#f59e0b', icon: '⏳' },
    in:        { label: 'داخل الاستشارة', cls: 'purple live', color: '#7c3aed', icon: '🩺' },
    completed: { label: 'مكتمل', cls: 'success', color: '#16a34a', icon: '✓' },
    noshow:    { label: 'لم يحضر', cls: 'muted', color: '#94a3b8', icon: '✕' },
    cancelled: { label: 'ملغى', cls: 'danger', color: '#e5484d', icon: '⊘' }
};
const PAY_STATUS = {
    paid:     { label: 'مدفوع', cls: 'success' },
    unpaid:   { label: 'غير مدفوع', cls: 'warning' },
    refunded: { label: 'مسترد', cls: 'muted' },
    none:     { label: 'لا يوجد', cls: 'muted' }
};
const METHODS = {
    cash:   { label: 'نقداً', color: '#1463ff' },
    card:   { label: 'بطاقة مصرفية', color: '#12b5a5' },
    wallet: { label: 'محفظة إلكترونية', color: '#f59e0b' }
};

const PAGES = ['dashboard', 'appointments', 'queue', 'consultation', 'patients', 'reports'];
const PAGE_INFO = {
    dashboard:    ['لوحة التحكم', 'ملخص عملك اليوم'],
    appointments: ['جدول المواعيد', 'إدارة مواعيد المرضى وتحديث حالاتها'],
    queue:        ['إدارة الطابور', 'ترتيب المرضى ومتابعة الدور مباشرة'],
    consultation: ['واجهة الاستشارة', 'التشخيص والوصفة الطبية والملاحظات'],
    patients:     ['المرضى', 'المرضى الذين راجعوك وملفاتهم الطبية'],
    reports:      ['التقارير والمدفوعات', 'إحصائيات الأداء والمدفوعات حسب الفترة']
};


/* =================== توليد البيانات التجريبية =================== */
function seededRandom(seed) {
    return () => {
        seed |= 0; seed = seed + 0x6D2B79F5 | 0;
        let t = Math.imul(seed ^ seed >>> 15, 1 | seed);
        t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
        return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
}

function slotsFor(clinic) {
    const [start, end] = clinic.id === 'c1' ? [10, 14] : [16, 22];
    const s = [];
    for (let h = start; h < end; h++) { s.push(`${pad(h)}:00`); s.push(`${pad(h)}:30`); }
    return s;
}

function generateData() {
    const R = seededRandom(20261122);
    const pick = arr => arr[Math.floor(R() * arr.length)];
    const now = Date.now();
    const appts = [];
    let idc = 41200;

    const makeConsult = (time) => {
        const rx = [];
        const n = 1 + Math.floor(R() * 3);
        const pool = [...DRUGS];
        for (let i = 0; i < n; i++) rx.push({ ...pool.splice(Math.floor(R() * pool.length), 1)[0] });
        const duration = pick([10, 15, 15, 20, 30]);
        return {
            duration, actual: duration + Math.floor(R() * 7) - 3,
            diagnosis: pick(DIAGNOSES), rx, notes: pick(NOTES), followUp: '', time
        };
    };

    for (let off = -60; off <= 7; off++) {
        const day = addDays(new Date(), off);
        const wd = day.getDay();
        if (wd === 5) continue; // الجمعة عطلة
        const iso = toISO(day);
        const isToday = off === 0;

        const sessions = isToday ? CLINICS : [[6, 1, 3].includes(wd) ? CLINICS[0] : CLINICS[1]];

        sessions.forEach(clinic => {
            let times = slotsFor(clinic);
            if (!isToday) {
                const count = off > 0 ? 2 + Math.floor(R() * 5) : 5 + Math.floor(R() * 6);
                times = times.map(t => [t, R()]).sort((a, b) => a[1] - b[1]).slice(0, count).map(x => x[0]).sort();
            } else if (clinic.id === 'c1') {
                times = times.slice(0, 7);
            }

            const used = new Set();
            const todayPlan = clinic.id === 'c1'
                ? ['completed', 'completed', 'noshow', 'completed', 'completed', 'cancelled', 'completed']
                : ['completed', 'completed', 'completed', 'completed', 'waiting', 'waiting', 'waiting', 'waiting', 'confirmed', 'confirmed', 'confirmed', 'confirmed'];

            times.forEach((time, i) => {
                let p;
                do { p = pick(PATIENTS); } while (used.has(p.id) && used.size < PATIENTS.length);
                used.add(p.id);

                let status;
                if (isToday) status = todayPlan[i] || 'confirmed';
                else if (off > 0) status = 'confirmed';
                else { const r = R(); status = r < 0.78 ? 'completed' : r < 0.88 ? 'cancelled' : 'noshow'; }

                const payment = pick(['cash', 'cash', 'card', 'wallet']);
                let paymentStatus;
                if (status === 'completed') paymentStatus = 'paid';
                else if (status === 'cancelled') paymentStatus = payment === 'cash' ? 'none' : 'refunded';
                else if (status === 'noshow') paymentStatus = payment === 'cash' ? 'none' : 'paid';
                else paymentStatus = payment === 'cash' ? 'unpaid' : 'paid';

                const a = {
                    id: 'SC-' + (idc += 1 + Math.floor(R() * 40)),
                    patientId: p.id, clinicId: clinic.id, date: iso, time,
                    queueNo: `${clinic.prefix}-${pad(i + 1)}`,
                    order: i + 1, status, fee: clinic.fee, payment, paymentStatus,
                    reason: pick(REASONS), bookingNote: R() < 0.3 ? 'يشعر بضيق في التنفس عند صعود الدرج' : ''
                };
                if (status === 'completed') a.consult = makeConsult(time);
                if (status === 'cancelled') a.cancelReason = pick(CANCEL_REASONS.slice(0, 3));
                if (status === 'waiting') a.arrivedAt = now - (40 - i * 6) * 60000;
                appts.push(a);
            });
        });
    }

    const todayCount = appts.filter(a => a.date === todayISO() && a.status !== 'cancelled').length;
    return {
        v: 1, seedDate: todayISO(), appts,
        settings: { avg: 15 },
        notifs: [
            { icon: '📅', text: `لديك ${todayCount} موعداً اليوم في عيادتين`, t: now - 3600000, unread: true },
            { icon: '💳', text: 'تم استلام دفعة إلكترونية لموعد الغد', t: now - 7200000, unread: false }
        ]
    };
}


/* =================== الحالة العامة =================== */
const state = {
    data: null,
    page: 'dashboard',
    apptFilter: { q: '', date: todayISO(), clinic: '', status: '' },
    queueClinic: '',
    payRange: 'today',
    report: { period: '7', from: '', to: '', clinic: '', limit: 15 },
    patientQ: '',
    patientSort: 'recent',
    loginFails: 0,
    lockUntil: 0,
    overtimeWarned: {},
    draftTimer: null
};

function loadData() {
    let d = LS.get('data', null);
    if (!d || d.v !== 1 || d.seedDate !== todayISO()) d = generateData();
    state.data = d;
    saveData();
}
function saveData() { LS.set('data', state.data); }

const appts = () => state.data.appts;
const findAppt = id => appts().find(a => a.id === id);
const patientOf = a => PATIENTS.find(p => p.id === (a.patientId || a));
const clinicOf = a => CLINICS.find(c => c.id === (a.clinicId || a));
const byTime = (a, b) => (a.date + a.time).localeCompare(b.date + b.time);
const ptIcon = p => {
    const age = ageOf(p.birth);
    if (age < 14) return p.gender === 'f' ? '👧' : '👦';
    if (age >= 60) return p.gender === 'f' ? '👵' : '👴';
    return p.gender === 'f' ? '👩' : '👨';
};
const todayAppts = (clinic = '') => appts().filter(a => a.date === todayISO() && (!clinic || a.clinicId === clinic));
const waitingList = (clinic = '') => todayAppts(clinic).filter(a => a.status === 'waiting').sort((a, b) => a.order - b.order);
const activeConsult = () => appts().find(a => a.status === 'in' && a.date === todayISO());


/* =================== الإشعارات المنبثقة والنوافذ =================== */
function toast(msg, type = 'success') {
    const icons = { success: '✓', error: '!', info: 'i', warning: '!' };
    const el = document.createElement('div');
    el.className = `toast ${type}`;
    el.innerHTML = `<span class="toast-icon">${icons[type] || 'i'}</span><span>${msg}</span>`;
    $('#toastStack').appendChild(el);
    requestAnimationFrame(() => requestAnimationFrame(() => el.classList.add('show')));
    setTimeout(() => { el.classList.remove('show'); setTimeout(() => el.remove(), 500); }, 3300);
}

let modalResolver = null;

function openModal(html, size = '') {
    const m = $('#modal');
    $('#modalBody').innerHTML = html;
    m.className = 'modal open ' + size;
    m.setAttribute('aria-hidden', 'false');
    document.body.classList.add('no-scroll');
}

function closeModal() {
    const m = $('#modal');
    if (!m.classList.contains('open')) return;
    m.classList.remove('open');
    m.setAttribute('aria-hidden', 'true');
    if (!$('#drawer').classList.contains('open')) document.body.classList.remove('no-scroll');
    if (modalResolver) { const r = modalResolver; modalResolver = null; r(false); }
}

function confirmDialog({ title, text, ok = 'تأكيد', danger = false, icon = '⚠️' }) {
    return new Promise(resolve => {
        openModal(`
            <div class="confirm">
                <div class="confirm-icon ${danger ? 'danger' : ''}">${icon}</div>
                <h3>${title}</h3>
                <p class="muted">${text}</p>
                <div class="confirm-actions">
                    <button class="btn light" data-confirm="no">تراجع</button>
                    <button class="btn ${danger ? 'danger' : 'primary'}" data-confirm="yes">${ok}</button>
                </div>
            </div>`);
        modalResolver = resolve;
    });
}

function openDrawer(html) {
    $('#drawerBody').innerHTML = html;
    $('#drawer').classList.add('open');
    $('#drawer').setAttribute('aria-hidden', 'false');
    document.body.classList.add('no-scroll');
    $('.drawer-panel').scrollTop = 0;
}
function closeDrawer() {
    $('#drawer').classList.remove('open');
    $('#drawer').setAttribute('aria-hidden', 'true');
    if (!$('#modal').classList.contains('open')) document.body.classList.remove('no-scroll');
}

function setError(input, msg) {
    const g = input && input.closest('.form-group');
    if (!g) return;
    g.classList.toggle('has-error', !!msg);
    const e = $('.error-text', g);
    if (e) e.textContent = msg || '';
}


/* =================== الإشعارات (الجرس) =================== */
function notify(icon, text) {
    state.data.notifs.unshift({ icon, text, t: Date.now(), unread: true });
    state.data.notifs = state.data.notifs.slice(0, 20);
    saveData();
    renderNotifs();
    const b = $('#notifBtn');
    b.classList.remove('ring'); void b.offsetWidth; b.classList.add('ring');
}

function timeAgo(t) {
    const m = Math.floor((Date.now() - t) / 60000);
    if (m < 1) return 'الآن';
    if (m < 60) return `منذ ${m} دقيقة`;
    const h = Math.floor(m / 60);
    return h < 24 ? `منذ ${h} ساعة` : `منذ ${Math.floor(h / 24)} يوم`;
}

function renderNotifs() {
    const list = state.data.notifs;
    const unread = list.filter(n => n.unread).length;
    const c = $('#notifCount');
    c.hidden = !unread;
    c.textContent = unread;
    $('#notifList').innerHTML = list.length
        ? list.map(n => `
            <div class="notif-item ${n.unread ? 'unread' : ''}">
                <span class="ni-icon">${n.icon}</span>
                <div>${esc(n.text)}<small>${timeAgo(n.t)}</small></div>
            </div>`).join('')
        : '<div class="notif-empty">لا توجد إشعارات 🎉</div>';
}


/* =================== تسجيل الدخول =================== */
const isLogged = () => !!(LS.get('session', null) || SS.get('session', null));

function showLoginAlert(msg, type = '') {
    const a = $('#loginAlert');
    a.hidden = false;
    a.className = 'form-alert ' + type;
    a.innerHTML = `<span>${msg}</span>`;
}

function bindLogin() {
    const form = $('#loginForm');
    const email = $('#loginEmail'), pass = $('#loginPassword');

    $('#togglePass').addEventListener('click', () => {
        pass.type = pass.type === 'password' ? 'text' : 'password';
        $('#togglePass').textContent = pass.type === 'password' ? '👁' : '🙈';
    });
    $('#fillDemo').addEventListener('click', () => {
        email.value = DOCTOR.email;
        pass.value = DOCTOR.password;
        setError(email, ''); setError(pass, '');
        toast('تمت تعبئة بيانات الحساب التجريبي', 'info');
    });
    $('#forgotBtn').addEventListener('click', () => {
        showLoginAlert('ℹ️ لإعادة تعيين كلمة المرور تواصل مع إدارة العيادة.', 'info');
    });
    [email, pass].forEach(i => i.addEventListener('input', () => setError(i, '')));

    form.addEventListener('submit', e => {
        e.preventDefault();
        if (Date.now() < state.lockUntil) return;

        const ev = email.value.trim(), pv = pass.value;
        let ok = true;
        if (!ev) { setError(email, 'البريد الإلكتروني مطلوب'); ok = false; }
        else if (!isEmail(ev)) { setError(email, 'صيغة البريد الإلكتروني غير صحيحة'); ok = false; }
        else setError(email, '');
        if (!pv) { setError(pass, 'كلمة المرور مطلوبة'); ok = false; }
        else if (pv.length < 6) { setError(pass, 'كلمة المرور يجب أن تكون 6 أحرف على الأقل'); ok = false; }
        else setError(pass, '');

        if (!ok) { $('#loginAlert').hidden = true; shake(form); return; }

        const btn = $('#loginBtn');
        setLoading(btn, true);
        setTimeout(() => {
            setLoading(btn, false);
            if (ev.toLowerCase() !== DOCTOR.email || pv !== DOCTOR.password) {
                state.loginFails++;
                const left = 5 - state.loginFails;
                if (left <= 0) {
                    lockLogin();
                } else {
                    showLoginAlert(`⚠️ البريد الإلكتروني أو كلمة المرور غير صحيحة. المحاولات المتبقية: <b>${left}</b>`);
                }
                shake(form);
                return;
            }

            state.loginFails = 0;
            const session = { email: DOCTOR.email, at: Date.now() };
            if ($('#rememberMe').checked) LS.set('session', session); else SS.set('session', session);

            showLoginAlert('✓ تم التحقق بنجاح، جاري توجيهك إلى لوحة التحكم...', 'success');
            setLoading(btn, true);
            setTimeout(() => {
                setLoading(btn, false);
                $('#loginScreen').classList.add('leaving');
                setTimeout(() => {
                    $('#loginScreen').classList.remove('leaving');
                    enterApp();
                    toast(`أهلاً بعودتك ${DOCTOR.title} ${DOCTOR.first} 👋`, 'success');
                }, 550);
            }, 900);
        }, 900);
    });
}

function lockLogin() {
    state.lockUntil = Date.now() + 30000;
    const btn = $('#loginBtn');
    btn.disabled = true;
    const timer = setInterval(() => {
        const s = Math.ceil((state.lockUntil - Date.now()) / 1000);
        if (s <= 0) {
            clearInterval(timer);
            btn.disabled = false;
            state.loginFails = 0;
            showLoginAlert('يمكنك المحاولة مجدداً الآن.', 'info');
            return;
        }
        showLoginAlert(`🔒 تم تجاوز عدد المحاولات المسموح. حاول مجدداً بعد <b>${s}</b> ثانية.`);
    }, 250);
}

function showLogin() {
    $('#doctorApp').hidden = true;
    $('#loginScreen').hidden = false;
    $('#loginAlert').hidden = true;
    $('#loginForm').reset();
    $('#rememberMe').checked = true;
    closeModal(); closeDrawer();
}

function enterApp() {
    $('#loginScreen').hidden = true;
    $('#doctorApp').hidden = false;
    const initial = DOCTOR.first.charAt(0);
    ['#sideAvatar', '#topAvatar'].forEach(s => { $(s).textContent = initial; });
    $('#sideName').textContent = $('#topName').textContent = DOCTOR.name;
    $('#sideSpec').textContent = $('#topSpec').textContent = DOCTOR.specialty;
    renderNotifs();

    const start = location.hash.replace('#', '');
    state.page = '';
    go(PAGES.includes(start) ? start : 'dashboard');
    requestAnimationFrame(moveIndicator);
}

function logout() {
    confirmDialog({ title: 'تسجيل الخروج؟', text: 'سيتم إنهاء جلستك في لوحة التحكم.', ok: 'تسجيل الخروج', danger: true, icon: '🚪' })
        .then(ok => {
            if (!ok) return;
            LS.del('session'); SS.del('session');
            try { history.replaceState(null, '', location.pathname); } catch (e) { /* تجاهل */ }
            showLogin();
            toast('تم تسجيل الخروج بنجاح', 'info');
        });
}


/* =================== التنقل =================== */
function go(page) {
    if (!PAGES.includes(page)) return;
    closeSidebar();
    if (page !== state.page) {
        $$('.page').forEach(p => p.classList.toggle('active', p.dataset.page === page));
        $$('.side-link').forEach(l => l.classList.toggle('active', l.dataset.page === page));
        state.page = page;
        moveIndicator();
        try { history.replaceState(null, '', '#' + page); } catch (e) { /* تجاهل */ }
        const [t, s] = PAGE_INFO[page];
        $('#pageTitle').textContent = t;
        $('#pageSub').textContent = s;
        const tt = $('.topbar-title');
        tt.classList.remove('swap'); void tt.offsetWidth; tt.classList.add('swap');
    }
    renderPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function renderPage(page = state.page) {
    ({
        dashboard: renderDashboard,
        appointments: renderAppointments,
        queue: renderQueue,
        consultation: renderConsultation,
        patients: renderPatients,
        reports: renderReports
    })[page]();
    updateBadges();
}

// تحديث الصفحة الحالية (لا نعيد رسم الاستشارة حتى لا تضيع الكتابة)
function refresh() {
    if (state.page === 'consultation') updateBadges();
    else renderPage();
}

function moveIndicator() {
    const a = $('.side-link.active'), ind = $('#sideIndicator');
    if (!a || !ind) return;
    ind.style.height = a.offsetHeight + 'px';
    ind.style.transform = `translateY(${a.offsetTop}px)`;
}

function updateBadges() {
    const t = todayAppts();
    const remaining = t.filter(a => ['confirmed', 'waiting', 'in'].includes(a.status)).length;
    const waiting = t.filter(a => a.status === 'waiting').length;
    $('#badgeAppts').textContent = remaining || '';
    $('#badgeQueue').textContent = waiting || '';
    $('#dotConsult').hidden = !activeConsult();
}

function closeSidebar() { document.body.classList.remove('sidebar-open'); }


/* =================== الرسوم البيانية =================== */
function renderBarChart(el, items, color = '#1463ff') {
    if (!items.length) { el.innerHTML = '<p class="chart-empty">لا توجد بيانات</p>'; return; }
    const max = Math.max(1, ...items.map(x => x.value));
    const step = Math.ceil(items.length / 8);
    const showVals = items.length <= 14;

    el.classList.remove('ready');
    el.innerHTML =
        `<div class="grid-line" style="bottom:calc(30px + (100% - 56px) * .5)"></div>
         <div class="grid-line" style="bottom:calc(30px + (100% - 56px))"></div>` +
        items.map((x, i) => {
            const pct = (x.value / max) * 100;
            return `
            <div class="bar-col" data-tip="${esc(x.tip)}">
                ${showVals ? `<span class="bar-val" data-b="${pct}">${x.value}</span>` : ''}
                <div class="bar" style="--i:${i}; background:${color}" data-h="${pct}"></div>
                ${i % step === 0 || i === items.length - 1 ? `<span class="bar-label">${x.label}</span>` : ''}
            </div>`;
        }).join('');

    requestAnimationFrame(() => requestAnimationFrame(() => {
        $$('.bar', el).forEach(b => { b.style.height = `max(${b.dataset.h}%, ${b.dataset.h > 0 ? 4 : 2}px)`; });
        $$('.bar-val', el).forEach(v => { v.style.bottom = v.dataset.b + '%'; });
        el.classList.add('ready');
    }));
}

function bindChartTips() {
    const tip = $('#chartTip');
    document.addEventListener('mousemove', e => {
        const col = e.target.closest('.bar-col');
        if (!col) { tip.classList.remove('show'); return; }
        const r = col.getBoundingClientRect();
        tip.textContent = col.dataset.tip;
        tip.style.left = (r.left + r.width / 2) + 'px';
        tip.style.top = (r.top + 18) + 'px';
        tip.classList.add('show');
    });
}

function renderStack(el, parts) {
    const total = parts.reduce((s, p) => s + p.value, 0);
    if (!total) { el.innerHTML = '<p class="chart-empty muted">لا توجد مواعيد في هذه الفترة</p>'; return; }
    el.innerHTML = `
        <div class="stack-bar">
            ${parts.filter(p => p.value).map(p => `<i style="background:${p.color}" data-w="${(p.value / total) * 100}" title="${p.label}: ${p.value}"></i>`).join('')}
        </div>
        <div class="legend">
            ${parts.map(p => `
                <div class="legend-row">
                    <i class="sw" style="background:${p.color}"></i>
                    <span>${p.icon} ${p.label}</span>
                    <b>${p.value}</b>
                    <em>${Math.round((p.value / total) * 100)}%</em>
                </div>`).join('')}
        </div>`;
    requestAnimationFrame(() => requestAnimationFrame(() => {
        $$('.stack-bar i', el).forEach(i => { i.style.width = i.dataset.w + '%'; });
    }));
}

function renderHBars(el, rows) {
    const max = Math.max(1, ...rows.map(r => r.value));
    el.innerHTML = rows.map(r => `
        <div class="hbar-row">
            <span>${r.label}</span>
            <div class="hbar-track"><i style="background:${r.color}" data-w="${(r.value / max) * 100}"></i></div>
            <b>${r.text}</b>
        </div>`).join('');
    requestAnimationFrame(() => requestAnimationFrame(() => {
        $$('.hbar-track i', el).forEach(i => { i.style.width = i.dataset.w + '%'; });
    }));
}

function statCard({ icon, label, value, sub, color = '#1463ff', money = false, trend = '' }, i) {
    return `
    <div class="stat-card card-anim" style="--c:${color}; --i:${i}">
        <div class="stat-top"><span class="stat-icon">${icon}</span>${trend}</div>
        <p>${label}</p>
        <h2 data-count="${value}" data-money="${money ? 1 : ''}">0</h2>
        <small>${sub}</small>
    </div>`;
}

function animateCounts(root) {
    $$('[data-count]', root).forEach(el => {
        const target = Number(el.dataset.count), money = !!el.dataset.money;
        const start = performance.now(), dur = 1100;
        const step = now => {
            const p = Math.min((now - start) / dur, 1);
            const v = Math.round(target * (1 - Math.pow(1 - p, 3)));
            el.textContent = money ? fmtMoney(v) : v;
            if (p < 1) requestAnimationFrame(step);
        };
        requestAnimationFrame(step);
    });
}


/* =================== 10. لوحة التحكم =================== */
function renderDashboard() {
    const h = new Date().getHours();
    const t = todayAppts();
    const active = t.filter(a => a.status !== 'cancelled');
    const waiting = waitingList();
    const done = t.filter(a => a.status === 'completed');
    const cur = activeConsult();

    $('#todayLabel').textContent = fmtDate(todayISO(), { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
    $('#greeting').textContent = `${h < 12 ? 'صباح الخير' : 'مساء الخير'} ${DOCTOR.title} ${DOCTOR.first} 👋`;
    $('#welcomeSub').textContent = `لديك ${active.length} موعداً اليوم، ${waiting.length} في الانتظار و ${done.length} مكتملة.`;
    $('#callNextHero').textContent = cur ? 'فتح الاستشارة الجارية ←' : 'استدعاء المريض التالي ▶';

    // المريض الحالي / التالي
    const wc = $('#welcomeCurrent');
    if (cur) {
        const p = patientOf(cur);
        wc.innerHTML = `
            <small>المريض الحالي</small>
            <div class="wc-num">${cur.queueNo}</div>
            <strong>${esc(p.name)}</strong>
            <div class="wc-row"><span>⏱ <b id="wcTimer">—</b></span><span class="badge purple live">داخل الاستشارة</span></div>
            <button class="btn light sm block" data-go="consultation">فتح الاستشارة ←</button>`;
    } else if (waiting.length) {
        const n = waiting[0], p = patientOf(n);
        wc.innerHTML = `
            <small>المريض التالي</small>
            <div class="wc-num">${n.queueNo}</div>
            <strong>${esc(p.name)}</strong>
            <div class="wc-row"><span>${esc(n.reason)}</span><span>في الانتظار منذ ${Math.max(1, Math.round((Date.now() - n.arrivedAt) / 60000))} د</span></div>
            <button class="btn light sm block" data-act="start" data-id="${n.id}">بدء الاستشارة ▶</button>`;
    } else {
        wc.innerHTML = '<small>الطابور</small><strong>لا يوجد مرضى في الانتظار ☕</strong><small>سيظهر هنا المريض التالي عند وصوله.</small>';
    }

    // الإحصائيات
    const patientsTotal = new Set(appts().filter(a => a.status === 'completed').map(a => a.patientId)).size;
    const todayRevenue = t.filter(a => a.paymentStatus === 'paid').reduce((s, a) => s + a.fee, 0);
    $('#dashStats').innerHTML = [
        { icon: '📅', label: 'مواعيد اليوم', value: active.length, sub: `${t.filter(a => a.status === 'cancelled').length} ملغاة`, color: '#1463ff' },
        { icon: '👥', label: 'عدد المرضى', value: patientsTotal, sub: 'مرضى راجعوك', color: '#12b5a5' },
        { icon: '⏳', label: 'في الانتظار', value: waiting.length, sub: `${done.length} استشارات مكتملة اليوم`, color: '#f59e0b' },
        { icon: '💰', label: 'مدفوعات اليوم', value: todayRevenue, sub: 'المبالغ المستلمة', color: '#7c3aed', money: true }
    ].map(statCard).join('');
    animateCounts($('#dashStats'));

    // المواعيد القادمة
    const nowKey = todayISO() + `${pad(new Date().getHours())}:${pad(new Date().getMinutes())}`;
    const upcoming = appts()
        .filter(a => a.status === 'waiting' || (a.status === 'confirmed' && (a.date + a.time >= nowKey || a.date === todayISO())))
        .sort((a, b) => (a.status === 'waiting' ? 0 : 1) - (b.status === 'waiting' ? 0 : 1) || byTime(a, b))
        .slice(0, 6);
    $('#upcomingList').innerHTML = upcoming.length ? upcoming.map((a, i) => {
        const p = patientOf(a), st = STATUS[a.status];
        return `
        <div class="up-item card-anim" style="--i:${i}">
            <div class="up-time">${fmtTime(a.time)}<small>${relDay(a.date)}</small></div>
            <span class="pt-avatar">${ptIcon(p)}</span>
            <div class="up-info">
                <button class="link-btn" data-act="patient" data-id="${p.id}">${esc(p.name)}</button>
                <small>${a.queueNo} · ${esc(a.reason)} · ${clinicOf(a).name}</small>
            </div>
            <span class="badge ${st.cls}">${st.label}</span>
        </div>`;
    }).join('') : '<div class="empty-state"><div class="empty-icon">🗓️</div><h3>لا توجد مواعيد قادمة</h3></div>';

    renderPaySummary();

    // آخر 7 أيام
    const week = [];
    for (let i = 6; i >= 0; i--) {
        const iso = toISO(addDays(new Date(), -i));
        const v = appts().filter(a => a.date === iso && a.status === 'completed').length;
        week.push({ label: relDay(iso).split('،')[0], value: v, tip: `${fmtDate(iso)}: ${v} استشارة مكتملة` });
    }
    renderBarChart($('#weekChart'), week);

    // حالة مواعيد اليوم
    renderStack($('#todayStatus'), ['completed', 'in', 'waiting', 'confirmed', 'noshow', 'cancelled'].map(k => ({
        label: STATUS[k].label, icon: STATUS[k].icon, color: STATUS[k].color,
        value: t.filter(a => a.status === k).length
    })));

    updateLiveTimers();
}

function renderPaySummary() {
    const now = new Date();
    const from = state.payRange === 'today' ? todayISO() : toISO(new Date(now.getFullYear(), now.getMonth(), 1));
    const list = appts().filter(a => a.date >= from && a.date <= todayISO());
    const sum = f => list.filter(f).reduce((s, a) => s + a.fee, 0);
    const paid = sum(a => a.paymentStatus === 'paid');
    const unpaid = sum(a => a.paymentStatus === 'unpaid' && a.status !== 'cancelled');
    const refunded = sum(a => a.paymentStatus === 'refunded');
    const total = paid + unpaid || 1;

    $('#paySummary').innerHTML = `
        <div class="pay-total">
            <div><span>المبالغ المستلمة</span><br><strong>${fmtMoney(paid)}</strong></div>
            <span>${Math.round((paid / total) * 100)}% من المستحق</span>
        </div>
        <div class="progress">
            <i style="background:#16a34a" data-w="${(paid / total) * 100}"></i>
            <i style="background:#f59e0b" data-w="${(unpaid / total) * 100}"></i>
        </div>
        <div class="pay-rows">
            <div class="pay-row"><span><i class="sw" style="background:#16a34a"></i>مدفوع</span><b>${fmtMoney(paid)}</b></div>
            <div class="pay-row"><span><i class="sw" style="background:#f59e0b"></i>بانتظار الدفع (في العيادة)</span><b>${fmtMoney(unpaid)}</b></div>
            <div class="pay-row"><span><i class="sw" style="background:#94a3b8"></i>مبالغ مستردة</span><b>${fmtMoney(refunded)}</b></div>
            ${Object.entries(METHODS).map(([k, m]) => `
                <div class="pay-row"><span><i class="sw" style="background:${m.color}"></i>${m.label}</span>
                <b>${fmtMoney(list.filter(a => a.payment === k && a.paymentStatus === 'paid').reduce((s, a) => s + a.fee, 0))}</b></div>`).join('')}
        </div>`;
    requestAnimationFrame(() => requestAnimationFrame(() => {
        $$('#paySummary .progress i').forEach(i => { i.style.width = i.dataset.w + '%'; });
    }));
}


/* =================== الإجراءات على المواعيد =================== */
function checkIn(a, auto = false) {
    a.status = 'waiting';
    a.arrivedAt = Date.now();
    a.order = Math.max(0, ...waitingList().map(x => x.order)) + 1;
    saveData();
    const name = patientOf(a).name;
    notify('🚶', `وصل المريض ${name} (${a.queueNo}) وأُضيف إلى الطابور`);
    toast(auto ? `🚶 وصل المريض ${name} (${a.queueNo})` : `تم تسجيل حضور ${name}`, auto ? 'info' : 'success');
    refresh();
}

function startConsult(a) {
    if (!a) return;
    const cur = activeConsult();
    if (cur && cur.id !== a.id) {
        confirmDialog({
            title: 'توجد استشارة جارية',
            text: `أنت الآن في استشارة مع ${patientOf(cur).name} (${cur.queueNo}). أنهِها أولاً قبل بدء استشارة جديدة.`,
            ok: 'الذهاب للاستشارة', icon: '🩺'
        }).then(ok => ok && go('consultation'));
        return;
    }
    if (a.date !== todayISO()) { toast('يمكن بدء الاستشارة في يوم الموعد فقط', 'error'); return; }
    if (cur && cur.id === a.id) { go('consultation'); return; }
    if (!a.arrivedAt) a.arrivedAt = Date.now();
    a.status = 'in';
    a.consult = { duration: state.data.settings.avg, startedAt: null };
    saveData();
    toast(`📣 تم استدعاء ${patientOf(a).name} (${a.queueNo})`, 'success');
    go('consultation');
}

function callNext() {
    const cur = activeConsult();
    if (cur) { go('consultation'); return; }
    const next = waitingList(state.page === 'queue' ? state.queueClinic : '')[0] || waitingList()[0];
    if (!next) { toast('لا يوجد مرضى في الانتظار حالياً', 'info'); return; }
    startConsult(next);
}

function markNoShow(a) {
    confirmDialog({
        title: 'تسجيل عدم الحضور؟',
        text: `سيتم تسجيل ${patientOf(a).name} (${a.queueNo}) كمريض لم يحضر وإزالته من الطابور.`,
        ok: 'تأكيد', danger: true, icon: '🚫'
    }).then(ok => {
        if (!ok) return;
        a.status = 'noshow';
        if (a.paymentStatus === 'unpaid') a.paymentStatus = 'none';
        saveData();
        toast('تم تسجيل عدم حضور المريض', 'success');
        refresh();
    });
}

function openCancel(a) {
    // الصلاحيات: يمكن إلغاء المواعيد المحجوزة أو المنتظرة فقط، ولا يمكن تعديل المواعيد السابقة
    if (!['confirmed', 'waiting'].includes(a.status) || a.date < todayISO()) {
        toast('لا تملك صلاحية إلغاء هذا الموعد', 'error');
        return;
    }
    const p = patientOf(a);
    openModal(`
        <div class="confirm">
            <div class="confirm-icon danger">🗓️</div>
            <h3>إلغاء موعد ${esc(p.name)}</h3>
            <p class="muted">${a.queueNo} · ${relDay(a.date)} · ${fmtTime(a.time)}</p>
            <form id="cancelForm" data-id="${a.id}" novalidate>
                <div class="form-group">
                    <div class="reason-list">
                        ${CANCEL_REASONS.map(r => `<label><input type="radio" name="reason" value="${r}"> ${r}</label>`).join('')}
                    </div>
                    <small class="error-text"></small>
                </div>
                <div class="form-group">
                    <textarea class="field" name="other" rows="2" placeholder="ملاحظة إضافية (مطلوبة عند اختيار «أخرى»)"></textarea>
                    <small class="error-text"></small>
                </div>
                ${a.paymentStatus === 'paid' ? '<div class="alert-box info">💳 سيتم استرداد المبلغ المدفوع إلكترونياً للمريض.</div>' : ''}
                <div class="confirm-actions">
                    <button type="button" class="btn light" data-close-modal>تراجع</button>
                    <button type="submit" class="btn danger">تأكيد الإلغاء</button>
                </div>
            </form>
        </div>`);
}

function submitCancel(form) {
    const a = findAppt(form.dataset.id);
    const reason = form.elements.reason.value;
    const other = form.elements.other.value.trim();
    let ok = true;
    if (!reason) { setError($('.reason-list', form), 'اختر سبب الإلغاء'); ok = false; } else setError($('.reason-list', form), '');
    if (reason === 'أخرى' && other.length < 3) { setError(form.elements.other, 'اكتب سبب الإلغاء'); ok = false; } else setError(form.elements.other, '');
    if (!ok) { shake(form); return; }

    setLoading($('[type=submit]', form), true);
    setTimeout(() => {
        a.status = 'cancelled';
        a.cancelReason = reason === 'أخرى' ? other : reason + (other ? ` — ${other}` : '');
        if (a.paymentStatus === 'paid') a.paymentStatus = 'refunded';
        else if (a.paymentStatus === 'unpaid') a.paymentStatus = 'none';
        saveData();
        closeModal();
        toast('تم إلغاء الموعد وإبلاغ المريض', 'success');
        notify('⊘', `تم إلغاء موعد ${patientOf(a).name} (${a.queueNo})`);
        refresh();
    }, 700);
}

function openDetails(a) {
    const p = patientOf(a), c = clinicOf(a), st = STATUS[a.status], ps = PAY_STATUS[a.paymentStatus];
    const k = a.consult && a.status === 'completed' ? a.consult : null;
    openModal(`
        <h2 class="modal-title">تفاصيل الموعد ${a.id}</h2>
        <div class="detail-grid">
            <div><span>المريض</span><b>${esc(p.name)}</b></div>
            <div><span>رقم الطابور</span><b>${a.queueNo}</b></div>
            <div><span>التاريخ والوقت</span><b>${fmtDate(a.date)} · ${fmtTime(a.time)}</b></div>
            <div><span>العيادة</span><b>${c.name}</b></div>
            <div><span>سبب الزيارة</span><b>${esc(a.reason)}</b></div>
            <div><span>الحالة</span><b><span class="badge ${st.cls}">${st.label}</span></b></div>
            <div><span>أجور المعاينة</span><b>${fmtMoney(a.fee)}</b></div>
            <div><span>الدفع</span><b>${METHODS[a.payment].label} · <span class="badge ${ps.cls}">${ps.label}</span></b></div>
            ${a.arrivedAt ? `<div><span>وقت الوصول</span><b>${hmOf(a.arrivedAt)}</b></div>` : ''}
            ${a.cancelReason ? `<div><span>سبب الإلغاء</span><b>${esc(a.cancelReason)}</b></div>` : ''}
        </div>
        ${a.bookingNote ? `<div class="alert-box note">📝 ملاحظة المريض عند الحجز: ${esc(a.bookingNote)}</div>` : ''}
        ${k ? `
            <div class="alert-box info">
                <b>التشخيص:</b> ${esc(k.diagnosis)}<br>
                <b>مدة الاستشارة:</b> ${k.actual || k.duration} دقيقة<br>
                ${k.notes ? `<b>ملاحظات:</b> ${esc(k.notes)}` : ''}
            </div>
            ${k.rx && k.rx.length ? `<ul class="rx-list">${k.rx.map(r => `<li>💊 <b>${esc(r.drug)}</b> ${esc(r.dose)} · ${esc(r.freq)} · ${esc(r.days)} يوم</li>`).join('')}</ul>` : ''}
        ` : ''}
        <div class="confirm-actions">
            <button class="btn light" data-close-modal>إغلاق</button>
            <button class="btn primary" data-act="patient" data-id="${p.id}">الملف الطبي ←</button>
        </div>`, 'wide');
}


/* =================== 11. جدول المواعيد =================== */
function fillClinicSelect(sel, value, allLabel = 'جميع العيادات') {
    sel.innerHTML = `<option value="">${allLabel}</option>` + CLINICS.map(c => `<option value="${c.id}">${c.name}</option>`).join('');
    sel.value = value;
}

function bindAppointments() {
    const f = state.apptFilter;
    let t;
    $('#apptSearch').addEventListener('input', e => { clearTimeout(t); t = setTimeout(() => { f.q = e.target.value.trim(); renderAppointments(); }, 200); });
    $('#apptDate').addEventListener('change', e => { if (e.target.value) { f.date = e.target.value; renderAppointments(); } });
    $('#apptClinic').addEventListener('change', e => { f.clinic = e.target.value; renderAppointments(); });
    $('#apptStatus').addEventListener('change', e => { f.status = e.target.value; renderAppointments(); });
    $('#datePrev').addEventListener('click', () => { f.date = toISO(addDays(parseISO(f.date), -1)); renderAppointments(); });
    $('#dateNext').addEventListener('click', () => { f.date = toISO(addDays(parseISO(f.date), 1)); renderAppointments(); });
    $('#dateToday').addEventListener('click', () => { f.date = todayISO(); renderAppointments(); });
    $('#apptChips').addEventListener('click', e => {
        const c = e.target.closest('[data-status]');
        if (!c) return;
        f.status = c.dataset.status;
        renderAppointments();
    });
}

function rowActions(a) {
    const isToday = a.date === todayISO(), past = a.date < todayISO();
    const b = (cls, act, label) => `<button class="btn ${cls} xs" data-act="${act}" data-id="${a.id}">${label}</button>`;
    const det = b('light', 'details', 'التفاصيل');
    if (past && !['completed', 'noshow', 'cancelled'].includes(a.status)) return det;
    switch (a.status) {
        case 'confirmed':
            return isToday
                ? b('teal', 'checkin', '✓ تسجيل حضور') + b('warn', 'noshow', 'لم يحضر') + b('danger-light', 'cancel', 'إلغاء')
                : det + b('danger-light', 'cancel', 'إلغاء');
        case 'waiting':
            return b('primary', 'start', '▶ بدء الاستشارة') + b('warn', 'noshow', 'لم يحضر') + b('danger-light', 'cancel', 'إلغاء');
        case 'in':
            return b('success', 'open-consult', '✓ إكمال الاستشارة');
        default:
            return det + (past ? '<span class="lock-note">🔒</span>' : '');
    }
}

function renderAppointments() {
    const f = state.apptFilter;
    $('#apptDate').value = f.date;
    fillClinicSelect($('#apptClinic'), f.clinic);
    $('#apptStatus').value = f.status;

    const base = appts().filter(a => a.date === f.date && (!f.clinic || a.clinicId === f.clinic));
    const chips = [['', 'الكل', base.length], ...Object.entries(STATUS).map(([k, s]) => [k, s.label, base.filter(a => a.status === k).length])];
    $('#apptChips').innerHTML = `<span class="muted small" style="align-self:center">📅 ${fmtDate(f.date)}</span>` +
        chips.filter(([k, , n]) => !k || n).map(([k, l, n]) => `<button class="chip ${f.status === k ? 'active' : ''}" data-status="${k}">${l} <b>${n}</b></button>`).join('');

    const q = normalize(f.q);
    const list = base
        .filter(a => !f.status || a.status === f.status)
        .filter(a => !q || normalize(`${patientOf(a).name} ${a.id} ${a.queueNo} ${patientOf(a).phone}`).includes(q))
        .sort(byTime);

    const body = $('#appointmentsList');
    if (!list.length) {
        body.innerHTML = `<tr class="table-empty"><td colspan="7"><div class="empty-state"><div class="empty-icon">🗓️</div><h3>لا توجد مواعيد مطابقة</h3><p>غيّر التاريخ أو الفلاتر.</p></div></td></tr>`;
        return;
    }
    body.innerHTML = list.map((a, i) => {
        const p = patientOf(a), st = STATUS[a.status], ps = PAY_STATUS[a.paymentStatus];
        return `
        <tr style="--i:${i}" class="${a.status === 'in' ? 'row-in' : ''}" data-row="${a.id}">
            <td><span class="q-no">${a.queueNo}</span></td>
            <td>
                <div class="pt-cell">
                    <span class="pt-avatar">${ptIcon(p)}</span>
                    <div>
                        <button class="link-btn" data-act="patient" data-id="${p.id}">${esc(p.name)}</button>
                        <small>${ageOf(p.birth)} سنة · ${esc(a.reason)}</small>
                    </div>
                </div>
            </td>
            <td><b>${fmtTime(a.time)}</b>${a.arrivedAt && a.status === 'waiting' ? `<br><small class="muted">وصل ${hmOf(a.arrivedAt)}</small>` : ''}</td>
            <td>${clinicOf(a).name}</td>
            <td><span class="badge ${ps.cls}">${ps.label}</span><br><small class="muted">${METHODS[a.payment].label} · ${fmtMoney(a.fee)}</small></td>
            <td><span class="badge ${st.cls}">${st.label}</span></td>
            <td><div class="actions">${rowActions(a)}</div></td>
        </tr>`;
    }).join('');
}


/* =================== 12. إدارة الطابور =================== */
function currentRemainingMin(cur) {
    if (!cur) return 0;
    const c = cur.consult;
    if (!c || !c.startedAt) return state.data.settings.avg;
    return Math.max(1, Math.ceil(c.duration - (Date.now() - c.startedAt) / 60000));
}

function bindQueue() {
    $('#queueClinic').addEventListener('change', e => { state.queueClinic = e.target.value; renderQueue(); });
    const setAvg = d => {
        const s = state.data.settings;
        s.avg = Math.min(60, Math.max(5, s.avg + d));
        saveData();
        renderQueue();
        toast(`متوسط مدة الكشف: ${s.avg} دقيقة`, 'info');
    };
    $('#avgMinus').addEventListener('click', () => setAvg(-5));
    $('#avgPlus').addEventListener('click', () => setAvg(5));
    $('#callNextBtn').addEventListener('click', callNext);

    // السحب والإفلات لإعادة الترتيب
    const list = $('#queueList');
    let dragId = null;
    list.addEventListener('dragstart', e => {
        const card = e.target.closest('.queue-card');
        if (!card) return;
        dragId = card.dataset.id;
        card.classList.add('dragging');
        e.dataTransfer.effectAllowed = 'move';
        try { e.dataTransfer.setData('text/plain', dragId); } catch (err) { /* تجاهل */ }
    });
    list.addEventListener('dragover', e => {
        const card = e.target.closest('.queue-card');
        if (!card || card.dataset.id === dragId) return;
        e.preventDefault();
        $$('.drag-over', list).forEach(c => c !== card && c.classList.remove('drag-over'));
        card.classList.add('drag-over');
    });
    list.addEventListener('dragleave', e => {
        const card = e.target.closest('.queue-card');
        if (card && !card.contains(e.relatedTarget)) card.classList.remove('drag-over');
    });
    list.addEventListener('drop', e => {
        e.preventDefault();
        const card = e.target.closest('.queue-card');
        if (card && dragId) moveInQueue(dragId, card.dataset.id);
    });
    list.addEventListener('dragend', () => {
        dragId = null;
        $$('.dragging, .drag-over', list).forEach(c => c.classList.remove('dragging', 'drag-over'));
    });
}

function moveInQueue(id, targetId) {
    const list = waitingList(state.queueClinic);
    const from = list.findIndex(a => a.id === id);
    const to = list.findIndex(a => a.id === targetId);
    if (from < 0 || to < 0 || from === to) return;
    const [m] = list.splice(from, 1);
    list.splice(to, 0, m);
    list.forEach((a, i) => { a.order = i + 1; });
    saveData();
    renderQueue();
    toast('تم تحديث ترتيب الطابور', 'info');
}

function shiftInQueue(id, dir) {
    const list = waitingList(state.queueClinic);
    const i = list.findIndex(a => a.id === id);
    const j = i + dir;
    if (i < 0 || j < 0 || j >= list.length) return;
    moveInQueue(id, list[j].id);
}

function renderQueue() {
    fillClinicSelect($('#queueClinic'), state.queueClinic, 'كل عيادات اليوم');
    $('#avgValue').textContent = state.data.settings.avg;

    const cur = activeConsult();
    const curShown = cur && (!state.queueClinic || cur.clinicId === state.queueClinic) ? cur : null;
    const waiting = waitingList(state.queueClinic);
    const notArrived = todayAppts(state.queueClinic).filter(a => a.status === 'confirmed').sort(byTime);
    const avg = state.data.settings.avg;
    const rem = currentRemainingMin(curShown);

    // المريض الحالي
    const box = $('#queueCurrent');
    if (curShown) {
        const p = patientOf(curShown);
        box.innerHTML = `
            <span class="qc-label"><span class="live-dot"></span> المريض الحالي</span>
            <div class="qc-number bump">${curShown.queueNo}</div>
            <div class="qc-name">${esc(p.name)}</div>
            <div class="qc-meta">${ageOf(p.birth)} سنة · ${p.gender === 'f' ? 'أنثى' : 'ذكر'} · ${esc(curShown.reason)}</div>
            <div class="qc-timer"><small>المدة المنقضية</small><b id="qcTimer">—</b></div>
            <div class="qc-actions">
                <button class="btn light sm" data-go="consultation">🩺 فتح الاستشارة</button>
            </div>
            ${waiting[0] ? `<div class="qc-next">التالي: <b>${waiting[0].queueNo}</b> · ${esc(patientOf(waiting[0]).name)}</div>` : ''}`;
    } else {
        box.innerHTML = `
            <span class="qc-label">المريض الحالي</span>
            <div class="qc-empty">
                <div class="empty-icon">🪑</div>
                <div class="qc-name">لا يوجد مريض داخل الاستشارة</div>
                <div class="qc-meta">${waiting.length ? `${waiting.length} في الانتظار` : 'الطابور فارغ حالياً'}</div>
            </div>
            ${waiting[0] ? `
                <div class="qc-actions"><button class="btn light" data-act="start" data-id="${waiting[0].id}">📣 استدعاء ${waiting[0].queueNo}</button></div>
                <div class="qc-next">التالي: <b>${waiting[0].queueNo}</b> · ${esc(patientOf(waiting[0]).name)}</div>` : ''}`;
    }

    // المنتظرون
    $('#waitingCount').textContent = waiting.length;
    $('#queueList').innerHTML = waiting.length ? waiting.map((a, i) => {
        const p = patientOf(a);
        const expected = (curShown ? rem : 0) + i * avg;
        const waited = Math.max(0, Math.round((Date.now() - a.arrivedAt) / 60000));
        return `
        <div class="queue-card ${i === 0 ? 'first' : ''}" draggable="true" data-id="${a.id}" style="--i:${i}">
            <span class="drag-handle" title="اسحب لإعادة الترتيب">⋮⋮</span>
            <span class="qcard-pos">${i + 1}</span>
            <span class="pt-avatar">${ptIcon(p)}</span>
            <div class="qcard-info">
                <strong><span class="q-no">${a.queueNo}</span> ${esc(p.name)}</strong>
                <small>${ageOf(p.birth)} سنة · وصل ${hmOf(a.arrivedAt)} · ينتظر ${waited} د</small>
            </div>
            <div class="qcard-wait">الانتظار المتوقع<b>${expected === 0 ? 'الآن' : '~' + expected + ' د'}</b></div>
            <div class="qcard-actions">
                <button class="icon-btn" data-act="up" data-id="${a.id}" title="تقديم" ${i === 0 ? 'disabled' : ''}>↑</button>
                <button class="icon-btn" data-act="down" data-id="${a.id}" title="تأخير" ${i === waiting.length - 1 ? 'disabled' : ''}>↓</button>
                <button class="icon-btn go" data-act="start" data-id="${a.id}" title="بدء الاستشارة">▶</button>
                <button class="icon-btn danger" data-act="noshow" data-id="${a.id}" title="لم يحضر">✕</button>
            </div>
        </div>`;
    }).join('') : '<div class="empty-state"><div class="empty-icon">☕</div><h3>لا يوجد مرضى في الانتظار</h3><p>سجّل حضور المرضى عند وصولهم.</p></div>';

    // لم يصلوا بعد
    $('#notArrivedCount').textContent = notArrived.length;
    $('#notArrivedList').innerHTML = notArrived.length ? notArrived.map((a, i) => {
        const p = patientOf(a);
        return `
        <div class="arrive-card" style="--i:${i}">
            <span class="pt-avatar">${ptIcon(p)}</span>
            <div class="qcard-info">
                <strong><span class="q-no">${a.queueNo}</span> ${esc(p.name)}</strong>
                <small>موعده ${fmtTime(a.time)}</small>
            </div>
            <button class="btn teal xs" data-act="checkin" data-id="${a.id}">✓ وصل</button>
        </div>`;
    }).join('') : '<p class="muted">جميع المرضى وصلوا أو تمت معالجة مواعيدهم.</p>';

    $('#callNextBtn').disabled = !waiting.length && !cur;
    updateLiveTimers();
}


/* =================== 13. واجهة الاستشارة =================== */
const RING = 502.65;

function rxRowHTML(r = {}) {
    return `
    <div class="rx-row">
        <input class="field" data-f="drug" list="drugList" placeholder="اسم الدواء" value="${esc(r.drug || '')}">
        <input class="field" data-f="dose" placeholder="الجرعة (5 mg)" value="${esc(r.dose || '')}">
        <select class="field" data-f="freq">${FREQS.map(x => `<option ${x === r.freq ? 'selected' : ''}>${x}</option>`).join('')}</select>
        <input class="field" data-f="days" type="number" min="1" max="365" placeholder="الأيام" value="${esc(r.days || '')}">
        <button type="button" class="icon-btn" data-rx-del title="حذف">✕</button>
    </div>`;
}

function renderConsultation() {
    const box = $('#consultContent');
    const a = activeConsult();

    if (!a) {
        const w = waitingList().slice(0, 5);
        box.innerHTML = `
            <div class="empty-state">
                <div class="empty-icon">🩺</div>
                <h3>لا توجد استشارة جارية</h3>
                <p>اختر مريضاً من قائمة الانتظار لبدء الاستشارة.</p>
                ${w.length
                    ? `<button class="btn primary" data-act="call-next">📣 استدعاء التالي: ${w[0].queueNo} · ${esc(patientOf(w[0]).name)}</button>`
                    : '<button class="btn light" data-go="queue">إدارة الطابور</button>'}
            </div>
            ${w.length ? `
            <div class="panel mt">
                <div class="panel-head"><h3>المرضى المنتظرون</h3></div>
                <div class="waiting-pick">
                    ${w.map((x, i) => {
                        const p = patientOf(x);
                        return `
                        <div class="up-item card-anim" style="--i:${i}">
                            <span class="q-no">${x.queueNo}</span>
                            <span class="pt-avatar">${ptIcon(p)}</span>
                            <div class="up-info"><strong>${esc(p.name)}</strong><small>${ageOf(p.birth)} سنة · ${esc(x.reason)}</small></div>
                            <button class="btn primary xs" data-act="start" data-id="${x.id}">بدء ▶</button>
                        </div>`;
                    }).join('')}
                </div>
            </div>` : ''}`;
        return;
    }

    const p = patientOf(a);
    const c = a.consult;
    const d = a.draft || { diagnosis: '', rx: [{}], notes: '', followUp: '' };
    const history = appts().filter(x => x.patientId === p.id && x.status === 'completed' && x.consult).sort((x, y) => byTime(y, x));

    box.innerHTML = `
    <div class="consult-layout">
        <aside class="patient-card">
            <div class="pc-cover"></div>
            <div class="pc-avatar">${ptIcon(p)}</div>
            <h3>${esc(p.name)}</h3>
            <p class="center muted small">${p.id} · <span class="q-no">${a.queueNo}</span></p>

            <div class="pc-grid">
                <div><span>العمر</span><b>${ageOf(p.birth)} سنة</b></div>
                <div><span>الجنس</span><b>${p.gender === 'f' ? 'أنثى' : 'ذكر'}</b></div>
                <div><span>فصيلة الدم</span><b>${p.blood}</b></div>
                <div><span>الزيارات السابقة</span><b>${history.length}</b></div>
                <div><span>سبب الزيارة</span><b>${esc(a.reason)}</b></div>
                <div><span>الهاتف</span><b dir="ltr">${p.phone}</b></div>
            </div>

            ${p.allergies.length ? `<div class="alert-box danger">⚠️ <b>حساسية:</b> ${p.allergies.map(esc).join('، ')}</div>` : ''}
            ${p.chronic.length ? `<div class="alert-box info">🩺 <b>أمراض مزمنة:</b> ${p.chronic.map(esc).join('، ')}</div>` : ''}
            ${a.bookingNote ? `<div class="alert-box note">📝 ${esc(a.bookingNote)}</div>` : ''}

            <strong class="small">آخر الزيارات</strong>
            <div class="mini-history">
                ${history.length ? history.slice(0, 3).map(h => `<div><small>${relDay(h.date)}</small>${esc(h.consult.diagnosis)}</div>`).join('') : '<div>أول زيارة للمريض</div>'}
            </div>
            <button class="btn light sm block mt" data-act="patient" data-id="${p.id}">📂 عرض الملف الطبي الكامل</button>
        </aside>

        <div class="consult-main">
            <div class="panel" id="timerPanel">
                <div class="panel-head">
                    <h3>⏱ مدة الاستشارة</h3>
                    <span class="badge purple live">داخل الاستشارة</span>
                </div>
                <div class="timer-panel">
                    <div class="timer-ring" id="timerRing">
                        <svg viewBox="0 0 180 180">
                            <circle class="tr-bg" cx="90" cy="90" r="80"></circle>
                            <circle class="tr-fg" id="trFg" cx="90" cy="90" r="80"></circle>
                        </svg>
                        <div class="tr-center"><b id="trTime">00:00</b><small id="trLabel">لم تبدأ بعد</small></div>
                    </div>
                    <div>
                        <div class="form-group" style="margin:0">
                            <label for="durInput">المدة المحددة (من 1 إلى 300 دقيقة) <span class="req">*</span></label>
                            <div class="duration-row">
                                <button type="button" class="icon-btn" id="durMinus">−</button>
                                <input type="number" id="durInput" class="field" min="1" max="300" value="${c.duration}">
                                <button type="button" class="icon-btn" id="durPlus">+</button>
                                <span class="muted">دقيقة</span>
                            </div>
                            <small class="error-text"></small>
                        </div>
                        <input type="range" class="range" id="durRange" min="1" max="300" value="${c.duration}">
                        <div class="presets" id="durPresets">
                            ${[10, 15, 20, 30, 45, 60, 90].map(m => `<button type="button" data-min="${m}" class="${m === c.duration ? 'active' : ''}">${m} د</button>`).join('')}
                        </div>
                        <div class="timer-state" id="timerState"></div>
                    </div>
                </div>
            </div>

            <div class="panel">
                <div class="panel-head"><h3>🩺 التشخيص <span class="req">*</span></h3></div>
                <div class="form-group">
                    <input class="field" id="diagInput" placeholder="اكتب التشخيص..." value="${esc(d.diagnosis)}">
                    <small class="error-text"></small>
                </div>
                <div class="presets" id="diagChips">
                    ${DIAGNOSES.map(x => `<button type="button" data-diag="${esc(x)}">${esc(x)}</button>`).join('')}
                </div>
            </div>

            <div class="panel">
                <div class="panel-head">
                    <h3>💊 الوصفة الطبية</h3>
                    <button type="button" class="btn light sm" id="addRx">+ إضافة دواء</button>
                </div>
                ${p.allergies.length ? `<div class="alert-box danger">⚠️ انتبه: المريض لديه حساسية من ${p.allergies.map(esc).join('، ')}</div>` : ''}
                <div class="rx-table" id="rxTable">
                    <div class="rx-row rx-head"><span>اسم الدواء</span><span>الجرعة</span><span>عدد المرات</span><span>المدة (يوم)</span><span></span></div>
                    ${(d.rx.length ? d.rx : [{}]).map(rxRowHTML).join('')}
                </div>
                <datalist id="drugList">${DRUGS.map(x => `<option value="${x.drug}">`).join('')}</datalist>
                <div class="form-group" style="margin:8px 0 0"><small class="error-text" id="rxError"></small></div>
            </div>

            <div class="panel">
                <div class="panel-head"><h3>📝 الملاحظات الطبية</h3></div>
                <div class="form-group">
                    <textarea class="field" id="notesInput" rows="4" placeholder="ملاحظات الفحص السريري، التوصيات، التحاليل المطلوبة...">${esc(d.notes)}</textarea>
                </div>
                <div class="form-group" style="max-width:260px; margin:0">
                    <label for="followInput">موعد المراجعة (اختياري)</label>
                    <input type="date" class="field" id="followInput" min="${toISO(addDays(new Date(), 1))}" value="${esc(d.followUp)}">
                    <small class="error-text"></small>
                </div>
            </div>

            <div class="panel consult-actions">
                <span class="saved-note" id="savedNote">💾 يتم حفظ المسودة تلقائياً</span>
                <div class="hero-buttons">
                    <button type="button" class="btn light" id="backToQueue">↩ إرجاع للطابور</button>
                    <button type="button" class="btn success" id="finishConsult">✓ إنهاء الاستشارة</button>
                </div>
            </div>
        </div>
    </div>`;

    renderTimerState();
    updateLiveTimers();
}

function renderTimerState() {
    const a = activeConsult();
    const el = $('#timerState');
    if (!a || !el) return;
    el.innerHTML = a.consult.startedAt
        ? `<span class="badge success">بدأت الساعة ${hmOf(a.consult.startedAt)}</span>
           <button type="button" class="btn light sm" id="extend5">+5 دقائق</button>`
        : `<button type="button" class="btn primary" id="startTimer">▶ بدء الاستشارة</button>
           <span class="muted small">يبدأ المؤقت عند الضغط</span>`;
}

function setDuration(raw, from) {
    const a = activeConsult();
    if (!a) return false;
    const input = $('#durInput');
    const v = Number(raw);
    if (!Number.isInteger(v) || v < 1 || v > 300) {
        setError(input, 'المدة يجب أن تكون رقماً صحيحاً من 1 إلى 300 دقيقة');
        return false;
    }
    setError(input, '');
    a.consult.duration = v;
    if (from !== 'input') input.value = v;
    $('#durRange').value = v;
    $$('#durPresets button').forEach(b => b.classList.toggle('active', Number(b.dataset.min) === v));
    delete state.overtimeWarned[a.id];
    saveData();
    updateLiveTimers();
    return true;
}

function readDraft() {
    const rows = $$('#rxTable .rx-row:not(.rx-head)').map(r => ({
        drug: $('[data-f=drug]', r).value.trim(),
        dose: $('[data-f=dose]', r).value.trim(),
        freq: $('[data-f=freq]', r).value,
        days: $('[data-f=days]', r).value.trim()
    }));
    return {
        diagnosis: $('#diagInput').value.trim(),
        rx: rows,
        notes: $('#notesInput').value.trim(),
        followUp: $('#followInput').value
    };
}

function scheduleDraftSave() {
    const note = $('#savedNote');
    note.textContent = '⏳ جارٍ حفظ المسودة...';
    note.classList.remove('saved');
    clearTimeout(state.draftTimer);
    state.draftTimer = setTimeout(() => {
        const a = activeConsult();
        if (!a || !$('#diagInput')) return;
        a.draft = readDraft();
        saveData();
        note.textContent = '✓ تم حفظ المسودة';
        note.classList.add('saved');
    }, 600);
}

function bindConsultation() {
    const box = $('#consultContent');

    box.addEventListener('input', e => {
        if (e.target.id === 'durInput') { setDuration(e.target.value, 'input'); return; }
        if (e.target.id === 'durRange') { setDuration(e.target.value); return; }
        if (e.target.closest('.form-group.has-error') && e.target.id !== 'durInput') setError(e.target, '');
        if (e.target.closest('#rxTable')) $('#rxError').textContent = '';
        if (e.target.matches('#diagInput, #notesInput, #followInput, #rxTable .field')) scheduleDraftSave();
    });
    box.addEventListener('change', e => {
        if (e.target.matches('#followInput, #rxTable select')) scheduleDraftSave();
    });

    box.addEventListener('click', async e => {
        const a = activeConsult();
        if (!a) return;
        const id = e.target.id;

        if (id === 'durMinus') setDuration(Math.max(1, a.consult.duration - 1));
        if (id === 'durPlus') setDuration(Math.min(300, a.consult.duration + 1));

        const preset = e.target.closest('[data-min]');
        if (preset) setDuration(preset.dataset.min);

        if (id === 'startTimer') {
            if (!setDuration($('#durInput').value, 'input')) { shake($('#timerPanel')); toast('حدد مدة صحيحة أولاً', 'error'); return; }
            a.consult.startedAt = Date.now();
            saveData();
            renderTimerState();
            updateLiveTimers();
            updateBadges();
            toast(`▶ بدأت الاستشارة · ${a.consult.duration} دقيقة`, 'success');
        }

        if (id === 'extend5') {
            if (a.consult.duration + 5 > 300) { toast('الحد الأقصى للمدة 300 دقيقة', 'error'); return; }
            setDuration(a.consult.duration + 5);
            toast('تم تمديد الاستشارة 5 دقائق', 'info');
        }

        const diag = e.target.closest('[data-diag]');
        if (diag) {
            const input = $('#diagInput');
            input.value = diag.dataset.diag;
            setError(input, '');
            input.focus();
            scheduleDraftSave();
        }

        if (id === 'addRx') {
            $('#rxTable').insertAdjacentHTML('beforeend', rxRowHTML());
            const rows = $$('#rxTable .rx-row:not(.rx-head)');
            $('[data-f=drug]', rows[rows.length - 1]).focus();
            scheduleDraftSave();
        }

        const del = e.target.closest('[data-rx-del]');
        if (del) {
            const row = del.closest('.rx-row');
            row.classList.add('removing');
            setTimeout(() => { row.remove(); scheduleDraftSave(); }, 280);
        }

        if (id === 'backToQueue') {
            const ok = await confirmDialog({
                title: 'إرجاع المريض للطابور؟',
                text: 'سيعود المريض إلى أول الطابور مع الاحتفاظ بالمسودة.',
                ok: 'إرجاع', icon: '↩'
            });
            if (!ok) return;
            a.draft = readDraft();
            a.status = 'waiting';
            a.order = Math.min(1, ...waitingList().map(x => x.order)) - 1;
            a.consult.startedAt = null;
            saveData();
            toast('تم إرجاع المريض إلى أول الطابور', 'info');
            go('queue');
        }

        if (id === 'finishConsult') finishConsult(a);
    });
}

function finishConsult(a) {
    const d = readDraft();
    let firstErr = null;

    if (!a.consult.startedAt) {
        toast('ابدأ الاستشارة أولاً بالضغط على «بدء الاستشارة»', 'error');
        shake($('#timerPanel'));
        $('#timerPanel').scrollIntoView({ behavior: 'smooth', block: 'center' });
        return;
    }
    if (!d.diagnosis) {
        setError($('#diagInput'), 'التشخيص مطلوب لإنهاء الاستشارة');
        firstErr = firstErr || $('#diagInput');
    }
    const badRow = d.rx.find(r => !r.drug && (r.dose || r.days));
    const badDays = d.rx.find(r => r.drug && r.days && (Number(r.days) < 1 || Number(r.days) > 365));
    if (badRow) { $('#rxError').textContent = 'أدخل اسم الدواء لكل سطر في الوصفة أو احذف السطر الفارغ'; firstErr = firstErr || $('#rxTable'); }
    else if (badDays) { $('#rxError').textContent = 'مدة الدواء يجب أن تكون بين 1 و 365 يوماً'; firstErr = firstErr || $('#rxTable'); }

    if (firstErr) {
        toast('يرجى تصحيح الحقول المطلوبة', 'error');
        shake(firstErr.closest('.panel'));
        firstErr.scrollIntoView({ behavior: 'smooth', block: 'center' });
        return;
    }

    const rx = d.rx.filter(r => r.drug);
    const actual = Math.max(1, Math.round((Date.now() - a.consult.startedAt) / 60000));
    const p = patientOf(a);

    openModal(`
        <div class="confirm">
            <div class="confirm-icon success">✓</div>
            <h3>إنهاء استشارة ${esc(p.name)}؟</h3>
            <p class="muted">راجع الملخص قبل الحفظ النهائي.</p>
        </div>
        <div class="detail-grid mt">
            <div><span>المدة الفعلية</span><b>${actual} دقيقة</b></div>
            <div><span>المدة المحددة</span><b>${a.consult.duration} دقيقة</b></div>
            <div><span>التشخيص</span><b>${esc(d.diagnosis)}</b></div>
            <div><span>الأدوية</span><b>${rx.length ? rx.length + ' دواء' : 'بدون وصفة'}</b></div>
            ${d.followUp ? `<div><span>موعد المراجعة</span><b>${fmtDate(d.followUp)}</b></div>` : ''}
        </div>
        ${a.paymentStatus === 'unpaid' ? `
            <label class="check-wrap alert-box note">
                <input type="checkbox" id="paidCheck" checked><span class="check-box"></span>
                تم استلام أجور المعاينة نقداً (${fmtMoney(a.fee)})
            </label>` : `<div class="alert-box info">💳 أجور المعاينة: ${PAY_STATUS[a.paymentStatus].label}</div>`}
        <div class="confirm-actions">
            <button class="btn light" data-close-modal>رجوع</button>
            <button class="btn success" id="confirmFinish" data-id="${a.id}">✓ تأكيد الإنهاء</button>
        </div>`);
}

function confirmFinish(btn) {
    const a = findAppt(btn.dataset.id);
    const d = readDraft();
    const paid = $('#paidCheck');
    setLoading(btn, true);
    setTimeout(() => {
        a.status = 'completed';
        a.consult = {
            duration: a.consult.duration,
            startedAt: a.consult.startedAt,
            endedAt: Date.now(),
            actual: Math.max(1, Math.round((Date.now() - a.consult.startedAt) / 60000)),
            diagnosis: d.diagnosis,
            rx: d.rx.filter(r => r.drug),
            notes: d.notes,
            followUp: d.followUp
        };
        delete a.draft;
        if (paid && paid.checked) a.paymentStatus = 'paid';
        saveData();

        const p = patientOf(a);
        notify('✅', `اكتملت استشارة ${p.name} (${a.queueNo})`);
        const next = waitingList()[0];
        modalResolver = null;
        openModal(`
            <div class="confirm">
                <div class="confirm-icon success">🎉</div>
                <h3>تم إنهاء الاستشارة بنجاح</h3>
                <p class="muted">تم حفظ التشخيص والوصفة في ملف ${esc(p.name)}.</p>
                <div class="confirm-actions">
                    <button class="btn light" data-go="dashboard">لوحة التحكم</button>
                    ${next
                        ? `<button class="btn primary" data-act="start" data-id="${next.id}">التالي: ${next.queueNo} ▶</button>`
                        : '<button class="btn primary" data-go="queue">الطابور</button>'}
                </div>
            </div>`);
        renderConsultation();
        updateBadges();
    }, 700);
}


/* =================== مؤقتات مباشرة =================== */
function updateLiveTimers() {
    const a = activeConsult();
    const elapsedSec = a && a.consult && a.consult.startedAt ? (Date.now() - a.consult.startedAt) / 1000 : 0;
    const started = !!(a && a.consult && a.consult.startedAt);

    const wc = $('#wcTimer');
    if (wc) wc.textContent = started ? fmtClock(elapsedSec) : 'لم يبدأ المؤقت';
    const qc = $('#qcTimer');
    if (qc) qc.textContent = started ? fmtClock(elapsedSec) : 'لم يبدأ المؤقت';

    const ring = $('#timerRing');
    if (!ring || !a) return;
    const total = a.consult.duration * 60;
    const remaining = total - elapsedSec;
    const fg = $('#trFg');
    ring.classList.remove('warn', 'over');

    if (!started) {
        $('#trTime').textContent = fmtClock(total);
        $('#trLabel').textContent = 'لم تبدأ بعد';
        fg.style.strokeDashoffset = RING;
        return;
    }
    if (remaining >= 0) {
        $('#trTime').textContent = fmtClock(remaining);
        $('#trLabel').textContent = 'الوقت المتبقي';
        fg.style.strokeDashoffset = RING * (1 - elapsedSec / total);
        if (remaining < 120) ring.classList.add('warn');
    } else {
        $('#trTime').textContent = '+' + fmtClock(-remaining);
        $('#trLabel').textContent = 'تجاوز المدة المحددة';
        fg.style.strokeDashoffset = 0;
        ring.classList.add('over');
        if (!state.overtimeWarned[a.id]) {
            state.overtimeWarned[a.id] = true;
            toast('⏰ تجاوزت الاستشارة المدة المحددة', 'warning');
        }
    }
}


/* =================== المرضى والملف الطبي =================== */
function patientSummary() {
    const map = {};
    appts().filter(a => a.status === 'completed').forEach(a => {
        const s = map[a.patientId] || (map[a.patientId] = { p: patientOf(a), visits: 0, last: null });
        s.visits++;
        if (!s.last || byTime(a, s.last) > 0) s.last = a;
    });
    return Object.values(map);
}

function bindPatients() {
    let t;
    $('#patientSearch').addEventListener('input', e => { clearTimeout(t); t = setTimeout(() => { state.patientQ = e.target.value.trim(); renderPatients(); }, 200); });
    $('#patientSort').addEventListener('change', e => { state.patientSort = e.target.value; renderPatients(); });
}

function renderPatients() {
    const q = normalize(state.patientQ);
    let list = patientSummary().filter(s => !q || normalize(`${s.p.name} ${s.p.phone} ${s.p.id}`).includes(q));
    if (state.patientSort === 'recent') list.sort((a, b) => byTime(b.last, a.last));
    if (state.patientSort === 'visits') list.sort((a, b) => b.visits - a.visits);
    if (state.patientSort === 'name') list.sort((a, b) => a.p.name.localeCompare(b.p.name, 'ar'));

    $('#patientsCount').textContent = list.length;
    $('#patientGrid').innerHTML = list.length ? list.map((s, i) => `
        <button class="patient-tile" data-act="patient" data-id="${s.p.id}" style="--i:${i}">
            <div class="pt-head">
                <span class="pt-avatar">${ptIcon(s.p)}</span>
                <div><strong>${esc(s.p.name)}</strong><small>${s.p.id} · ${ageOf(s.p.birth)} سنة · <span dir="ltr">${s.p.phone}</span></small></div>
            </div>
            <div class="pt-stats">
                <div>آخر زيارة<b>${relDay(s.last.date)}</b></div>
                <div>عدد الزيارات<b>${s.visits}</b></div>
            </div>
            <small class="muted">آخر تشخيص: ${esc(s.last.consult.diagnosis)}</small>
            <div class="pt-tags">
                ${s.p.allergies.map(x => `<span class="tag danger">حساسية: ${esc(x)}</span>`).join('')}
                ${s.p.chronic.map(x => `<span class="tag info">${esc(x)}</span>`).join('')}
                <span class="tag">فصيلة ${s.p.blood}</span>
            </div>
        </button>`).join('')
        : '<div class="empty-state" style="grid-column:1/-1"><div class="empty-icon">🔍</div><h3>لا يوجد مريض مطابق</h3><p>جرّب البحث بالاسم أو رقم الهاتف أو رقم المريض.</p></div>';
}

function openPatientFile(pid, tab = 'consults') {
    const p = PATIENTS.find(x => x.id === pid);
    if (!p) return;
    const visits = appts().filter(a => a.patientId === pid && a.status === 'completed' && a.consult).sort((a, b) => byTime(b, a));
    const all = appts().filter(a => a.patientId === pid);
    const upcoming = all.filter(a => ['confirmed', 'waiting'].includes(a.status) && a.date >= todayISO()).sort(byTime)[0];

    const consults = visits.length ? visits.map((v, i) => `
        <div class="tl-item" style="--i:${i}">
            <header><b>${fmtDate(v.date, { day: 'numeric', month: 'long', year: 'numeric' })}</b><span>${clinicOf(v).name} · ${v.consult.actual || v.consult.duration} د</span></header>
            <p><b>التشخيص:</b> ${esc(v.consult.diagnosis)}</p>
            ${v.consult.notes ? `<p class="muted">${esc(v.consult.notes)}</p>` : ''}
        </div>`).join('') : '<p class="muted">لا توجد استشارات سابقة.</p>';

    const rxs = visits.filter(v => v.consult.rx && v.consult.rx.length);
    const prescriptions = rxs.length ? rxs.map((v, i) => `
        <div class="tl-item" style="--i:${i}">
            <header><b>${fmtDate(v.date, { day: 'numeric', month: 'long', year: 'numeric' })}</b><span>${esc(v.consult.diagnosis)}</span></header>
            <ul class="rx-list">${v.consult.rx.map(r => `<li>💊 <b>${esc(r.drug)}</b> ${esc(r.dose)} · ${esc(r.freq)} · ${esc(r.days)} يوم</li>`).join('')}</ul>
        </div>`).join('') : '<p class="muted">لا توجد وصفات طبية.</p>';

    openDrawer(`
        <div class="drawer-head">
            <span class="pt-avatar">${ptIcon(p)}</span>
            <div>
                <h2>${esc(p.name)}</h2>
                <span class="muted small">${p.id} · ${ageOf(p.birth)} سنة · ${p.gender === 'f' ? 'أنثى' : 'ذكر'}</span>
            </div>
        </div>
        <p class="access-note">🔒 تعرض هذه الصفحة المعلومات الطبية المسموح للطبيب بالاطلاع عليها فقط.</p>

        <div class="drawer-section">
            <h4>المعلومات الأساسية</h4>
            <div class="detail-grid">
                <div><span>رقم الهاتف</span><b dir="ltr">${p.phone}</b></div>
                <div><span>فصيلة الدم</span><b>${p.blood}</b></div>
                <div><span>تاريخ الميلاد</span><b>${fmtDate(p.birth, { day: 'numeric', month: 'long', year: 'numeric' })}</b></div>
                <div><span>الزيارات المكتملة</span><b>${visits.length}</b></div>
                <div><span>مواعيد ملغاة / لم يحضر</span><b>${all.filter(a => a.status === 'cancelled').length} / ${all.filter(a => a.status === 'noshow').length}</b></div>
                <div><span>الموعد القادم</span><b>${upcoming ? relDay(upcoming.date) + ' · ' + fmtTime(upcoming.time) : '—'}</b></div>
            </div>
            ${p.allergies.length ? `<div class="alert-box danger">⚠️ <b>حساسية:</b> ${p.allergies.map(esc).join('، ')}</div>` : '<div class="alert-box info">لا توجد حساسية مسجلة.</div>'}
            ${p.chronic.length ? `<div class="alert-box info">🩺 <b>أمراض مزمنة:</b> ${p.chronic.map(esc).join('، ')}</div>` : ''}
        </div>

        <div class="drawer-section">
            <div class="tabs" id="fileTabs">
                <button class="${tab === 'consults' ? 'active' : ''}" data-file-tab="consults" data-pid="${p.id}">سجل الاستشارات (${visits.length})</button>
                <button class="${tab === 'rx' ? 'active' : ''}" data-file-tab="rx" data-pid="${p.id}">الوصفات الطبية (${rxs.length})</button>
            </div>
            <div class="timeline">${tab === 'consults' ? consults : prescriptions}</div>
        </div>`);
}


/* =================== 16. التقارير والمدفوعات =================== */
function reportRange() {
    const t = todayISO(), r = state.report;
    switch (r.period) {
        case 'today': return [t, t];
        case '7': return [toISO(addDays(new Date(), -6)), t];
        case '30': return [toISO(addDays(new Date(), -29)), t];
        case 'month': { const n = new Date(); return [toISO(new Date(n.getFullYear(), n.getMonth(), 1)), t]; }
        default: return [r.from, r.to];
    }
}

function bindReports() {
    $('#periodSeg').addEventListener('click', e => {
        const b = e.target.closest('[data-period]');
        if (!b) return;
        state.report.period = b.dataset.period;
        state.report.limit = 15;
        if (b.dataset.period === 'custom' && !state.report.from) {
            state.report.from = toISO(addDays(new Date(), -13));
            state.report.to = todayISO();
        }
        renderReports();
    });
    const onRange = () => {
        const f = $('#rangeFrom').value, t = $('#rangeTo').value;
        if (!f || !t) return;
        if (f > t) {
            toast('تاريخ البداية يجب أن يكون قبل تاريخ النهاية', 'error');
            shake($('#customRange'));
            $('#rangeFrom').value = state.report.from;
            $('#rangeTo').value = state.report.to;
            return;
        }
        state.report.from = f;
        state.report.to = t;
        state.report.limit = 15;
        renderReports();
    };
    $('#rangeFrom').addEventListener('change', onRange);
    $('#rangeTo').addEventListener('change', onRange);
    $('#reportClinic').addEventListener('change', e => { state.report.clinic = e.target.value; renderReports(); });
    $('#exportCsv').addEventListener('click', exportCsv);
    $('#paymentsList').addEventListener('click', e => {
        if (e.target.closest('#moreRows')) { state.report.limit += 20; renderPaymentsTable(); }
    });
}

function reportList() {
    const [from, to] = reportRange();
    return appts().filter(a => a.date >= from && a.date <= to && (!state.report.clinic || a.clinicId === state.report.clinic));
}

function renderReports() {
    const r = state.report;
    $$('#periodSeg button').forEach(b => b.classList.toggle('active', b.dataset.period === r.period));
    $('#customRange').hidden = r.period !== 'custom';
    $('#rangeFrom').value = r.from;
    $('#rangeTo').value = r.to;
    $('#rangeFrom').max = $('#rangeTo').max = todayISO();
    fillClinicSelect($('#reportClinic'), r.clinic);

    const [from, to] = reportRange();
    const fmt = { day: 'numeric', month: 'long', year: 'numeric' };
    $('#periodLabel').textContent = from === to
        ? `📅 الفترة: ${fmtDate(from, fmt)}`
        : `📅 الفترة: من ${fmtDate(from, fmt)} إلى ${fmtDate(to, fmt)}`;

    const list = reportList();
    const count = s => list.filter(a => a.status === s).length;
    const completed = count('completed'), cancelled = count('cancelled'), noshow = count('noshow');
    const paid = list.filter(a => a.paymentStatus === 'paid').reduce((s, a) => s + a.fee, 0);
    const unpaid = list.filter(a => a.paymentStatus === 'unpaid').reduce((s, a) => s + a.fee, 0);
    const refunded = list.filter(a => a.paymentStatus === 'refunded').reduce((s, a) => s + a.fee, 0);
    const rate = list.length ? Math.round((completed / list.length) * 100) : 0;

    $('#reportStats').innerHTML = [
        { icon: '🩺', label: 'إجمالي الاستشارات', value: completed, sub: `${rate}% من ${list.length} موعداً`, color: '#16a34a' },
        { icon: '⊘', label: 'المواعيد الملغاة', value: cancelled, sub: `${fmtMoney(refunded)} مستردة`, color: '#e5484d' },
        { icon: '🚫', label: 'لم يحضر', value: noshow, sub: 'مواعيد بدون حضور', color: '#94a3b8' },
        { icon: '💰', label: 'المدفوعات المستلمة', value: paid, sub: `${fmtMoney(unpaid)} بانتظار الدفع`, color: '#7c3aed', money: true }
    ].map(statCard).join('');
    animateCounts($('#reportStats'));

    // الرسم حسب اليوم (أو الأسبوع للفترات الطويلة)
    const days = [];
    for (let d = parseISO(from); toISO(d) <= to; d = addDays(d, 1)) days.push(toISO(d));
    let items;
    const completedOn = iso => list.filter(a => a.date === iso && a.status === 'completed').length;
    if (days.length <= 31) {
        items = days.map(iso => {
            const v = completedOn(iso);
            return { label: fmtDate(iso, { day: 'numeric', month: 'numeric' }), value: v, tip: `${fmtDate(iso)}: ${v} استشارة` };
        });
    } else {
        items = [];
        for (let i = 0; i < days.length; i += 7) {
            const chunk = days.slice(i, i + 7);
            const v = chunk.reduce((s, iso) => s + completedOn(iso), 0);
            items.push({ label: fmtDate(chunk[0], { day: 'numeric', month: 'numeric' }), value: v, tip: `أسبوع ${fmtDate(chunk[0], { day: 'numeric', month: 'short' })}: ${v} استشارة` });
        }
    }
    renderBarChart($('#reportChart'), items);

    const pending = list.filter(a => ['confirmed', 'waiting', 'in'].includes(a.status)).length;
    renderStack($('#statusBreakdown'), [
        { label: 'مكتملة', icon: '✓', color: STATUS.completed.color, value: completed },
        { label: 'ملغاة', icon: '⊘', color: STATUS.cancelled.color, value: cancelled },
        { label: 'لم يحضر', icon: '✕', color: STATUS.noshow.color, value: noshow },
        { label: 'قيد الانتظار / محجوزة', icon: '📅', color: STATUS.confirmed.color, value: pending }
    ]);

    renderHBars($('#methodBreakdown'), Object.entries(METHODS).map(([k, m]) => {
        const v = list.filter(a => a.payment === k && a.paymentStatus === 'paid').reduce((s, a) => s + a.fee, 0);
        return { label: m.label, color: m.color, value: v, text: fmtMoney(v) };
    }));

    renderPaymentsTable();
}

function renderPaymentsTable() {
    const rows = reportList().filter(a => a.paymentStatus !== 'none').sort((a, b) => byTime(b, a));
    $('#paymentsCount').textContent = `${rows.length} عملية`;
    const shown = rows.slice(0, state.report.limit);
    $('#paymentsList').innerHTML = shown.length ? shown.map((a, i) => {
        const ps = PAY_STATUS[a.paymentStatus];
        return `
        <tr style="--i:${Math.min(i, 15)}">
            <td><b>${a.id}</b></td>
            <td>${fmtDate(a.date, { day: 'numeric', month: 'short' })} · ${fmtTime(a.time)}</td>
            <td><button class="link-btn" data-act="patient" data-id="${a.patientId}">${esc(patientOf(a).name)}</button></td>
            <td>${clinicOf(a).name}</td>
            <td><i class="sw" style="background:${METHODS[a.payment].color}"></i> ${METHODS[a.payment].label}</td>
            <td><b>${fmtMoney(a.fee)}</b></td>
            <td><span class="badge ${ps.cls}">${ps.label}</span></td>
        </tr>`;
    }).join('') + (rows.length > shown.length
        ? `<tr><td colspan="7" style="text-align:center"><button class="btn light sm" id="moreRows">عرض المزيد (${rows.length - shown.length} متبقية)</button></td></tr>`
        : '')
        : '<tr class="table-empty"><td colspan="7"><div class="empty-state"><div class="empty-icon">💳</div><h3>لا توجد مدفوعات في هذه الفترة</h3></div></td></tr>';
}

function exportCsv() {
    const [from, to] = reportRange();
    const rows = reportList().sort(byTime);
    if (!rows.length) { toast('لا توجد بيانات للتصدير', 'error'); return; }
    const header = ['رقم الحجز', 'التاريخ', 'الوقت', 'المريض', 'العيادة', 'حالة الموعد', 'طريقة الدفع', 'المبلغ', 'حالة الدفع'];
    const data = rows.map(a => [a.id, a.date, a.time, patientOf(a).name, clinicOf(a).name, STATUS[a.status].label, METHODS[a.payment].label, a.fee, PAY_STATUS[a.paymentStatus].label]);
    const csv = '﻿' + [header, ...data].map(r => r.map(v => `"${String(v).replace(/"/g, '""')}"`).join(',')).join('\n');
    const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
    const link = document.createElement('a');
    link.href = url;
    link.download = `تقرير-العيادة-${from}-${to}.csv`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    toast(`تم تصدير ${rows.length} سجلاً`, 'success');
}


/* =================== معالج النقرات العام =================== */
function handleAction(act, id) {
    const a = id ? findAppt(id) : null;
    switch (act) {
        case 'checkin': if (a) checkIn(a); break;
        case 'start': startConsult(a); break;
        case 'open-consult': go('consultation'); toast('أكمل التشخيص ثم اضغط «إنهاء الاستشارة»', 'info'); break;
        case 'call-next': callNext(); break;
        case 'noshow': if (a) markNoShow(a); break;
        case 'cancel': if (a) openCancel(a); break;
        case 'details': if (a) openDetails(a); break;
        case 'patient': openPatientFile(id); break;
        case 'up': shiftInQueue(id, -1); break;
        case 'down': shiftInQueue(id, 1); break;
    }
}

document.addEventListener('click', e => {
    const inModal = e.target.closest('#modal');

    const nav = e.target.closest('a[data-page], [data-go]');
    if (nav) {
        e.preventDefault();
        if (inModal) closeModal();
        closeDrawer();
        go(nav.dataset.page || nav.dataset.go);
        return;
    }

    const act = e.target.closest('[data-act]');
    if (act && !act.disabled) {
        if (inModal) closeModal();
        if (act.dataset.act !== 'patient') closeDrawer();
        handleAction(act.dataset.act, act.dataset.id);
    }
});

// تأثير الموجة
document.addEventListener('pointerdown', e => {
    const b = e.target.closest('.btn');
    if (!b || b.disabled) return;
    const r = b.getBoundingClientRect();
    const size = Math.max(r.width, r.height);
    const s = document.createElement('span');
    s.className = 'ripple';
    s.style.width = s.style.height = size + 'px';
    s.style.left = (e.clientX - r.left - size / 2) + 'px';
    s.style.top = (e.clientY - r.top - size / 2) + 'px';
    b.appendChild(s);
    setTimeout(() => s.remove(), 650);
});


/* =================== ربط عناصر الواجهة =================== */
function bindApp() {
    // النافذة المنبثقة
    const modal = $('#modal');
    modal.addEventListener('click', e => {
        if (e.target === modal || e.target.closest('[data-close-modal]')) { closeModal(); return; }
        const c = e.target.closest('[data-confirm]');
        if (c && modalResolver) {
            const r = modalResolver;
            modalResolver = null;
            closeModal();
            r(c.dataset.confirm === 'yes');
        }
        const fin = e.target.closest('#confirmFinish');
        if (fin) confirmFinish(fin);
    });
    $('#modalBody').addEventListener('submit', e => {
        e.preventDefault();
        if (e.target.id === 'cancelForm') submitCancel(e.target);
    });
    $('#modalBody').addEventListener('change', e => {
        if (e.target.name === 'reason') setError($('.reason-list'), '');
    });

    // اللوحة الجانبية للملف الطبي
    const drawer = $('#drawer');
    drawer.addEventListener('click', e => {
        if (e.target === drawer || e.target.closest('[data-close-drawer]')) closeDrawer();
        const tab = e.target.closest('[data-file-tab]');
        if (tab) {
            const scroll = $('.drawer-panel').scrollTop;
            openPatientFile(tab.dataset.pid, tab.dataset.fileTab);
            $('.drawer-panel').scrollTop = scroll;
        }
    });

    // القائمة الجانبية على الهاتف
    $('#menuToggle').addEventListener('click', () => document.body.classList.toggle('sidebar-open'));
    $('#sidebarOverlay').addEventListener('click', closeSidebar);

    // الإشعارات
    $('#notifBtn').addEventListener('click', e => {
        e.stopPropagation();
        const panel = $('#notifPanel');
        panel.classList.toggle('open');
        if (panel.classList.contains('open')) {
            setTimeout(() => {
                state.data.notifs.forEach(n => { n.unread = false; });
                saveData();
                $('#notifCount').hidden = true;
            }, 1200);
        } else renderNotifs();
    });
    $('#clearNotifs').addEventListener('click', () => {
        state.data.notifs = [];
        saveData();
        renderNotifs();
    });
    document.addEventListener('click', e => {
        if (!e.target.closest('.notif-wrap') && $('#notifPanel').classList.contains('open')) {
            $('#notifPanel').classList.remove('open');
            renderNotifs();
        }
    });

    $('#paySeg').addEventListener('click', e => {
        const b = e.target.closest('[data-range]');
        if (!b) return;
        state.payRange = b.dataset.range;
        $$('#paySeg button').forEach(x => x.classList.toggle('active', x === b));
        renderPaySummary();
    });
    $('#callNextHero').addEventListener('click', callNext);

    $('#logoutBtn').addEventListener('click', logout);
    $('#resetData').addEventListener('click', async () => {
        const ok = await confirmDialog({ title: 'إعادة ضبط البيانات؟', text: 'سيتم حذف جميع التغييرات وإعادة إنشاء البيانات التجريبية.', ok: 'إعادة الضبط', danger: true, icon: '↺' });
        if (!ok) return;
        state.data = generateData();
        state.overtimeWarned = {};
        saveData();
        renderNotifs();
        renderPage();
        toast('تمت إعادة ضبط البيانات التجريبية', 'success');
    });

    // ظل الشريط العلوي
    window.addEventListener('scroll', () => $('#topbar').classList.toggle('scrolled', window.scrollY > 8), { passive: true });
    window.addEventListener('resize', moveIndicator);
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(moveIndicator);

    document.addEventListener('keydown', e => {
        if (e.key !== 'Escape') return;
        if ($('#modal').classList.contains('open')) closeModal();
        else if ($('#drawer').classList.contains('open')) closeDrawer();
        else { $('#notifPanel').classList.remove('open'); closeSidebar(); }
    });

    bindAppointments();
    bindQueue();
    bindConsultation();
    bindPatients();
    bindReports();
    bindChartTips();
}


/* =================== الساعة والمحاكاة =================== */
let secCounter = 0;

function tick() {
    if ($('#doctorApp').hidden) return;
    $('#liveClock').textContent = new Intl.DateTimeFormat('ar-u-nu-latn', { hour: '2-digit', minute: '2-digit', second: '2-digit' }).format(new Date());
    updateLiveTimers();

    secCounter++;
    // تحديث أوقات الانتظار كل 30 ثانية
    if (secCounter % 30 === 0 && state.page === 'queue' && !document.querySelector('.queue-card.dragging')) renderQueue();
    // محاكاة وصول مريض جديد كل 40 ثانية
    if (secCounter % 40 === 0 && $('#simToggle').checked) {
        const next = todayAppts().filter(a => a.status === 'confirmed').sort(byTime)[0];
        if (next) checkIn(next, true);
    }
}


/* =================== التشغيل =================== */
function init() {
    loadData();
    bindLogin();
    bindApp();
    if (isLogged()) enterApp();
    else showLogin();
    setInterval(tick, 1000);
}

function hideLoader() {
    const l = $('#pageLoader');
    if (l) l.classList.add('hide');
    moveIndicator();
}
window.addEventListener('load', () => setTimeout(hideLoader, 300));
setTimeout(hideLoader, 2500);

init();

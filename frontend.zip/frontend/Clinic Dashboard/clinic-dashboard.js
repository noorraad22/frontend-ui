/* =========================================================
   العيادة الذكية — لوحة العيادة
   clinic-dashboard.js
   ملاحظة: البيانات تجريبية وتُحفظ في المتصفح فقط (localStorage)
   ========================================================= */
'use strict';

/* =================== أدوات مساعدة =================== */
const $ = (sel, ctx = document) => ctx.querySelector(sel);
const $$ = (sel, ctx = document) => Array.from(ctx.querySelectorAll(sel));

const pad = n => String(n).padStart(2, '0');
const toISO = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const addDays = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
const todayISO = () => toISO(new Date());
const parseISO = s => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); };
const fmtDate = (iso, opts = { day: 'numeric', month: 'short', year: 'numeric' }) =>
    new Intl.DateTimeFormat('ar-u-nu-latn', opts).format(parseISO(iso));
const fmtTime = t => {
    let [h, m] = t.split(':').map(Number);
    const s = h >= 12 ? 'م' : 'ص';
    h = h % 12 || 12;
    return `${h}:${pad(m)} ${s}`;
};
const fmtMoney = n => Number(n || 0).toLocaleString('en-US') + ' د.ع';
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const normalize = s => String(s).replace(/[ً-ْـ]/g, '').replace(/[أإآ]/g, 'ا').replace(/ة/g, 'ه').replace(/ى/g, 'ي').toLowerCase();
const nowHM = () => { const d = new Date(); return `${pad(d.getHours())}:${pad(d.getMinutes())}`; };
const isEmail = v => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
const relDay = iso => {
    if (iso === todayISO()) return 'اليوم';
    if (iso === toISO(addDays(new Date(), 1))) return 'غداً';
    if (iso === toISO(addDays(new Date(), -1))) return 'أمس';
    return fmtDate(iso, { weekday: 'short', day: 'numeric', month: 'short' });
};
function timeAgo(t) {
    const m = Math.floor((Date.now() - t) / 60000);
    if (m < 1) return 'الآن';
    if (m < 60) return `منذ ${m} دقيقة`;
    const h = Math.floor(m / 60);
    return h < 24 ? `منذ ${h} ساعة` : `منذ ${Math.floor(h / 24)} يوم`;
}
function shake(el) { if (!el) return; el.classList.remove('shake'); void el.offsetWidth; el.classList.add('shake'); }
function setLoading(btn, on) { if (!btn) return; btn.classList.toggle('loading', on); btn.disabled = on; }

const rawGet = (k, s = localStorage) => { try { const v = s.getItem(k); return v ? JSON.parse(v) : null; } catch (e) { return null; } };
const rawSet = (k, v, s = localStorage) => { try { s.setItem(k, JSON.stringify(v)); } catch (e) { /* تجاهل */ } };
const rawDel = k => { try { localStorage.removeItem(k); sessionStorage.removeItem(k); } catch (e) { /* تجاهل */ } };


/* =================== الثوابت =================== */
const KARRADA = { id: 'CL-01', name: 'عيادة الكرادة التخصصية', city: 'بغداد', address: 'بغداد · الكرادة داخل', reqId: '' };
let CLINIC = { ...KARRADA }; // تتغير حسب العيادة التي سجّل مديرها الدخول

// نفس التشفير التجريبي المستخدم في صفحة تسجيل العيادة (Shared)
const hashPass = s => { let h = 5381; for (const c of s) h = ((h << 5) + h + c.charCodeAt(0)) >>> 0; return h.toString(16); };

const ACCOUNTS = {
    'manager@karrada-clinic.iq': { name: 'أ. كريم الساعدي', role: 'manager' },
    'reception@karrada-clinic.iq': { name: 'سرى جبار', role: 'reception' }
};
const DEMO_PASS = '123456';

const PERMS = {
    'dashboard.view': 'عرض لوحة التحكم',
    'appointments.view': 'عرض المواعيد ومتابعة الحجوزات',
    'queue.view': 'متابعة الطوابير',
    'payments.view': 'عرض ملخص المدفوعات',
    'doctors.manage': 'إدارة الأطباء والأجور والطلبات',
    'schedule.edit': 'تعديل الدوام والعطل والجداول',
    'reports.view': 'التقارير والإيرادات'
};
const ROLE_INFO = {
    manager: { label: 'مدير العيادة', icon: '👔', perms: Object.keys(PERMS) },
    reception: { label: 'موظف استقبال', icon: '🧾', perms: ['dashboard.view', 'appointments.view', 'queue.view'] }
};

const ORDER = [6, 0, 1, 2, 3, 4, 5]; // السبت ← الجمعة
const DAY_NAMES = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];

const DIRECTORY = [
    { id: 'D-201', name: 'د. سارة أحمد', gender: 'f', specialty: 'أمراض القلب', exp: 12 },
    { id: 'D-205', name: 'د. زينب عبد الله', gender: 'f', specialty: 'طب الأسرة', exp: 6 },
    { id: 'D-208', name: 'د. حيدر العبيدي', gender: 'm', specialty: 'العظام والمفاصل', exp: 14 },
    { id: 'D-207', name: 'د. مريم الدليمي', gender: 'f', specialty: 'طب العيون', exp: 11 },
    { id: 'D-202', name: 'د. محمد الجبوري', gender: 'm', specialty: 'طب الأطفال', exp: 9 },
    { id: 'D-203', name: 'د. نور الهدى كريم', gender: 'f', specialty: 'الأمراض الجلدية', exp: 7 },
    { id: 'D-204', name: 'د. علي حسن الموسوي', gender: 'm', specialty: 'طب الأعصاب', exp: 15 },
    { id: 'D-206', name: 'د. أحمد السامرائي', gender: 'm', specialty: 'طب الأسنان', exp: 10 },
    { id: 'D-209', name: 'د. ياسر الخفاجي', gender: 'm', specialty: 'طب الأطفال', exp: 5 },
    { id: 'D-211', name: 'د. ليث المالكي', gender: 'm', specialty: 'العظام والمفاصل', exp: 4 },
    { id: 'D-214', name: 'د. سامر يوسف', gender: 'm', specialty: 'طب العيون', exp: 2 },
    { id: 'D-210', name: 'د. آمنة الشمري', gender: 'f', specialty: 'الأمراض الجلدية', exp: 8 }
];

const LINK_STATUS = {
    active:    { label: 'مرتبط بالعيادة', cls: 'success' },
    pending:   { label: 'بانتظار رد الطبيب', cls: 'warning' },
    declined:  { label: 'رفض الطبيب', cls: 'danger' },
    cancelled: { label: 'ملغى من العيادة', cls: 'muted' },
    removed:   { label: 'أُزيل الارتباط', cls: 'muted' }
};
const APPT_STATUS = {
    confirmed: { label: 'محجوز', cls: 'primary', color: '#1463ff', icon: '📅' },
    waiting:   { label: 'في الانتظار', cls: 'warning', color: '#f59e0b', icon: '⏳' },
    in:        { label: 'داخل الاستشارة', cls: 'purple live', color: '#7c3aed', icon: '🩺' },
    completed: { label: 'مكتمل', cls: 'success', color: '#16a34a', icon: '✓' },
    noshow:    { label: 'لم يحضر', cls: 'muted', color: '#94a3b8', icon: '✕' },
    cancelled: { label: 'ملغى', cls: 'danger', color: '#e5484d', icon: '⊘' }
};
const PAY_STATUS = {
    paid:     { label: 'مدفوع', cls: 'success', color: '#16a34a', icon: '✓' },
    pending:  { label: 'بانتظار الدفع', cls: 'warning', color: '#f59e0b', icon: '⏳' },
    refunded: { label: 'مسترد', cls: 'muted', color: '#94a3b8', icon: '↩' },
    failed:   { label: 'فشل الدفع', cls: 'danger', color: '#e5484d', icon: '!' }
};
const METHODS = {
    cash:   { label: 'نقداً', color: '#1463ff' },
    card:   { label: 'بطاقة مصرفية', color: '#12b5a5' },
    wallet: { label: 'محفظة إلكترونية', color: '#f59e0b' }
};

const PAGES = ['dashboard', 'doctors', 'appointments', 'schedule', 'queue', 'reports'];
const PAGE_INFO = {
    dashboard:    ['لوحة تحكم العيادة', CLINIC.name],
    doctors:      ['أطباء العيادة', 'الأطباء المرتبطون وطلبات الانضمام والأجور'],
    appointments: ['مواعيد العيادة', 'جميع الحجوزات والإلغاءات'],
    schedule:     ['إدارة الدوام', 'أوقات العمل والعطل وجداول الأطباء'],
    queue:        ['طوابير العيادة', 'متابعة المرضى المنتظرين مباشرة'],
    reports:      ['تقارير العيادة', 'الحجوزات والأداء والإيرادات']
};


/* =================== توليد البيانات التجريبية =================== */
function seededRandom(seed) {
    return () => {
        seed |= 0; seed = seed + 0x6D2B79F5 | 0;
        let t = Math.imul(seed ^ seed >>> 15, 1 | seed);
        t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
        return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
}

function slotsBetween(from, to, step = 30) {
    const out = [];
    let [h, m] = from.split(':').map(Number);
    const [eh, em] = to.split(':').map(Number);
    while (h * 60 + m + step <= eh * 60 + em) {
        out.push(`${pad(h)}:${pad(m)}`);
        m += step; h += Math.floor(m / 60); m %= 60;
    }
    return out;
}

function generateData() {
    const R = seededRandom(4242);
    const pick = a => a[Math.floor(R() * a.length)];
    const now = Date.now();
    const day = 86400000;
    const evening = ['16:00', '21:00'];

    const links = [
        { doctorId: 'D-201', status: 'active', fee: 25000, letter: 'A', shifts: { 6: evening, 0: evening, 1: evening, 2: evening, 3: evening }, requestedAt: now - 400 * day, respondedAt: now - 398 * day },
        { doctorId: 'D-205', status: 'active', fee: 15000, letter: 'B', shifts: { 0: ['09:00', '13:00'], 1: ['09:00', '13:00'], 2: ['09:00', '13:00'], 3: ['09:00', '13:00'], 4: ['09:00', '13:00'] }, requestedAt: now - 300 * day, respondedAt: now - 299 * day },
        { doctorId: 'D-208', status: 'active', fee: 35000, letter: 'C', shifts: { 6: ['15:00', '19:00'], 1: ['15:00', '19:00'], 3: ['15:00', '19:00'] }, requestedAt: now - 250 * day, respondedAt: now - 248 * day },
        { doctorId: 'D-207', status: 'active', fee: 30000, letter: 'D', shifts: { 6: ['16:00', '20:00'], 0: ['16:00', '20:00'], 2: ['16:00', '20:00'], 4: ['16:00', '20:00'] }, requestedAt: now - 180 * day, respondedAt: now - 179 * day },
        { doctorId: 'D-209', status: 'pending', fee: 20000, shifts: { 0: ['16:00', '20:00'], 2: ['16:00', '20:00'] }, requestedAt: now - 2 * day, message: 'نرحب بانضمامك لفريق العيادة.' },
        { doctorId: 'D-211', status: 'pending', fee: 30000, shifts: { 1: ['10:00', '14:00'], 3: ['10:00', '14:00'] }, requestedAt: now - 5 * 3600000, message: '' },
        { doctorId: 'D-214', status: 'declined', fee: 25000, shifts: { 4: ['16:00', '20:00'] }, requestedAt: now - 12 * day, respondedAt: now - 10 * day, note: 'جدول الطبيب ممتلئ حالياً' },
        { doctorId: 'D-206', status: 'removed', fee: 20000, letter: 'E', shifts: {}, oldShifts: { 6: ['10:00', '14:00'], 1: ['10:00', '14:00'], 3: ['10:00', '14:00'] }, requestedAt: now - 220 * day, respondedAt: now - 20 * day, note: 'انتهاء فترة التعاقد' }
    ].map(l => ({ pendingShifts: {}, note: '', message: '', ...l }));

    const hours = {};
    [0, 1, 2, 3, 4, 6].forEach(d => { hours[d] = { open: true, from: '09:00', to: '22:00' }; });
    hours[5] = { open: false, from: '09:00', to: '22:00' };

    const holidays = [
        { id: 'H-1', date: toISO(addDays(new Date(), -6)), name: 'عطلة رسمية' },
        { id: 'H-2', date: toISO(addDays(new Date(), 9)), name: 'عطلة رسمية' },
        { id: 'H-3', date: toISO(addDays(new Date(), 23)), name: 'صيانة دورية للعيادة' }
    ];
    const holidaySet = new Set(holidays.map(h => h.date));

    const firsts = ['علي', 'زينب', 'محمد', 'نور', 'حيدر', 'فاطمة', 'حسين', 'مريم', 'عباس', 'رقية', 'أحمد', 'سجى', 'كرار', 'هدى', 'مصطفى', 'بنين', 'يوسف', 'تبارك', 'منتظر', 'زهراء', 'سيف', 'دعاء', 'حسن', 'آيات', 'مرتضى', 'غدير', 'جعفر', 'إسراء'];
    const lasts = ['حسن', 'كاظم', 'كريم', 'حسين', 'جاسم', 'علي', 'صادق', 'فاضل', 'مهدي', 'سلمان', 'رعد', 'ناصر', 'عادل', 'جواد'];
    const patients = firsts.map((f, i) => ({
        id: `U-${1101 + i}`, name: `${f} ${pick(lasts)}`, gender: i % 2 ? 'f' : 'm',
        phone: `07${pick(['70', '71', '80', '50'])}${Math.floor(1000000 + R() * 8999999)}`
    }));

    const cancelReasons = {
        'المريض': ['ظرف طارئ', 'تغيير الموعد', 'تحسّن الحالة'],
        'الطبيب': ['ظرف طارئ لدى الطبيب'],
        'العيادة': ['تعارض في جدول العيادة']
    };

    const appts = [];
    let idc = 61200;
    for (let off = -30; off <= 7; off++) {
        const date = addDays(new Date(), off);
        const iso = toISO(date), wd = date.getDay();
        if (!hours[wd].open || holidaySet.has(iso)) continue;

        links.forEach(l => {
            const shifts = l.status === 'active' ? l.shifts : (l.status === 'removed' && off < -20 ? l.oldShifts : null);
            if (!shifts || !shifts[wd]) return;
            const slots = slotsBetween(shifts[wd][0], shifts[wd][1]);
            const morning = shifts[wd][1] <= '14:00';
            const n = off === 0 ? Math.min(slots.length, 5 + Math.floor(R() * 3)) : Math.floor(R() * slots.length * 0.75);
            const used = new Set();
            const fee = l.fee;

            for (let k = 0; k < n; k++) {
                let p;
                do { p = pick(patients); } while (used.has(p.id) && used.size < patients.length);
                used.add(p.id);

                let status;
                if (off < 0) { const r = R(); status = r < 0.8 ? 'completed' : r < 0.9 ? 'cancelled' : 'noshow'; }
                else if (off > 0) status = R() < 0.9 ? 'confirmed' : 'cancelled';
                else if (morning) status = R() < 0.9 ? 'completed' : 'noshow';
                else status = k < 2 ? 'completed' : k === 2 ? 'in' : k < 5 ? 'waiting' : (R() < 0.85 ? 'confirmed' : 'cancelled');

                const method = pick(['cash', 'cash', 'card', 'wallet']);
                let pay = null;
                if (status === 'completed') pay = R() < 0.03 ? 'failed' : 'paid';
                else if (status === 'cancelled') pay = method === 'cash' ? null : 'refunded';
                else if (status === 'noshow') pay = method === 'cash' ? null : 'paid';
                else pay = method === 'cash' ? 'pending' : 'paid';

                const slotTs = parseISO(iso).getTime() + (Number(slots[k].split(':')[0]) * 60 + Number(slots[k].split(':')[1])) * 60000;
                const a = {
                    id: `SC-${idc += 1 + Math.floor(R() * 25)}`,
                    doctorId: l.doctorId, patientId: p.id, date: iso, time: slots[k],
                    queueNo: `${l.letter}-${pad(k + 1)}`, status, fee,
                    payment: pay ? { method, status: pay, amount: fee } : null,
                    bookedAt: Math.min(now - 3600000, slotTs - Math.floor(R() * 8 * day) - 3600000)
                };
                if (status === 'cancelled') {
                    const by = R() < 0.7 ? 'المريض' : R() < 0.5 ? 'الطبيب' : 'العيادة';
                    a.cancelledBy = by;
                    a.cancelReason = pick(cancelReasons[by]);
                    a.cancelledAt = Math.min(now - 600000, a.bookedAt + Math.floor(R() * 3 * day));
                }
                if (status === 'waiting' || status === 'in') a.arrivedAt = now - (45 - k * 7) * 60000;
                appts.push(a);
            }
        });
    }

    return {
        v: 1, seedDate: todayISO(), links, patients, appts, hours, holidays,
        reception: { before: 30, last: 30 },
        queuePaused: { 'D-207': true },
        hoursUpdated: { by: 'أ. كريم الساعدي', at: now - 14 * day },
        notifs: [
            { icon: '📨', text: 'طلبان للانضمام بانتظار رد الأطباء', t: now - 3 * 3600000, unread: true },
            { icon: '⏸', text: 'طابور د. مريم الدليمي متوقف مؤقتاً (استراحة)', t: now - 20 * 60000, unread: true }
        ]
    };
}


/* =================== الحالة =================== */
const state = {
    data: null,
    session: null,
    page: '',
    docTab: 'linked',
    docQ: '',
    reqStatus: '',
    apptView: 'table',
    apptFilter: { q: '', doctor: '', date: todayISO(), status: '' },
    feedFilter: { type: '', days: 2 },
    pages: { appt: 1 },
    payRange: 'today',
    report: { period: '7', from: '', to: '' },
    hoursDraft: null,
    loginFails: 0,
    lockUntil: 0,
    lastQueueUpdate: Date.now(),
    timers: []
};

// لكل عيادة بياناتها الخاصة: عيادة الكرادة (تجريبية) أو عيادة مسجّلة حديثاً
const dataKey = () => CLINIC.reqId ? 'scClinic_data_' + CLINIC.reqId : 'scClinic_data';

function loadData(session) {
    let d = rawGet(dataKey());
    if (!CLINIC.reqId) { if (!d || d.v !== 1 || d.seedDate !== todayISO()) d = generateData(); }
    else if (!d || d.v !== 1) d = generateEmptyData(session);
    state.data = d;
    state.hoursDraft = null;
    saveData();
}
const saveData = () => rawSet(dataKey(), state.data);

// عيادة جديدة: تبدأ بدون أطباء ولا مواعيد، وبأوقات العمل التي أدخلتها عند التسجيل
function generateEmptyData(session) {
    const base = generateData();
    const req = (rawGet('smartClinic_clinicRequests') || []).find(r => r.reqId === session.reqId);
    const hours = {};
    [0, 1, 2, 3, 4, 5, 6].forEach(d => {
        hours[d] = { open: req ? req.hours.days.includes(d) : d !== 5, from: req ? req.hours.from : '09:00', to: req ? req.hours.to : '21:00' };
    });
    return {
        ...base, links: [], appts: [], holidays: [], queuePaused: {}, hours, hoursUpdated: null,
        notifs: [{ icon: '🎉', text: `أهلاً بك في لوحة ${session.clinicName}! ابدأ بإرسال طلبات انضمام للأطباء`, t: Date.now(), unread: true }]
    };
}

// التحقق من بيانات الدخول (حسابات تجريبية + العيادات المسجّلة وحالة اعتمادها من الإدارة)
function authenticate(email, pass) {
    const admin = rawGet('scAdmin_data');
    const acc = ACCOUNTS[email];
    if (acc) {
        if (pass !== DEMO_PASS) return { fail: true };
        const ac = admin && admin.clinics ? admin.clinics.find(c => c.id === 'CL-01') : null;
        if (acc.role === 'manager' && ac && ac.manager.status === 'disabled') return { msg: '🚫 حساب مدير العيادة معطّل من إدارة النظام. تواصل مع الإدارة.' };
        return { session: { email, name: acc.name, role: acc.role, clinicId: KARRADA.id, clinicName: KARRADA.name, city: KARRADA.city, address: KARRADA.address, reqId: '', at: Date.now() } };
    }
    const req = (rawGet('smartClinic_clinicRequests') || []).find(r => r.manager.email === email);
    if (!req) return email.endsWith('@smartclinic.iq') ? { msg: '⚠️ هذا الحساب ليس حساب عيادة. استخدم بوابة الدخول المناسبة لنوع حسابك.' } : { fail: true };
    if (req.manager.pass !== hashPass(pass)) return { fail: true };
    const st = registeredStatus(req);
    if (st.msg) return st;
    return { session: { email, name: req.manager.name, role: 'manager', clinicId: st.clinicId, clinicName: req.name, city: req.city, address: req.address, reqId: req.reqId, at: Date.now() } };
}

function registeredStatus(req) {
    const admin = rawGet('scAdmin_data');
    const ac = admin && admin.clinics ? admin.clinics.find(c => c.reqId === req.reqId) : null;
    if (!ac || ac.status === 'pending') return { msg: `⏳ طلب تسجيل «${esc(req.name)}» (${req.reqId}) قيد المراجعة من إدارة النظام. يمكنك الدخول بعد قبول الطلب وتفعيل الحساب.`, type: 'info' };
    if (ac.status === 'rejected') return { msg: `✕ تم رفض طلب تسجيل العيادة${ac.reason ? ': ' + esc(ac.reason) : ''}. <a href="../Shared/clinic-register.html" class="text-button">تقديم طلب جديد</a>` };
    if (ac.manager.status === 'inactive') return { msg: '✓ تم قبول عيادتك! حساب المدير بانتظار التفعيل من إدارة النظام.', type: 'info' };
    if (ac.manager.status === 'disabled') return { msg: '🚫 حساب مدير العيادة معطّل من إدارة النظام. تواصل مع الإدارة.' };
    return { clinicId: ac.id };
}
const D = () => state.data;

const docInfo = id => DIRECTORY.find(d => d.id === id);
const getLink = id => D().links.find(l => l.doctorId === id);
const activeLinks = () => D().links.filter(l => l.status === 'active');
const patientOf = id => D().patients.find(p => p.id === id);
const docIcon = d => d.gender === 'f' ? '👩‍⚕️' : '👨‍⚕️';
const isHoliday = iso => D().holidays.find(h => h.date === iso);
const todayAppts = () => D().appts.filter(a => a.date === todayISO());
const can = p => !!state.session && ROLE_INFO[state.session.role].perms.includes(p);
const byTime = (a, b) => (a.date + a.time).localeCompare(b.date + b.time);

function denied() {
    toast('🔒 هذه العملية تتطلب صلاحية مدير العيادة', 'error');
}


/* =================== الإشعارات والنوافذ =================== */
function toast(msg, type = 'success') {
    const icons = { success: '✓', error: '!', info: 'i', warning: '!' };
    const el = document.createElement('div');
    el.className = `toast ${type}`;
    el.innerHTML = `<span class="toast-icon">${icons[type] || 'i'}</span><span>${msg}</span>`;
    $('#toastStack').appendChild(el);
    requestAnimationFrame(() => requestAnimationFrame(() => el.classList.add('show')));
    setTimeout(() => { el.classList.remove('show'); setTimeout(() => el.remove(), 500); }, 3300);
}

let modalResolver = null;
function openModal(html, size = '') {
    const m = $('#modal');
    $('#modalBody').innerHTML = html;
    m.className = 'modal open ' + size;
    m.setAttribute('aria-hidden', 'false');
    document.body.classList.add('no-scroll');
}
function closeModal() {
    const m = $('#modal');
    if (!m.classList.contains('open')) return;
    m.classList.remove('open');
    m.setAttribute('aria-hidden', 'true');
    if (!$('#drawer').classList.contains('open')) document.body.classList.remove('no-scroll');
    if (modalResolver) { const r = modalResolver; modalResolver = null; r(false); }
}
function confirmDialog({ title, text, ok = 'تأكيد', danger = false, icon = '⚠️' }) {
    return new Promise(resolve => {
        openModal(`
            <div class="confirm">
                <div class="confirm-icon ${danger ? 'danger' : ''}">${icon}</div>
                <h3>${title}</h3>
                <p class="muted">${text}</p>
                <div class="confirm-actions">
                    <button class="btn light" data-confirm="no">تراجع</button>
                    <button class="btn ${danger ? 'danger' : 'primary'}" data-confirm="yes">${ok}</button>
                </div>
            </div>`);
        modalResolver = resolve;
    });
}
function openDrawer(html) {
    $('#drawerBody').innerHTML = html;
    $('#drawer').classList.add('open');
    document.body.classList.add('no-scroll');
    $('.drawer-panel').scrollTop = 0;
}
function closeDrawer() {
    $('#drawer').classList.remove('open');
    if (!$('#modal').classList.contains('open')) document.body.classList.remove('no-scroll');
}
function setError(input, msg) {
    const g = input && input.closest('.form-group');
    if (!g) return !msg;
    g.classList.toggle('has-error', !!msg);
    const e = $('.error-text', g);
    if (e) e.textContent = msg || '';
    return !msg;
}

function notify(icon, text) {
    D().notifs.unshift({ icon, text, t: Date.now(), unread: true });
    D().notifs = D().notifs.slice(0, 20);
    saveData();
    renderNotifs();
    const b = $('#notifBtn');
    b.classList.remove('ring'); void b.offsetWidth; b.classList.add('ring');
}
function renderNotifs() {
    const list = D().notifs;
    const unread = list.filter(n => n.unread).length;
    $('#notifCount').hidden = !unread;
    $('#notifCount').textContent = unread;
    $('#notifList').innerHTML = list.length
        ? list.map(n => `<div class="notif-item ${n.unread ? 'unread' : ''}"><span class="ni-icon">${n.icon}</span><div>${esc(n.text)}<small>${timeAgo(n.t)}</small></div></div>`).join('')
        : '<div class="notif-empty">لا توجد إشعارات 🎉</div>';
}


/* =================== الرسوم =================== */
function renderBarChart(el, items, color = '#12b5a5') {
    const max = Math.max(1, ...items.map(x => x.value));
    const step = Math.ceil(items.length / 8);
    const showVals = items.length <= 14;
    el.classList.remove('ready');
    el.innerHTML =
        `<div class="grid-line" style="bottom:calc(30px + (100% - 56px) * .5)"></div>
         <div class="grid-line" style="bottom:calc(30px + (100% - 56px))"></div>` +
        items.map((x, i) => {
            const pct = (x.value / max) * 100;
            return `
            <div class="bar-col" data-tip="${esc(x.tip)}">
                ${showVals ? `<span class="bar-val" data-b="${pct}">${x.value}</span>` : ''}
                <div class="bar" style="--i:${i}; background:${color}" data-h="${pct}"></div>
                ${i % step === 0 || i === items.length - 1 ? `<span class="bar-label">${x.label}</span>` : ''}
            </div>`;
        }).join('');
    requestAnimationFrame(() => requestAnimationFrame(() => {
        $$('.bar', el).forEach(b => { b.style.height = `max(${b.dataset.h}%, ${b.dataset.h > 0 ? 4 : 2}px)`; });
        $$('.bar-val', el).forEach(v => { v.style.bottom = v.dataset.b + '%'; });
        el.classList.add('ready');
    }));
}
function renderStack(el, parts, money = false) {
    const total = parts.reduce((s, p) => s + p.value, 0);
    if (!total) { el.innerHTML = '<p class="chart-empty muted">لا توجد بيانات في هذه الفترة</p>'; return; }
    el.innerHTML = `
        <div class="stack-bar">${parts.filter(p => p.value).map(p => `<i style="background:${p.color}" data-w="${(p.value / total) * 100}" title="${p.label}"></i>`).join('')}</div>
        <div class="legend">
            ${parts.map(p => `
                <div class="legend-row">
                    <i class="sw" style="background:${p.color}"></i>
                    <span>${p.icon} ${p.label}${p.count !== undefined ? ` <small class="muted">(${p.count})</small>` : ''}</span>
                    <b>${money ? fmtMoney(p.value) : p.value}</b>
                    <em>${Math.round((p.value / total) * 100)}%</em>
                </div>`).join('')}
        </div>`;
    requestAnimationFrame(() => requestAnimationFrame(() => {
        $$('.stack-bar i', el).forEach(i => { i.style.width = i.dataset.w + '%'; });
    }));
}
function renderHBars(el, rows) {
    const max = Math.max(1, ...rows.map(r => r.value));
    el.innerHTML = rows.map(r => `
        <div class="hbar-row">
            <span>${r.label}</span>
            <div class="hbar-track"><i style="background:${r.color}" data-w="${(r.value / max) * 100}"></i></div>
            <b>${r.text}</b>
        </div>`).join('');
    requestAnimationFrame(() => requestAnimationFrame(() => {
        $$('.hbar-track i', el).forEach(i => { i.style.width = i.dataset.w + '%'; });
    }));
}
function statCard({ icon, label, value, sub, color, money = false }, i) {
    return `
    <div class="stat-card card-anim" style="--c:${color}; --i:${i}">
        <div class="stat-top"><span class="stat-icon">${icon}</span></div>
        <p>${label}</p>
        <h2 data-count="${value}" data-money="${money ? 1 : ''}">0</h2>
        <small>${sub}</small>
    </div>`;
}
function animateCounts(root) {
    $$('[data-count]', root).forEach(el => {
        const target = Number(el.dataset.count), money = !!el.dataset.money;
        const start = performance.now();
        const step = now => {
            const p = Math.min((now - start) / 1100, 1);
            const v = Math.round(target * (1 - Math.pow(1 - p, 3)));
            el.textContent = money ? fmtMoney(v) : v;
            if (p < 1) requestAnimationFrame(step);
        };
        requestAnimationFrame(step);
    });
}
function bindChartTips() {
    const tip = $('#chartTip');
    document.addEventListener('mousemove', e => {
        const col = e.target.closest('.bar-col');
        if (!col) { tip.classList.remove('show'); return; }
        const r = col.getBoundingClientRect();
        tip.textContent = col.dataset.tip;
        tip.style.left = (r.left + r.width / 2) + 'px';
        tip.style.top = (r.top + 18) + 'px';
        tip.classList.add('show');
    });
}

function paginate(list, key, size) {
    const pages = Math.max(1, Math.ceil(list.length / size));
    if (state.pages[key] > pages) state.pages[key] = pages;
    const page = state.pages[key];
    return { rows: list.slice((page - 1) * size, page * size), page, pages, total: list.length, size };
}
function renderPager(el, key, { page, pages, total, size }) {
    if (!total) { el.innerHTML = ''; return; }
    const from = (page - 1) * size + 1, to = Math.min(total, page * size);
    const nums = [];
    const start = Math.max(1, Math.min(page - 2, pages - 4));
    for (let i = start; i <= Math.min(pages, start + 4); i++) nums.push(i);
    el.innerHTML = `
        <span>عرض ${from}–${to} من ${total}</span>
        <div class="pager-btns">
            <button data-pg="${key}" data-to="${page - 1}" ${page <= 1 ? 'disabled' : ''}>→</button>
            ${nums.map(n => `<button data-pg="${key}" data-to="${n}" class="${n === page ? 'active' : ''}">${n}</button>`).join('')}
            <button data-pg="${key}" data-to="${page + 1}" ${page >= pages ? 'disabled' : ''}>←</button>
        </div>`;
}


/* =================== تسجيل الدخول (24) =================== */
function showLoginAlert(msg, type = '') {
    const a = $('#loginAlert');
    a.hidden = false;
    a.className = 'form-alert ' + type;
    a.innerHTML = `<span>${msg}</span>`;
}

function bindLogin() {
    const form = $('#loginForm'), email = $('#loginEmail'), pass = $('#loginPassword');

    $('#togglePass').addEventListener('click', () => {
        pass.type = pass.type === 'password' ? 'text' : 'password';
        $('#togglePass').textContent = pass.type === 'password' ? '👁' : '🙈';
    });
    $$('[data-demo]').forEach(b => b.addEventListener('click', () => {
        email.value = `${b.dataset.demo}@karrada-clinic.iq`;
        pass.value = DEMO_PASS;
        setError(email, ''); setError(pass, '');
        toast(`تمت تعبئة حساب ${ROLE_INFO[b.dataset.demo].label}`, 'info');
    }));
    $('#forgotBtn').addEventListener('click', () => showLoginAlert('ℹ️ لإعادة تعيين كلمة المرور تواصل مع إدارة النظام.', 'info'));
    [email, pass].forEach(i => i.addEventListener('input', () => setError(i, '')));

    form.addEventListener('submit', e => {
        e.preventDefault();
        if (Date.now() < state.lockUntil) return;
        const ev = email.value.trim().toLowerCase(), pv = pass.value;
        let ok = true;
        if (!ev) ok = setError(email, 'البريد الإلكتروني مطلوب') && ok;
        else if (!isEmail(ev)) ok = setError(email, 'صيغة البريد الإلكتروني غير صحيحة') && ok;
        else setError(email, '');
        if (!pv) ok = setError(pass, 'كلمة المرور مطلوبة') && ok;
        else if (pv.length < 6) ok = setError(pass, 'كلمة المرور 6 أحرف على الأقل') && ok;
        else setError(pass, '');
        if (!ok) { $('#loginAlert').hidden = true; shake(form); return; }

        const btn = $('#loginBtn');
        setLoading(btn, true);
        setTimeout(() => {
            setLoading(btn, false);
            const res = authenticate(ev, pv);
            if (!res.session) {
                if (res.msg) {
                    showLoginAlert(res.msg, res.type || '');
                } else {
                    state.loginFails++;
                    if (state.loginFails >= 5) lockLogin();
                    else showLoginAlert(`⚠️ البريد الإلكتروني أو كلمة المرور غير صحيحة. المحاولات المتبقية: <b>${5 - state.loginFails}</b>`);
                }
                shake(form);
                return;
            }
            state.loginFails = 0;
            const session = res.session;
            const acc = { name: session.name, role: session.role };
            rawSet('scClinic_session', session, $('#rememberMe').checked ? localStorage : sessionStorage);

            showLoginAlert(`✓ أهلاً ${acc.name} (${ROLE_INFO[acc.role].label})، جاري التوجيه...`, 'success');
            setLoading(btn, true);
            setTimeout(() => {
                setLoading(btn, false);
                $('#loginScreen').classList.add('leaving');
                setTimeout(() => {
                    $('#loginScreen').classList.remove('leaving');
                    enterApp(session);
                    toast(`مرحباً ${acc.name} 👋`, 'success');
                }, 550);
            }, 800);
        }, 900);
    });
}

function lockLogin() {
    state.lockUntil = Date.now() + 30000;
    const btn = $('#loginBtn');
    btn.disabled = true;
    const t = setInterval(() => {
        const s = Math.ceil((state.lockUntil - Date.now()) / 1000);
        if (s <= 0) {
            clearInterval(t); btn.disabled = false; state.loginFails = 0;
            showLoginAlert('يمكنك المحاولة مجدداً الآن.', 'info');
            return;
        }
        showLoginAlert(`🔒 تم تجاوز عدد المحاولات. حاول بعد <b>${s}</b> ثانية.`);
    }, 250);
}

function showLogin() {
    state.session = null;
    $('#clinicApp').hidden = true;
    $('#loginScreen').hidden = false;
    $('#loginAlert').hidden = true;
    $('#loginForm').reset();
    $('#rememberMe').checked = true;
    closeModal(); closeDrawer();
}

function enterApp(session) {
    state.session = session;
    CLINIC = session.reqId
        ? { id: session.clinicId, name: session.clinicName, city: session.city, address: session.address, reqId: session.reqId }
        : { ...KARRADA };
    PAGE_INFO.dashboard[1] = CLINIC.name;
    loadData(session);
    $('#loginScreen').hidden = true;
    $('#clinicApp').hidden = false;
    const R = ROLE_INFO[session.role];
    $('#sideClinic').textContent = CLINIC.name;
    $('#sideUser').textContent = session.name;
    $('#sideRole').textContent = `${R.icon} ${R.label}`;
    $('#topName').textContent = session.name;
    $('#topRole').textContent = R.label;
    $('#topAvatar').textContent = session.name.replace('أ. ', '').charAt(0);
    $('.side-link[data-page="reports"]').classList.toggle('locked', !can('reports.view'));
    renderNotifs();
    const start = location.hash.replace('#', '');
    state.page = '';
    go(PAGES.includes(start) ? start : 'dashboard');
    requestAnimationFrame(moveIndicator);
}

function logout() {
    confirmDialog({ title: 'تسجيل الخروج؟', text: 'سيتم إنهاء جلستك في لوحة العيادة.', ok: 'تسجيل الخروج', danger: true, icon: '🚪' })
        .then(ok => {
            if (!ok) return;
            rawDel('scClinic_session');
            try { history.replaceState(null, '', location.pathname); } catch (e) { /* تجاهل */ }
            showLogin();
            toast('تم تسجيل الخروج بنجاح', 'info');
        });
}

function openAccount() {
    const s = state.session, R = ROLE_INFO[s.role];
    openModal(`
        <div class="confirm">
            <div class="confirm-icon">${R.icon}</div>
            <h3>${esc(s.name)}</h3>
            <p class="muted">${R.label} · ${CLINIC.name}</p>
        </div>
        <div class="detail-grid mt">
            <div><span>البريد</span><b dir="ltr">${esc(s.email)}</b></div>
            <div><span>العيادة</span><b>${CLINIC.address}</b></div>
        </div>
        <h4>صلاحيات الحساب</h4>
        <ul class="perm-list">
            ${Object.entries(PERMS).map(([k, l]) => `<li class="${can(k) ? '' : 'no'}">${can(k) ? '✅' : '🔒'} ${l}</li>`).join('')}
        </ul>
        <div class="confirm-actions">
            <button class="btn light" data-close-modal>إغلاق</button>
            <button class="btn danger-light" id="modalLogout">🚪 تسجيل الخروج</button>
        </div>`);
}


/* =================== التنقل =================== */
function go(page) {
    if (!PAGES.includes(page)) page = 'dashboard';
    document.body.classList.remove('sidebar-open');
    if (page !== state.page) {
        $$('.page').forEach(p => p.classList.toggle('active', p.dataset.page === page));
        $$('.side-link').forEach(l => l.classList.toggle('active', l.dataset.page === page));
        state.page = page;
        moveIndicator();
        try { history.replaceState(null, '', '#' + page); } catch (e) { /* تجاهل */ }
        const [t, s] = PAGE_INFO[page];
        $('#pageTitle').textContent = t;
        $('#pageSub').textContent = s;
        const tt = $('.topbar-title');
        tt.classList.remove('swap'); void tt.offsetWidth; tt.classList.add('swap');
    }
    renderPage();
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function renderPage() {
    ({
        dashboard: renderDashboard,
        doctors: renderDoctors,
        appointments: renderApptView,
        schedule: renderSchedule,
        queue: renderQueue,
        reports: renderReports
    })[state.page]();
    updateBadges();
}

function moveIndicator() {
    const a = $('.side-link.active'), ind = $('#sideIndicator');
    if (!a || !ind) return;
    ind.style.height = a.offsetHeight + 'px';
    ind.style.transform = `translateY(${a.offsetTop}px)`;
}

function updateBadges() {
    $('#badgeReq').textContent = D().links.filter(l => l.status === 'pending').length || '';
    const pendingShifts = D().links.reduce((s, l) => s + Object.keys(l.pendingShifts || {}).length, 0);
    $('#badgeSched').textContent = pendingShifts || '';
    $('#badgeQueue').textContent = todayAppts().filter(a => a.status === 'waiting').length || '';
}


/* =================== حالة العيادة الآن =================== */
function clinicStatusNow() {
    const iso = todayISO(), wd = new Date().getDay();
    const hol = isHoliday(iso);
    if (hol) return { open: false, text: `مغلقة اليوم · ${hol.name}` };
    const h = D().hours[wd];
    if (!h.open) return { open: false, text: `مغلقة اليوم (${DAY_NAMES[wd]})` };
    const now = nowHM();
    if (now < h.from) return { open: false, text: `تفتح اليوم الساعة ${fmtTime(h.from)}` };
    if (now >= h.to) return { open: false, text: `أُغلقت الساعة ${fmtTime(h.to)}` };
    return { open: true, text: `مفتوحة الآن · حتى ${fmtTime(h.to)}` };
}

function queueStateOf(docId) {
    const list = todayAppts().filter(a => a.doctorId === docId && a.status !== 'cancelled');
    if (!list.length) return { key: 'none', label: 'لا مواعيد', cls: 'muted' };
    if (D().queuePaused[docId]) return { key: 'paused', label: 'متوقف مؤقتاً', cls: 'warning' };
    if (list.some(a => a.status === 'in' || a.status === 'waiting')) return { key: 'active', label: 'نشط', cls: 'success' };
    if (list.every(a => ['completed', 'noshow'].includes(a.status))) return { key: 'done', label: 'انتهى', cls: 'primary' };
    return { key: 'idle', label: 'لم يبدأ', cls: 'muted' };
}


/* =================== 25. لوحة التحكم =================== */
function renderDashboard() {
    const h = new Date().getHours();
    const wd = new Date().getDay();
    const t = todayAppts();
    const active = t.filter(a => a.status !== 'cancelled');
    const waiting = t.filter(a => a.status === 'waiting');
    const onDuty = activeLinks().filter(l => l.shifts[wd] && !isHoliday(todayISO()));
    const st = clinicStatusNow();

    $('#todayLabel').textContent = fmtDate(todayISO(), { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
    $('#greeting').textContent = `${h < 12 ? 'صباح الخير' : 'مساء الخير'} ${state.session.name.split(' ').slice(0, 2).join(' ')} 👋`;
    $('#welcomeSub').textContent = `${onDuty.length} أطباء على الدوام اليوم و ${active.length} موعداً في ${CLINIC.name}.`;
    const os = $('#openState');
    os.classList.toggle('closed', !st.open);
    os.innerHTML = `<i></i> ${st.text}`;

    const maxWait = Math.max(0, ...activeLinks().map(l => t.filter(a => a.doctorId === l.doctorId && a.status === 'waiting').length * 15));
    $('#welcomeSide').innerHTML = `
        <small>المرضى المنتظرون الآن</small>
        <div class="wc-num">${waiting.length}</div>
        <div class="wc-row"><span>داخل الاستشارة</span><b>${t.filter(a => a.status === 'in').length}</b></div>
        <div class="wc-row"><span>أطول انتظار متوقع</span><b>~${maxWait} د</b></div>
        <button class="btn light sm block" data-go="queue">متابعة الطوابير ←</button>`;

    $('#dashStats').innerHTML = [
        { icon: '🩺', label: 'الأطباء العاملون بالعيادة', value: activeLinks().length, sub: `${onDuty.length} على الدوام اليوم`, color: '#12b5a5' },
        { icon: '📅', label: 'مواعيد اليوم', value: active.length, sub: `${t.filter(a => a.status === 'confirmed').length} لم يصلوا بعد`, color: '#1463ff' },
        { icon: '⏳', label: 'المرضى المنتظرون', value: waiting.length, sub: 'في طوابير الأطباء', color: '#f59e0b' },
        { icon: '✓', label: 'المكتملة اليوم', value: t.filter(a => a.status === 'completed').length, sub: `${t.filter(a => a.status === 'cancelled').length} ملغاة · ${t.filter(a => a.status === 'noshow').length} لم يحضر`, color: '#16a34a' }
    ].map(statCard).join('');
    animateCounts($('#dashStats'));

    $('#onDutyList').innerHTML = onDuty.length ? onDuty.map((l, i) => {
        const d = docInfo(l.doctorId), q = queueStateOf(l.doctorId);
        const w = t.filter(a => a.doctorId === l.doctorId && a.status === 'waiting').length;
        return `
        <div class="mini-item" style="--i:${i}">
            <span class="pt-avatar">${docIcon(d)}</span>
            <div class="up-info">
                <button class="link-btn" data-act="doc-view" data-id="${d.id}"><strong>${esc(d.name)}</strong></button>
                <small>${d.specialty} · ${fmtTime(l.shifts[wd][0])} – ${fmtTime(l.shifts[wd][1])}</small>
            </div>
            <small class="muted">${w} منتظر</small>
            <span class="badge ${q.cls}">${q.label}</span>
        </div>`;
    }).join('') : '<div class="empty-state"><div class="empty-icon">🏖️</div><h3>لا يوجد أطباء على الدوام اليوم</h3></div>';

    renderPaySummary();

    const week = [];
    for (let i = 6; i >= 0; i--) {
        const iso = toISO(addDays(new Date(), -i));
        const list = D().appts.filter(a => a.date === iso);
        week.push({ label: relDay(iso).split('،')[0], value: list.length, tip: `${fmtDate(iso, { weekday: 'long', day: 'numeric', month: 'short' })}: ${list.length} حجز · ${list.filter(a => a.status === 'completed').length} مكتملة` });
    }
    renderBarChart($('#weekChart'), week);

    renderStack($('#todayStatus'), ['completed', 'in', 'waiting', 'confirmed', 'noshow', 'cancelled'].map(k => ({
        label: APPT_STATUS[k].label, icon: APPT_STATUS[k].icon, color: APPT_STATUS[k].color,
        value: t.filter(a => a.status === k).length
    })));
}

function renderPaySummary() {
    const box = $('#paySummary');
    if (!can('payments.view')) {
        box.innerHTML = '<div class="empty-state"><div class="empty-icon">🔒</div><h3>غير متاح لحسابك</h3><p>ملخص المدفوعات متاح لمدير العيادة فقط.</p></div>';
        return;
    }
    const n = new Date();
    const from = state.payRange === 'today' ? todayISO() : toISO(new Date(n.getFullYear(), n.getMonth(), 1));
    const list = D().appts.filter(a => a.payment && a.date >= from && a.date <= todayISO());
    renderStack(box, Object.entries(PAY_STATUS).map(([k, s]) => {
        const items = list.filter(a => a.payment.status === k);
        return { label: s.label, icon: s.icon, color: s.color, count: items.length, value: items.reduce((x, a) => x + a.payment.amount, 0) };
    }), true);
}


/* =================== 26. أطباء العيادة =================== */
function shiftSummary(shifts) {
    const days = ORDER.filter(d => shifts[d]);
    if (!days.length) return { days: 'لا يوجد دوام', hours: '—' };
    const first = shifts[days[0]];
    const same = days.every(d => shifts[d][0] === first[0] && shifts[d][1] === first[1]);
    return {
        days: days.map(d => DAY_NAMES[d].replace('ال', '')).join('، '),
        hours: same ? `${fmtTime(first[0])} – ${fmtTime(first[1])}` : 'أوقات مختلفة'
    };
}

function bindDoctors() {
    $('#docTabs').addEventListener('click', e => {
        const b = e.target.closest('[data-tab]');
        if (!b) return;
        state.docTab = b.dataset.tab;
        state.reqStatus = '';
        renderDoctors();
    });
    let t;
    $('#docSearch').addEventListener('input', e => { clearTimeout(t); t = setTimeout(() => { state.docQ = e.target.value.trim(); renderDoctors(); }, 200); });
    $('#docChips').addEventListener('click', e => {
        const c = e.target.closest('[data-status]');
        if (c) { state.reqStatus = c.dataset.status; renderDoctors(); }
    });
    $('#addDoctorBtn').addEventListener('click', () => can('doctors.manage') ? openAddDoctor() : denied());
}

function lockedBtn(cls, act, id, label, perm = 'doctors.manage') {
    return can(perm)
        ? `<button class="btn ${cls} xs" data-act="${act}" data-id="${id}">${label}</button>`
        : `<button class="btn light xs locked" data-act="denied">${label.replace(/^[^\s]+\s/, '')}</button>`;
}

function renderDoctors() {
    $$('#docTabs button').forEach(b => b.classList.toggle('active', b.dataset.tab === state.docTab));
    $('#addDoctorBtn').classList.toggle('locked', !can('doctors.manage'));
    const q = normalize(state.docQ);
    const match = l => { const d = docInfo(l.doctorId); return !q || normalize(`${d.name} ${d.specialty} ${d.id}`).includes(q); };
    const wd = new Date().getDay();
    const grid = $('#docGrid');

    if (state.docTab === 'linked') {
        const list = activeLinks().filter(match);
        $('#docChips').innerHTML = `<span class="chip active">الأطباء المرتبطون <b>${activeLinks().length}</b></span>
            <span class="chip">على الدوام اليوم <b>${activeLinks().filter(l => l.shifts[wd]).length}</b></span>`;
        grid.innerHTML = list.length ? list.map((l, i) => {
            const d = docInfo(l.doctorId), s = shiftSummary(l.shifts);
            const todayCount = todayAppts().filter(a => a.doctorId === l.doctorId && a.status !== 'cancelled').length;
            const pend = Object.keys(l.pendingShifts || {}).length;
            return `
            <article class="doc-card" style="--i:${i}" data-card="${d.id}">
                <div class="dc-head">
                    <span class="pt-avatar">${docIcon(d)}</span>
                    <div>
                        <button class="link-btn" data-act="doc-view" data-id="${d.id}"><strong>${esc(d.name)}</strong></button>
                        <small>${d.id} · ${d.specialty} · ${d.exp} سنة خبرة</small>
                    </div>
                </div>
                <div class="hero-buttons">
                    <span class="badge success">مرتبط بالعيادة</span>
                    ${l.shifts[wd] ? '<span class="badge primary">على الدوام اليوم</span>' : ''}
                    ${pend ? `<span class="badge warning">${pend} تعديل دوام بانتظار الموافقة</span>` : ''}
                </div>
                <div class="dc-meta">
                    <div>أجر المعاينة بالعيادة<b>${fmtMoney(l.fee)}</b></div>
                    <div>مواعيد اليوم<b>${todayCount}</b></div>
                    <div>أيام الدوام<b>${s.days}</b></div>
                    <div>ساعات الدوام<b>${s.hours}</b></div>
                </div>
                <div class="dc-actions">
                    <button class="btn light xs" data-act="doc-schedule" data-id="${d.id}">🗓️ الجدول</button>
                    ${lockedBtn('teal', 'doc-fee', d.id, '💰 تعديل الأجر')}
                    ${lockedBtn('danger-light', 'doc-remove', d.id, '✕ إزالة الارتباط')}
                </div>
            </article>`;
        }).join('') : '<div class="empty-state" style="grid-column:1/-1"><div class="empty-icon">🩺</div><h3>لا يوجد أطباء مطابقون</h3></div>';
        return;
    }

    // طلبات الانضمام
    const reqs = D().links.filter(match).sort((a, b) => b.requestedAt - a.requestedAt);
    const chipDefs = [['', 'الكل'], ['pending', 'بانتظار الرد'], ['active', 'مقبول'], ['declined', 'مرفوض'], ['cancelled', 'ملغى'], ['removed', 'أُزيل']];
    $('#docChips').innerHTML = chipDefs.map(([k, l]) =>
        `<button class="chip ${state.reqStatus === k ? 'active' : ''}" data-status="${k}">${l} <b>${k ? reqs.filter(r => r.status === k).length : reqs.length}</b></button>`).join('');
    const list = reqs.filter(r => !state.reqStatus || r.status === state.reqStatus);

    grid.innerHTML = list.length ? list.map((l, i) => {
        const d = docInfo(l.doctorId), S = LINK_STATUS[l.status], s = shiftSummary(l.shifts);
        const steps = l.status === 'pending'
            ? '<span class="done">أُرسل الطلب</span><i></i><span class="now">قيد مراجعة الطبيب</span><i></i><span>القرار</span>'
            : l.status === 'active' || l.status === 'removed'
                ? '<span class="done">أُرسل الطلب</span><i></i><span class="done">راجعه الطبيب</span><i></i><span class="done">تم القبول</span>'
                : `<span class="done">أُرسل الطلب</span><i></i><span class="done">راجعه الطبيب</span><i></i><span class="bad">${l.status === 'cancelled' ? 'أُلغي' : 'مرفوض'}</span>`;
        let actions = '';
        if (l.status === 'pending') actions = lockedBtn('danger-light', 'req-cancel', d.id, '✕ إلغاء الطلب');
        if (['declined', 'cancelled', 'removed'].includes(l.status)) actions = lockedBtn('teal', 'req-resend', d.id, '↻ إرسال طلب جديد');
        return `
        <article class="doc-card ${l.status === 'pending' ? 'pending' : ''}" style="--i:${i}">
            ${l.status === 'pending' ? '<span class="ribbon">بانتظار الرد</span>' : ''}
            <div class="dc-head">
                <span class="pt-avatar">${docIcon(d)}</span>
                <div><strong>${esc(d.name)}</strong><small>${d.specialty} · أُرسل ${timeAgo(l.requestedAt)}</small></div>
            </div>
            <span class="badge ${S.cls}" style="align-self:flex-start">${S.label}</span>
            <div class="req-steps">${steps}</div>
            <div class="dc-meta">
                <div>الأجر المقترح<b>${fmtMoney(l.fee)}</b></div>
                <div>الدوام المقترح<b>${s.days}</b></div>
            </div>
            ${l.note ? `<small class="muted">📝 ${esc(l.note)}</small>` : ''}
            ${l.message ? `<small class="muted">✉️ ${esc(l.message)}</small>` : ''}
            ${actions ? `<div class="dc-actions">${actions}</div>` : ''}
        </article>`;
    }).join('') : '<div class="empty-state" style="grid-column:1/-1"><div class="empty-icon">📨</div><h3>لا توجد طلبات مطابقة</h3></div>';
}

function openDoctorDrawer(id) {
    const d = docInfo(id), l = getLink(id);
    if (!d || !l) return;
    const list = D().appts.filter(a => a.doctorId === id && a.date >= toISO(addDays(new Date(), -29)) && a.date <= todayISO());
    const upcoming = D().appts.filter(a => a.doctorId === id && a.date > todayISO() && a.status === 'confirmed').length;
    openDrawer(`
        <div class="drawer-head">
            <span class="pt-avatar">${docIcon(d)}</span>
            <div>
                <h2>${esc(d.name)}</h2>
                <span class="muted small">${d.id} · ${d.specialty} · ${d.exp} سنة خبرة</span><br>
                <span class="badge ${LINK_STATUS[l.status].cls}">${LINK_STATUS[l.status].label}</span>
            </div>
        </div>
        <p class="access-note">🔒 تعرض العيادة بيانات الدوام والمواعيد فقط، دون أي معلومات طبية للمرضى.</p>
        <div class="drawer-section">
            <h4>الارتباط بالعيادة</h4>
            <div class="detail-grid">
                <div><span>أجر المعاينة</span><b>${fmtMoney(l.fee)}</b></div>
                <div><span>تاريخ الانضمام</span><b>${l.respondedAt ? fmtDate(toISO(new Date(l.respondedAt))) : '—'}</b></div>
                <div><span>مواعيد قادمة</span><b>${upcoming}</b></div>
                <div><span>حالة الطابور اليوم</span><b>${queueStateOf(id).label}</b></div>
            </div>
        </div>
        <div class="drawer-section">
            <h4>الدوام الأسبوعي</h4>
            <div class="mini-list">
                ${ORDER.map(wd => `<div class="mini-item"><b style="min-width:70px">${DAY_NAMES[wd]}</b><div class="up-info">${l.shifts[wd] ? `${fmtTime(l.shifts[wd][0])} – ${fmtTime(l.shifts[wd][1])}` : '<small>لا يوجد دوام</small>'}</div>${l.pendingShifts[wd] ? '<span class="badge warning">تعديل بانتظار الموافقة</span>' : ''}</div>`).join('')}
            </div>
        </div>
        <div class="drawer-section">
            <h4>المواعيد · آخر 30 يوماً</h4>
            <div class="detail-grid">
                <div><span>الحجوزات</span><b>${list.length}</b></div>
                <div><span>المكتملة</span><b>${list.filter(a => a.status === 'completed').length}</b></div>
                <div><span>الملغاة</span><b>${list.filter(a => a.status === 'cancelled').length}</b></div>
                <div><span>لم يحضر</span><b>${list.filter(a => a.status === 'noshow').length}</b></div>
            </div>
        </div>
        ${l.status === 'active' ? `<div class="hero-buttons">
            <button class="btn light sm" data-act="doc-schedule" data-id="${id}">🗓️ تعديل الجدول</button>
            ${lockedBtn('teal', 'doc-fee', id, '💰 تعديل الأجر')}
            ${lockedBtn('danger-light', 'doc-remove', id, '✕ إزالة الارتباط')}
        </div>` : ''}`);
}

/* ---------- طلب إضافة طبيب ---------- */
function openAddDoctor(preselect = '') {
    const available = DIRECTORY.filter(d => { const l = getLink(d.id); return !l || !['active', 'pending'].includes(l.status); });
    const openDays = ORDER.filter(d => D().hours[d].open);
    openModal(`
        <h2 class="modal-title">📨 طلب إضافة طبيب للعيادة</h2>
        <p class="muted small">سيصل الطلب للطبيب ليوافق عليه أو يرفضه، ويمكنك متابعة حالته من «طلبات الانضمام».</p>
        <form id="addDocForm" novalidate>
            <div class="form-group mt">
                <label>اختر الطبيب <span class="req">*</span></label>
                <div class="search-wrap" style="flex:none">
                    <span class="search-icon">⌕</span>
                    <input type="text" class="field search" id="dirSearch" placeholder="ابحث في دليل أطباء النظام...">
                </div>
                <div class="dir-list" id="dirList">
                    ${available.map(d => `
                        <button type="button" class="dir-item ${d.id === preselect ? 'selected' : ''}" data-pick="${d.id}" data-search="${esc(normalize(d.name + ' ' + d.specialty))}">
                            <span class="pt-avatar">${docIcon(d)}</span>
                            <div class="up-info"><strong>${esc(d.name)}</strong><small>${d.specialty} · ${d.exp} سنة خبرة</small></div>
                            ${getLink(d.id) ? `<span class="badge ${LINK_STATUS[getLink(d.id).status].cls}">${LINK_STATUS[getLink(d.id).status].label}</span>` : ''}
                        </button>`).join('')}
                </div>
                <input type="hidden" name="doctor" value="${preselect}">
                <small class="error-text"></small>
            </div>
            <div class="form-group">
                <label>أجر المعاينة داخل العيادة (د.ع) <span class="req">*</span></label>
                <input type="number" class="field" name="fee" min="5000" max="200000" step="1000" value="25000">
                <small class="error-text"></small>
            </div>
            <div class="form-group">
                <label>أيام الدوام المقترحة <span class="req">*</span></label>
                <div class="day-pick">
                    ${ORDER.map(d => `<label class="${openDays.includes(d) ? '' : 'disabled'}"><input type="checkbox" name="days" value="${d}" ${openDays.includes(d) ? '' : 'disabled'}>${DAY_NAMES[d]}</label>`).join('')}
                </div>
                <small class="error-text"></small>
            </div>
            <div class="form-grid">
                <div class="form-group">
                    <label>من الساعة</label>
                    <input type="time" class="field" name="from" value="16:00">
                    <small class="error-text"></small>
                </div>
                <div class="form-group">
                    <label>إلى الساعة</label>
                    <input type="time" class="field" name="to" value="20:00">
                    <small class="error-text"></small>
                </div>
            </div>
            <div class="form-group">
                <label>رسالة للطبيب (اختياري)</label>
                <textarea class="field" name="message" rows="2" placeholder="مثال: يسعدنا انضمامك إلى فريق العيادة..."></textarea>
            </div>
            <div class="confirm-actions">
                <button type="button" class="btn light" data-close-modal>تراجع</button>
                <button type="submit" class="btn primary">📨 إرسال الطلب</button>
            </div>
        </form>`, 'wide');
}

function submitAddDoctor(form) {
    const el = form.elements;
    const docId = el.doctor.value;
    const fee = Number(el.fee.value);
    const days = $$('input[name=days]:checked', form).map(i => Number(i.value));
    const from = el.from.value, to = el.to.value;
    let ok = setError(el.doctor, docId ? '' : 'اختر طبيباً من القائمة');
    ok = setError(el.fee, !Number.isInteger(fee) || fee < 5000 || fee > 200000 ? 'الأجر يجب أن يكون بين 5,000 و 200,000 د.ع' : '') && ok;
    ok = setError($('.day-pick', form), days.length ? '' : 'اختر يوماً واحداً على الأقل') && ok;
    let timeErr = '';
    if (!from || !to) timeErr = 'حدد وقت البداية والنهاية';
    else if (from >= to) timeErr = 'وقت النهاية يجب أن يكون بعد البداية';
    else {
        const bad = days.find(d => from < D().hours[d].from || to > D().hours[d].to);
        if (bad !== undefined) timeErr = `الوقت خارج أوقات عمل العيادة يوم ${DAY_NAMES[bad]} (${fmtTime(D().hours[bad].from)} – ${fmtTime(D().hours[bad].to)})`;
    }
    ok = setError(el.to, timeErr) && ok;
    if (!ok) { shake(form); return; }

    setLoading($('[type=submit]', form), true);
    setTimeout(() => {
        const shifts = {};
        days.forEach(d => { shifts[d] = [from, to]; });
        let l = getLink(docId);
        const fresh = { doctorId: docId, status: 'pending', fee, shifts, pendingShifts: {}, requestedAt: Date.now(), respondedAt: null, note: '', message: el.message.value.trim() };
        if (l) Object.assign(l, fresh); else { l = fresh; D().links.push(l); }
        saveData();
        closeModal();
        state.docTab = 'requests'; state.reqStatus = '';
        if (state.page === 'doctors') renderDoctors(); else go('doctors');
        updateBadges();
        toast(`تم إرسال طلب الانضمام إلى ${docInfo(docId).name}`, 'success');
        simulateDoctorReply(docId);
    }, 800);
}

function simulateDoctorReply(docId) {
    const t = setTimeout(() => {
        const l = getLink(docId);
        if (!l || l.status !== 'pending') return;
        const d = docInfo(docId);
        if (Math.random() < 0.75) {
            l.status = 'active';
            l.respondedAt = Date.now();
            const used = D().links.map(x => x.letter).filter(Boolean);
            l.letter = 'ABCDEFGHIJKLMN'.split('').find(c => !used.includes(c));
            notify('✅', `وافق ${d.name} على الانضمام للعيادة`);
            toast(`🎉 وافق ${d.name} على طلب الانضمام`, 'success');
        } else {
            l.status = 'declined';
            l.respondedAt = Date.now();
            l.note = 'اعتذر الطبيب لعدم توفر وقت حالياً';
            notify('✕', `اعتذر ${d.name} عن طلب الانضمام`);
            toast(`اعتذر ${d.name} عن الانضمام`, 'warning');
        }
        saveData();
        if (['doctors', 'dashboard', 'schedule'].includes(state.page)) renderPage(); else updateBadges();
    }, 12000 + Math.random() * 8000);
    state.timers.push(t);
}

function openFeeModal(id) {
    const d = docInfo(id), l = getLink(id);
    openModal(`
        <div class="confirm">
            <div class="confirm-icon">💰</div>
            <h3>أجر ${esc(d.name)} داخل العيادة</h3>
            <p class="muted">الأجر الحالي: <b>${fmtMoney(l.fee)}</b></p>
        </div>
        <form id="feeForm" data-id="${id}" novalidate>
            <div class="form-group mt">
                <label>الأجر الجديد (د.ع) <span class="req">*</span></label>
                <input type="number" class="field" name="fee" min="5000" max="200000" step="1000" value="${l.fee}">
                <small class="muted">يُطبّق على الحجوزات الجديدة فقط، ولا يتغير أجر المواعيد المحجوزة مسبقاً.</small>
                <small class="error-text"></small>
            </div>
            <div class="presets">${[15000, 20000, 25000, 30000, 35000, 40000].map(v => `<button type="button" data-fee="${v}">${v.toLocaleString('en-US')}</button>`).join('')}</div>
            <div class="confirm-actions">
                <button type="button" class="btn light" data-close-modal>تراجع</button>
                <button type="submit" class="btn primary">💾 حفظ الأجر</button>
            </div>
        </form>`);
}

function submitFee(form) {
    const l = getLink(form.dataset.id), fee = Number(form.elements.fee.value);
    if (!setError(form.elements.fee, !Number.isInteger(fee) || fee < 5000 || fee > 200000 ? 'الأجر يجب أن يكون بين 5,000 و 200,000 د.ع' : (fee === l.fee ? 'الأجر الجديد مطابق للحالي' : ''))) { shake(form); return; }
    setLoading($('[type=submit]', form), true);
    setTimeout(() => {
        const old = l.fee;
        l.fee = fee;
        saveData();
        closeModal();
        renderPage();
        if ($('#drawer').classList.contains('open')) openDoctorDrawer(l.doctorId);
        toast(`تم تعديل الأجر: ${fmtMoney(old)} ← ${fmtMoney(fee)}`, 'success');
    }, 600);
}

function openRemoveModal(id) {
    const d = docInfo(id);
    const upcoming = D().appts.filter(a => a.doctorId === id && a.date >= todayISO() && a.status === 'confirmed');
    openModal(`
        <div class="confirm">
            <div class="confirm-icon danger">✕</div>
            <h3>إزالة ارتباط ${esc(d.name)} بالعيادة</h3>
            <p class="muted">لن يظهر الطبيب ضمن أطباء العيادة ولن تُقبل حجوزات جديدة له فيها.</p>
            <form id="removeForm" data-id="${id}" novalidate>
                <div class="form-group">
                    <div class="reason-list">${['انتهاء فترة التعاقد', 'بطلب من الطبيب', 'إعادة تنظيم الكادر', 'أخرى'].map(r => `<label><input type="radio" name="reason" value="${r}"> ${r}</label>`).join('')}</div>
                    <small class="error-text"></small>
                </div>
                <div class="form-group">
                    <textarea class="field" name="note" rows="2" placeholder="ملاحظة (مطلوبة عند اختيار «أخرى»)"></textarea>
                    <small class="error-text"></small>
                </div>
                ${upcoming.length ? `
                <div class="form-group">
                    <div class="alert-box danger">⚠️ لدى الطبيب <b>${upcoming.length}</b> مواعيد قادمة في العيادة، سيتم إلغاؤها وإبلاغ المرضى واسترداد المبالغ المدفوعة.</div>
                    <label class="check-wrap"><input type="checkbox" name="ack"><span class="check-box"></span> أفهم ذلك وأريد المتابعة</label>
                    <small class="error-text"></small>
                </div>` : ''}
                <div class="confirm-actions">
                    <button type="button" class="btn light" data-close-modal>تراجع</button>
                    <button type="submit" class="btn danger">تأكيد الإزالة</button>
                </div>
            </form>
        </div>`);
}

function submitRemove(form) {
    const id = form.dataset.id, el = form.elements;
    const reason = el.reason.value, note = el.note.value.trim();
    let ok = setError($('.reason-list', form), reason ? '' : 'اختر سبب الإزالة');
    ok = setError(el.note, reason === 'أخرى' && note.length < 3 ? 'اكتب السبب' : '') && ok;
    if (el.ack) ok = setError(el.ack, el.ack.checked ? '' : 'يجب التأكيد للمتابعة') && ok;
    if (!ok) { shake(form); return; }

    setLoading($('[type=submit]', form), true);
    setTimeout(() => {
        const l = getLink(id);
        l.status = 'removed';
        l.respondedAt = Date.now();
        l.note = reason === 'أخرى' ? note : reason + (note ? ` — ${note}` : '');
        l.oldShifts = l.shifts; l.shifts = {}; l.pendingShifts = {};
        let n = 0;
        D().appts.filter(a => a.doctorId === id && a.date >= todayISO() && a.status === 'confirmed').forEach(a => {
            a.status = 'cancelled'; a.cancelledBy = 'العيادة'; a.cancelReason = 'إزالة الطبيب من العيادة'; a.cancelledAt = Date.now();
            if (a.payment && a.payment.status === 'paid') a.payment.status = 'refunded';
            n++;
        });
        saveData();
        closeModal(); closeDrawer();
        renderPage();
        notify('✕', `أُزيل ارتباط ${docInfo(id).name} بالعيادة${n ? ` وأُلغي ${n} موعد` : ''}`);
        toast('تمت إزالة الارتباط', 'success');
    }, 700);
}


/* =================== 27. مواعيد العيادة =================== */
function bindAppointments() {
    const f = state.apptFilter;
    const reset = () => { state.pages.appt = 1; renderApptTable(); };
    $('#apptTabs').addEventListener('click', e => {
        const b = e.target.closest('[data-view]');
        if (b) { state.apptView = b.dataset.view; renderApptView(); }
    });
    let t;
    $('#apptSearch').addEventListener('input', e => { clearTimeout(t); t = setTimeout(() => { f.q = e.target.value.trim(); reset(); }, 200); });
    $('#apptDoctor').addEventListener('change', e => { f.doctor = e.target.value; reset(); });
    $('#apptDate').addEventListener('change', e => { f.date = e.target.value; reset(); });
    $('#datePrev').addEventListener('click', () => { f.date = toISO(addDays(parseISO(f.date || todayISO()), -1)); reset(); });
    $('#dateNext').addEventListener('click', () => { f.date = toISO(addDays(parseISO(f.date || todayISO()), 1)); reset(); });
    $('#dateToday').addEventListener('click', () => { f.date = todayISO(); reset(); });
    $('#apptChips').addEventListener('click', e => {
        const c = e.target.closest('[data-status]');
        if (c) { f.status = c.dataset.status; reset(); }
    });
    $('#feedSeg').addEventListener('click', e => {
        const b = e.target.closest('[data-feed]');
        if (!b) return;
        state.feedFilter.type = b.dataset.feed;
        renderFeed();
    });
    $('#feedPeriod').addEventListener('change', e => { state.feedFilter.days = Number(e.target.value); renderFeed(); });
}

function renderApptView() {
    $$('#apptTabs button').forEach(b => b.classList.toggle('active', b.dataset.view === state.apptView));
    $('#view-table').hidden = state.apptView !== 'table';
    $('#view-feed').hidden = state.apptView !== 'feed';
    if (state.apptView === 'table') renderApptTable(); else renderFeed();
}

function renderApptTable() {
    const f = state.apptFilter;
    const docs = D().links.filter(l => ['active', 'removed'].includes(l.status));
    $('#apptDoctor').innerHTML = '<option value="">جميع الأطباء</option>' + docs.map(l => `<option value="${l.doctorId}">${docInfo(l.doctorId).name}${l.status === 'removed' ? ' (سابق)' : ''}</option>`).join('');
    $('#apptDoctor').value = f.doctor;
    $('#apptDate').value = f.date;
    $('#apptSearch').value = f.q;

    const base = D().appts.filter(a => (!f.date || a.date === f.date) && (!f.doctor || a.doctorId === f.doctor));
    $('#apptChips').innerHTML = `<span class="muted small" style="align-self:center">📅 ${f.date ? fmtDate(f.date, { weekday: 'long', day: 'numeric', month: 'long' }) : 'كل التواريخ'}${isHoliday(f.date) ? ' · 🏖️ عطلة' : ''}</span>` +
        [['', 'الكل', base.length], ...Object.entries(APPT_STATUS).map(([k, s]) => [k, s.label, base.filter(a => a.status === k).length])]
            .filter(([k, , n]) => !k || n)
            .map(([k, l, n]) => `<button class="chip ${f.status === k ? 'active' : ''}" data-status="${k}">${l} <b>${n}</b></button>`).join('');

    const q = normalize(f.q);
    const list = base
        .filter(a => !f.status || a.status === f.status)
        .filter(a => !q || normalize(`${a.id} ${patientOf(a.patientId).name} ${a.queueNo}`).includes(q))
        .sort((a, b) => byTime(a, b) || a.doctorId.localeCompare(b.doctorId));

    const pg = paginate(list, 'appt', 10);
    $('#apptList').innerHTML = pg.rows.length ? pg.rows.map((a, i) => {
        const p = patientOf(a.patientId), d = docInfo(a.doctorId), st = APPT_STATUS[a.status];
        const ps = a.payment ? PAY_STATUS[a.payment.status] : null;
        return `
        <tr style="--i:${i}">
            <td><b>${a.id}</b></td>
            <td>${esc(p.name)}<br><small class="muted" dir="ltr">${p.phone}</small></td>
            <td><button class="link-btn" data-act="doc-view" data-id="${d.id}">${esc(d.name)}</button><br><small class="muted">${d.specialty}</small></td>
            <td>${fmtTime(a.time)}</td>
            <td><span class="q-no">${a.queueNo}</span></td>
            <td>${ps ? `<span class="badge ${ps.cls}">${ps.label}</span><br><small class="muted">${fmtMoney(a.fee)}</small>` : '<span class="muted small">—</span>'}</td>
            <td><span class="badge ${st.cls}">${st.label}</span>${a.status === 'cancelled' ? `<br><small class="muted">بواسطة ${a.cancelledBy}</small>` : ''}</td>
            <td><small>${timeAgo(a.bookedAt)}</small></td>
        </tr>`;
    }).join('') : '<tr class="table-empty"><td colspan="8"><div class="empty-state"><div class="empty-icon">🗓️</div><h3>لا توجد مواعيد مطابقة</h3><p>غيّر الطبيب أو التاريخ.</p></div></td></tr>';
    renderPager($('#apptPager'), 'appt', pg);
}

function renderFeed() {
    const f = state.feedFilter;
    $$('#feedSeg button').forEach(b => b.classList.toggle('active', b.dataset.feed === f.type));
    const since = Date.now() - f.days * 86400000;
    const events = [];
    D().appts.forEach(a => {
        if (a.bookedAt >= since) events.push({ type: 'book', at: a.bookedAt, a });
        if (a.cancelledAt && a.cancelledAt >= since) events.push({ type: 'cancel', at: a.cancelledAt, a });
    });
    events.sort((x, y) => y.at - x.at);
    const books = events.filter(e => e.type === 'book').length, cancels = events.filter(e => e.type === 'cancel');
    $('#feedStats').innerHTML = [
        { icon: '📅', label: 'حجوزات جديدة', value: books, sub: `خلال آخر ${f.days === 2 ? '48 ساعة' : '7 أيام'}`, color: '#1463ff' },
        { icon: '⊘', label: 'إلغاءات', value: cancels.length, sub: `${books ? Math.round((cancels.length / books) * 100) : 0}% من الحجوزات`, color: '#e5484d' },
        { icon: '🧑', label: 'ألغاها المرضى', value: cancels.filter(e => e.a.cancelledBy === 'المريض').length, sub: 'ضمن مهلة الإلغاء', color: '#f59e0b' },
        { icon: '🏥', label: 'ألغاها الطبيب/العيادة', value: cancels.filter(e => e.a.cancelledBy !== 'المريض').length, sub: 'مع إبلاغ المريض', color: '#7c3aed' }
    ].map(statCard).join('');
    animateCounts($('#feedStats'));

    const list = events.filter(e => !f.type || e.type === f.type).slice(0, 40);
    $('#feedList').innerHTML = list.length ? list.map((e, i) => {
        const a = e.a, p = patientOf(a.patientId), d = docInfo(a.doctorId);
        return e.type === 'book' ? `
            <div class="feed-item" style="--i:${Math.min(i, 12)}">
                <span class="feed-icon book">📅</span>
                <div class="up-info"><strong>حجز جديد · ${esc(p.name)}</strong><small>مع ${esc(d.name)} · ${relDay(a.date)} ${fmtTime(a.time)} · ${a.id}</small></div>
                <small class="muted">${timeAgo(e.at)}</small>
            </div>` : `
            <div class="feed-item" style="--i:${Math.min(i, 12)}">
                <span class="feed-icon cancel">⊘</span>
                <div class="up-info"><strong>إلغاء بواسطة ${a.cancelledBy} · ${esc(p.name)}</strong><small>${esc(d.name)} · ${relDay(a.date)} ${fmtTime(a.time)} · السبب: ${esc(a.cancelReason)}</small></div>
                <small class="muted">${timeAgo(e.at)}</small>
            </div>`;
    }).join('') : '<div class="empty-state"><div class="empty-icon">🔄</div><h3>لا توجد حركة في هذه الفترة</h3></div>';
}


/* =================== 28. إدارة الدوام =================== */
function bindSchedule() {
    const list = $('#hoursList');
    list.addEventListener('change', e => {
        const row = e.target.closest('[data-day]');
        if (!row) return;
        const wd = Number(row.dataset.day), dft = state.hoursDraft[wd];
        if (e.target.type === 'checkbox') { dft.open = e.target.checked; row.classList.toggle('off', !dft.open); }
        if (e.target.dataset.f) dft[e.target.dataset.f] = e.target.value;
        validateHours();
        updateHoursStatus();
    });
    $('#recBefore').addEventListener('change', updateHoursStatus);
    $('#recLast').addEventListener('change', updateHoursStatus);
    $('#hoursForm').addEventListener('submit', saveHours);

    $('#holidayForm').addEventListener('submit', addHoliday);
    $('#holidayForm').addEventListener('input', e => setError(e.target, ''));
    $('#holidayList').addEventListener('click', e => {
        const b = e.target.closest('[data-del-hol]');
        if (b) removeHoliday(b.dataset.delHol);
    });

    $('#schedTable').addEventListener('click', e => {
        const c = e.target.closest('[data-cell]');
        if (!c || c.classList.contains('closed')) return;
        if (!can('schedule.edit')) { denied(); return; }
        const [docId, wd] = c.dataset.cell.split('|');
        openShiftModal(docId, Number(wd));
    });
}

function hoursChanged() {
    const h = D().hours, d = state.hoursDraft;
    return ORDER.some(wd => h[wd].open !== d[wd].open || h[wd].from !== d[wd].from || h[wd].to !== d[wd].to)
        || Number($('#recBefore').value) !== D().reception.before || Number($('#recLast').value) !== D().reception.last;
}

function validateHours() {
    let ok = true;
    $$('#hoursList [data-day]').forEach(row => {
        const d = state.hoursDraft[row.dataset.day];
        const bad = d.open && (!d.from || !d.to || d.from >= d.to);
        row.classList.toggle('has-error', bad);
        $('.hours-err', row).textContent = bad ? 'وقت الإغلاق يجب أن يكون بعد الفتح' : '';
        if (bad) ok = false;
    });
    return ok;
}

function updateHoursStatus() {
    const changed = hoursChanged();
    $('#hoursChanged').textContent = changed ? '⚠️ تغييرات غير محفوظة' : 'لا توجد تغييرات';
    $('#hoursChanged').style.color = changed ? 'var(--warning)' : '';
    $('#hoursSave').disabled = !changed || !can('schedule.edit');
}

function renderSchedule() {
    const editable = can('schedule.edit');
    if (!state.hoursDraft) state.hoursDraft = JSON.parse(JSON.stringify(D().hours));
    const up = D().hoursUpdated;
    $('#hoursMeta').textContent = up ? `آخر تحديث: ${up.by} · ${timeAgo(up.at)}` : '';

    $('#hoursList').innerHTML = ORDER.map((wd, i) => {
        const d = state.hoursDraft[wd];
        return `
        <div class="hours-row card-anim ${d.open ? '' : 'off'}" data-day="${wd}" style="--i:${i}">
            <b>${DAY_NAMES[wd]}</b>
            <label class="switch" title="${d.open ? 'مفتوح' : 'مغلق'}">
                <input type="checkbox" ${d.open ? 'checked' : ''} ${editable ? '' : 'disabled'}>
                <span class="slider"></span>
            </label>
            <div class="hours-times">
                <input type="time" class="field" data-f="from" value="${d.from}" ${editable ? '' : 'disabled'}>
                <span class="muted">إلى</span>
                <input type="time" class="field" data-f="to" value="${d.to}" ${editable ? '' : 'disabled'}>
                <small class="error-text hours-err"></small>
            </div>
        </div>`;
    }).join('');
    $('#recBefore').value = D().reception.before;
    $('#recLast').value = D().reception.last;
    $('#recBefore').disabled = $('#recLast').disabled = !editable;
    $('#hoursSave').classList.toggle('locked', !editable);
    $('#holAdd').classList.toggle('locked', !editable);
    $('#holDate').min = todayISO();
    validateHours();
    updateHoursStatus();
    renderHolidays();
    renderSchedTable();
}

async function saveHours(e) {
    e.preventDefault();
    if (!can('schedule.edit')) { denied(); return; }
    if (!validateHours()) { shake($('#hoursForm')); toast('صحّح أوقات العمل غير الصحيحة', 'error'); return; }
    if (!hoursChanged()) return;

    const d = state.hoursDraft;
    const conflicts = [];
    activeLinks().forEach(l => ORDER.forEach(wd => {
        const s = l.shifts[wd];
        if (s && (!d[wd].open || s[0] < d[wd].from || s[1] > d[wd].to)) conflicts.push(`${docInfo(l.doctorId).name} (${DAY_NAMES[wd]})`);
    }));
    const ok = await confirmDialog({
        title: 'حفظ أوقات عمل العيادة؟',
        text: conflicts.length
            ? `⚠️ يوجد ${conflicts.length} دوام أطباء خارج الأوقات الجديدة:<br><small>${conflicts.map(esc).join('، ')}</small><br>ستحتاج لتنسيق جداولهم بعد الحفظ.`
            : 'سيتم تطبيق الأوقات الجديدة على الحجوزات القادمة.',
        ok: '💾 حفظ', icon: '🕘'
    });
    if (!ok) return;
    const btn = $('#hoursSave');
    setLoading(btn, true);
    setTimeout(() => {
        D().hours = JSON.parse(JSON.stringify(d));
        D().reception = { before: Number($('#recBefore').value), last: Number($('#recLast').value) };
        D().hoursUpdated = { by: state.session.name, at: Date.now() };
        saveData();
        setLoading(btn, false);
        renderSchedule();
        toast('تم حفظ أوقات العمل وساعات الاستقبال', 'success');
        if (conflicts.length) toast(`نسّق جداول ${conflicts.length} دوام خارج الأوقات الجديدة`, 'warning');
    }, 700);
}

function renderHolidays() {
    const list = [...D().holidays].sort((a, b) => a.date.localeCompare(b.date));
    $('#holidayList').innerHTML = list.length ? list.map((h, i) => {
        const past = h.date < todayISO();
        return `
        <div class="holiday-item ${past ? 'past' : ''}" style="--i:${i}">
            <span>🏖️</span>
            <div class="up-info"><strong>${esc(h.name)}</strong><small>${fmtDate(h.date, { weekday: 'long', day: 'numeric', month: 'long' })} · ${past ? 'انتهت' : relDay(h.date)}</small></div>
            ${!past && can('schedule.edit') ? `<button class="icon-btn sm" data-del-hol="${h.id}" title="حذف">✕</button>` : ''}
        </div>`;
    }).join('') : '<p class="muted">لا توجد عطل مسجلة.</p>';
}

async function addHoliday(e) {
    e.preventDefault();
    if (!can('schedule.edit')) { denied(); return; }
    const date = $('#holDate').value, name = $('#holName').value.trim();
    let ok = setError($('#holDate'), !date ? 'اختر التاريخ' : date < todayISO() ? 'لا يمكن إضافة عطلة بتاريخ سابق' : isHoliday(date) ? 'هذا اليوم مسجل كعطلة مسبقاً' : '');
    ok = setError($('#holName'), name.length < 3 ? 'اكتب سبب العطلة' : '') && ok;
    if (!ok) { shake($('#holidayForm')); return; }

    const affected = D().appts.filter(a => a.date === date && a.status === 'confirmed');
    if (affected.length) {
        const go_ = await confirmDialog({
            title: 'يوجد مواعيد في هذا اليوم',
            text: `لدى العيادة ${affected.length} مواعيد محجوزة يوم ${fmtDate(date, { weekday: 'long', day: 'numeric', month: 'long' })}. سيتم إلغاؤها وإبلاغ المرضى.`,
            ok: 'إضافة العطلة وإلغاء المواعيد', danger: true, icon: '🏖️'
        });
        if (!go_) return;
    }
    affected.forEach(a => {
        a.status = 'cancelled'; a.cancelledBy = 'العيادة'; a.cancelReason = `عطلة: ${name}`; a.cancelledAt = Date.now();
        if (a.payment && a.payment.status === 'paid') a.payment.status = 'refunded';
    });
    D().holidays.push({ id: 'H-' + Date.now(), date, name });
    saveData();
    $('#holidayForm').reset();
    renderHolidays();
    renderSchedTable();
    toast(`أُضيفت العطلة${affected.length ? ` وأُلغي ${affected.length} موعد` : ''}`, 'success');
}

async function removeHoliday(id) {
    const h = D().holidays.find(x => x.id === id);
    const ok = await confirmDialog({ title: 'حذف العطلة؟', text: `ستعود العيادة للعمل يوم ${fmtDate(h.date, { weekday: 'long', day: 'numeric', month: 'long' })} حسب الدوام المعتاد.`, ok: 'حذف', danger: true, icon: '🗑️' });
    if (!ok) return;
    D().holidays = D().holidays.filter(x => x.id !== id);
    saveData();
    renderHolidays();
    toast('تم حذف العطلة', 'success');
}

function renderSchedTable() {
    const links = activeLinks();
    const hours = D().hours;
    $('#schedTable').innerHTML = `
        <thead><tr><th style="text-align:right">الطبيب</th>${ORDER.map(wd => `<th class="${hours[wd].open ? '' : 'closed'}">${DAY_NAMES[wd]}${hours[wd].open ? '' : '<br><small>مغلق</small>'}</th>`).join('')}</tr></thead>
        <tbody>
            ${links.map(l => {
                const d = docInfo(l.doctorId);
                return `<tr><td><div class="sched-doc"><span class="pt-avatar">${docIcon(d)}</span>${esc(d.name)}</div></td>
                ${ORDER.map(wd => {
                    if (!hours[wd].open) return '<td><div class="shift closed">—</div></td>';
                    const p = l.pendingShifts[wd], s = l.shifts[wd];
                    if (p) return `<td><button class="shift pending" data-cell="${l.doctorId}|${wd}">${p.off ? 'إلغاء الدوام' : `${fmtTime(p.from)}<br>${fmtTime(p.to)}`}<small>⏳ بانتظار الطبيب</small></button></td>`;
                    if (s) {
                        const out = s[0] < hours[wd].from || s[1] > hours[wd].to;
                        return `<td><button class="shift" data-cell="${l.doctorId}|${wd}" ${out ? 'style="border-color:var(--danger)"' : ''}>${fmtTime(s[0])}<br>${fmtTime(s[1])}${out ? '<small style="color:var(--danger)">خارج أوقات العيادة</small>' : ''}</button></td>`;
                    }
                    return `<td><button class="shift empty" data-cell="${l.doctorId}|${wd}">${can('schedule.edit') ? '+ إضافة' : '—'}</button></td>`;
                }).join('')}</tr>`;
            }).join('')}
        </tbody>`;
}

function openShiftModal(docId, wd) {
    const d = docInfo(docId), l = getLink(docId), h = D().hours[wd];
    const s = l.shifts[wd];
    openModal(`
        <h2 class="modal-title">🗓️ دوام ${esc(d.name)} · ${DAY_NAMES[wd]}</h2>
        <p class="muted small">أوقات العيادة هذا اليوم: ${fmtTime(h.from)} – ${fmtTime(h.to)}. أي تعديل يُرسل للطبيب للموافقة عليه قبل اعتماده.</p>
        <form id="shiftForm" data-doc="${docId}" data-day="${wd}" novalidate>
            <div class="form-group mt">
                <label class="check-wrap"><input type="checkbox" name="works" ${s || !l.shifts[wd] ? 'checked' : ''}><span class="check-box"></span> يداوم الطبيب في هذا اليوم</label>
            </div>
            <div class="form-grid" id="shiftTimes">
                <div class="form-group">
                    <label>من الساعة</label>
                    <input type="time" class="field" name="from" value="${s ? s[0] : h.from}">
                </div>
                <div class="form-group">
                    <label>إلى الساعة</label>
                    <input type="time" class="field" name="to" value="${s ? s[1] : (h.to < '20:00' ? h.to : '20:00')}">
                    <small class="error-text"></small>
                </div>
            </div>
            ${l.pendingShifts[wd] ? '<div class="alert-box note">⏳ يوجد تعديل سابق بانتظار موافقة الطبيب وسيُستبدل بهذا التعديل.</div>' : ''}
            <div class="confirm-actions">
                <button type="button" class="btn light" data-close-modal>تراجع</button>
                <button type="submit" class="btn primary">📨 إرسال للطبيب</button>
            </div>
        </form>`);
}

function submitShift(form) {
    const docId = form.dataset.doc, wd = Number(form.dataset.day), el = form.elements;
    const l = getLink(docId), h = D().hours[wd];
    const works = el.works.checked, from = el.from.value, to = el.to.value;
    if (works) {
        let msg = '';
        if (!from || !to) msg = 'حدد الوقت';
        else if (from >= to) msg = 'وقت النهاية يجب أن يكون بعد البداية';
        else if (from < h.from || to > h.to) msg = `يجب أن يكون الدوام ضمن أوقات العيادة (${fmtTime(h.from)} – ${fmtTime(h.to)})`;
        else if (l.shifts[wd] && l.shifts[wd][0] === from && l.shifts[wd][1] === to) msg = 'لم يتغير الدوام';
        if (!setError(el.to, msg)) { shake(form); return; }
    } else if (!l.shifts[wd]) {
        setError(el.to, 'الطبيب لا يداوم أصلاً في هذا اليوم'); shake(form); return;
    }

    setLoading($('[type=submit]', form), true);
    setTimeout(() => {
        l.pendingShifts[wd] = works ? { from, to } : { off: true };
        saveData();
        closeModal();
        renderSchedTable();
        updateBadges();
        const cell = $(`[data-cell="${docId}|${wd}"]`);
        if (cell) cell.classList.add('flash');
        toast(`📨 أُرسل التعديل إلى ${docInfo(docId).name} للموافقة`, 'info');
        simulateShiftReply(docId, wd);
    }, 600);
}

function simulateShiftReply(docId, wd) {
    const t = setTimeout(() => {
        const l = getLink(docId);
        if (!l || !l.pendingShifts[wd]) return;
        const p = l.pendingShifts[wd], d = docInfo(docId);
        delete l.pendingShifts[wd];
        if (Math.random() < 0.85) {
            if (p.off) delete l.shifts[wd]; else l.shifts[wd] = [p.from, p.to];
            notify('✅', `وافق ${d.name} على تعديل دوام ${DAY_NAMES[wd]}`);
            toast(`✅ وافق ${d.name} على دوام ${DAY_NAMES[wd]}`, 'success');
        } else {
            notify('✕', `اعتذر ${d.name} عن تعديل دوام ${DAY_NAMES[wd]}`);
            toast(`اعتذر ${d.name} عن تعديل دوام ${DAY_NAMES[wd]}`, 'warning');
        }
        saveData();
        if (state.page === 'schedule') renderSchedTable();
        updateBadges();
    }, 7000 + Math.random() * 5000);
    state.timers.push(t);
}


/* =================== 29. الطوابير =================== */
function renderQueue() {
    const t = todayAppts();
    const docs = D().links.filter(l => l.status === 'active' && t.some(a => a.doctorId === l.doctorId));
    const states = docs.map(l => queueStateOf(l.doctorId));
    const waiting = t.filter(a => a.status === 'waiting');
    $('#queueUpdated').textContent = `آخر تحديث: ${timeAgo(state.lastQueueUpdate)}`;

    $('#queueStats').innerHTML = [
        { icon: '🎫', label: 'طوابير نشطة', value: states.filter(s => s.key === 'active').length, sub: `من ${docs.length} طوابير اليوم`, color: '#12b5a5' },
        { icon: '⏳', label: 'المرضى المنتظرون', value: waiting.length, sub: 'في جميع الطوابير', color: '#f59e0b' },
        { icon: '🩺', label: 'داخل الاستشارة', value: t.filter(a => a.status === 'in').length, sub: 'الآن', color: '#7c3aed' },
        { icon: '⏸', label: 'طوابير متوقفة', value: states.filter(s => s.key === 'paused').length, sub: 'استراحة مؤقتة', color: '#94a3b8' }
    ].map(statCard).join('');
    animateCounts($('#queueStats'));

    $('#queueBoard').innerHTML = docs.length ? docs.map((l, i) => {
        const d = docInfo(l.doctorId), q = queueStateOf(l.doctorId);
        const list = t.filter(a => a.doctorId === l.doctorId && a.status !== 'cancelled');
        const cur = list.find(a => a.status === 'in');
        const wait = list.filter(a => a.status === 'waiting').sort((a, b) => a.queueNo.localeCompare(b.queueNo));
        const done = list.filter(a => ['completed', 'noshow'].includes(a.status)).length;
        const notArrived = list.filter(a => a.status === 'confirmed').length;
        return `
        <div class="q-tile ${q.key === 'paused' ? 'paused' : ''}" style="--i:${i}">
            <div class="q-tile-head">
                <span class="pt-avatar">${docIcon(d)}</span>
                <div style="flex:1"><strong>${esc(d.name)}</strong><small>${d.specialty}${l.shifts[new Date().getDay()] ? ` · ${fmtTime(l.shifts[new Date().getDay()][0])} – ${fmtTime(l.shifts[new Date().getDay()][1])}` : ''}</small></div>
                <span class="badge ${q.cls}">${q.label}</span>
            </div>
            <div class="q-now ${cur ? '' : 'idle'}">
                <div><small>${q.key === 'paused' ? 'الطابور متوقف مؤقتاً' : cur ? 'داخل الاستشارة الآن' : 'لا يوجد مريض حالياً'}</small><b>${cur ? cur.queueNo : '—'}</b></div>
                ${cur && q.key !== 'paused' ? '<span class="badge purple live" style="background:rgba(255,255,255,.2);color:#fff">مباشر</span>' : ''}
            </div>
            <div class="q-stats">
                <div><b>${wait.length}</b>في الانتظار</div>
                <div><b>${done}</b>انتهى</div>
                <div><b>${notArrived}</b>لم يصلوا</div>
            </div>
            <div class="q-waitlist">
                ${wait.length ? wait.map((w, k) => `<div style="animation-delay:${k * 40}ms"><b>${w.queueNo}</b><span>${esc(patientOf(w.patientId).name)}</span><small class="muted">~${(k + (cur ? 1 : 0)) * 15} د</small></div>`).join('') : '<small class="muted">لا يوجد منتظرون</small>'}
            </div>
            <div class="q-progress"><i style="width:${list.length ? (done / list.length) * 100 : 0}%"></i></div>
        </div>`;
    }).join('') : '<div class="empty-state" style="grid-column:1/-1"><div class="empty-icon">🎫</div><h3>لا توجد طوابير اليوم</h3><p>لا يوجد أطباء على الدوام أو لا توجد مواعيد.</p></div>';
}

function tickQueues() {
    const t = todayAppts().filter(a => a.status !== 'cancelled');
    const ids = [...new Set(t.map(a => a.doctorId))].filter(id => getLink(id) && getLink(id).status === 'active');
    if (!ids.length) return;

    // استئناف الطوابير المتوقفة أحياناً
    Object.keys(D().queuePaused).forEach(id => {
        if (Math.random() < 0.3) {
            delete D().queuePaused[id];
            notify('▶', `استُؤنف طابور ${docInfo(id).name}`);
        }
    });

    const id = ids[Math.floor(Math.random() * ids.length)];
    if (D().queuePaused[id]) { saveData(); return; }
    const list = t.filter(a => a.doctorId === id);
    const cur = list.find(a => a.status === 'in');
    const next = list.filter(a => a.status === 'waiting').sort((a, b) => a.queueNo.localeCompare(b.queueNo))[0];
    const arriving = list.filter(a => a.status === 'confirmed').sort(byTime)[0];
    if (cur) {
        cur.status = 'completed';
        if (cur.payment && cur.payment.status === 'pending') cur.payment.status = 'paid';
    }
    if (next) next.status = 'in';
    if (arriving && Math.random() < 0.6) { arriving.status = 'waiting'; arriving.arrivedAt = Date.now(); }
    state.lastQueueUpdate = Date.now();
    saveData();
    if (['queue', 'dashboard'].includes(state.page)) renderPage(); else updateBadges();
}

function simulateBooking() {
    const links = activeLinks();
    if (!links.length) return;
    const l = links[Math.floor(Math.random() * links.length)];
    const futureDays = [1, 2, 3, 4, 5, 6].map(n => addDays(new Date(), n)).filter(d => l.shifts[d.getDay()] && D().hours[d.getDay()].open && !isHoliday(toISO(d)));
    if (!futureDays.length) return;
    const day = futureDays[Math.floor(Math.random() * futureDays.length)];
    const iso = toISO(day);
    const taken = D().appts.filter(a => a.doctorId === l.doctorId && a.date === iso).map(a => a.time);
    const free = slotsBetween(...l.shifts[day.getDay()]).filter(s => !taken.includes(s));
    if (!free.length) return;
    const p = D().patients[Math.floor(Math.random() * D().patients.length)];
    const method = ['cash', 'card', 'wallet'][Math.floor(Math.random() * 3)];
    const maxId = Math.max(...D().appts.map(a => Number(a.id.split('-')[1])));
    const count = D().appts.filter(a => a.doctorId === l.doctorId && a.date === iso).length;
    D().appts.push({
        id: `SC-${maxId + 7}`, doctorId: l.doctorId, patientId: p.id, date: iso, time: free[0],
        queueNo: `${l.letter}-${pad(count + 1)}`, status: 'confirmed', fee: l.fee,
        payment: { method, status: method === 'cash' ? 'pending' : 'paid', amount: l.fee }, bookedAt: Date.now()
    });
    saveData();
    notify('📅', `حجز جديد: ${p.name} مع ${docInfo(l.doctorId).name} (${relDay(iso)})`);
    if (state.page === 'appointments') renderApptView();
    if (state.page === 'dashboard') renderDashboard();
}


/* =================== 30. التقارير =================== */
function reportRange() {
    const t = todayISO(), r = state.report;
    if (r.period === '7') return [toISO(addDays(new Date(), -6)), t];
    if (r.period === '30') return [toISO(addDays(new Date(), -29)), t];
    if (r.period === 'month') { const n = new Date(); return [toISO(new Date(n.getFullYear(), n.getMonth(), 1)), t]; }
    return [r.from, r.to];
}

function bindReports() {
    $('#periodSeg').addEventListener('click', e => {
        const b = e.target.closest('[data-period]');
        if (!b) return;
        state.report.period = b.dataset.period;
        if (b.dataset.period === 'custom' && !state.report.from) {
            state.report.from = toISO(addDays(new Date(), -13));
            state.report.to = todayISO();
        }
        renderReports();
    });
    const onRange = () => {
        const f = $('#rangeFrom').value, t = $('#rangeTo').value;
        if (!f || !t) return;
        if (f > t) {
            toast('تاريخ البداية يجب أن يكون قبل تاريخ النهاية', 'error');
            shake($('#customRange'));
            $('#rangeFrom').value = state.report.from; $('#rangeTo').value = state.report.to;
            return;
        }
        state.report.from = f; state.report.to = t;
        renderReports();
    };
    $('#rangeFrom').addEventListener('change', onRange);
    $('#rangeTo').addEventListener('change', onRange);
    $('#exportCsv').addEventListener('click', exportReport);
}

function perfRows(list) {
    const ids = [...new Set(list.map(a => a.doctorId))];
    return ids.map(id => {
        const mine = list.filter(a => a.doctorId === id);
        const completed = mine.filter(a => a.status === 'completed').length;
        const closed = mine.filter(a => ['completed', 'cancelled', 'noshow'].includes(a.status)).length;
        return {
            id, d: docInfo(id), link: getLink(id),
            total: mine.length, completed,
            cancelled: mine.filter(a => a.status === 'cancelled').length,
            noshow: mine.filter(a => a.status === 'noshow').length,
            rate: closed ? Math.round((completed / closed) * 100) : 0,
            revenue: mine.filter(a => a.payment && a.payment.status === 'paid').reduce((s, a) => s + a.payment.amount, 0)
        };
    }).sort((a, b) => b.completed - a.completed);
}

function renderReports() {
    const locked = !can('reports.view');
    $('#reportsLocked').hidden = !locked;
    $('#reportsBody').hidden = locked;
    if (locked) {
        $('#reportsLocked').innerHTML = `
            <div class="lock-card">
                <div class="big">🔒</div>
                <h3>غير مصرح لك بعرض التقارير</h3>
                <p>التقارير والإيرادات متاحة لـ «مدير العيادة» فقط. حسابك الحالي: ${ROLE_INFO[state.session.role].label}.</p>
                <div class="hero-buttons" style="justify-content:center;margin-top:16px">
                    <button class="btn light" data-go="dashboard">العودة للرئيسية</button>
                    <button class="btn primary" data-act="account">عرض صلاحياتي</button>
                </div>
            </div>`;
        return;
    }

    const r = state.report;
    $$('#periodSeg button').forEach(b => b.classList.toggle('active', b.dataset.period === r.period));
    $('#customRange').hidden = r.period !== 'custom';
    $('#rangeFrom').value = r.from; $('#rangeTo').value = r.to;
    $('#rangeFrom').max = $('#rangeTo').max = todayISO();

    const [from, to] = reportRange();
    const fmt = { day: 'numeric', month: 'long', year: 'numeric' };
    $('#periodLabel').textContent = `📅 الفترة: من ${fmtDate(from, fmt)} إلى ${fmtDate(to, fmt)}`;
    const list = D().appts.filter(a => a.date >= from && a.date <= to);
    const paid = list.filter(a => a.payment && a.payment.status === 'paid');
    const completed = list.filter(a => a.status === 'completed').length;

    $('#reportStats').innerHTML = [
        { icon: '📅', label: 'عدد الحجوزات', value: list.length, sub: `${list.filter(a => a.status === 'cancelled').length} ملغاة`, color: '#1463ff' },
        { icon: '✓', label: 'الزيارات المكتملة', value: completed, sub: `${list.length ? Math.round((completed / list.length) * 100) : 0}% من الحجوزات`, color: '#16a34a' },
        { icon: '✕', label: 'لم يحضر', value: list.filter(a => a.status === 'noshow').length, sub: 'مواعيد بدون حضور', color: '#94a3b8' },
        { icon: '💰', label: 'الإيرادات المستلمة', value: paid.reduce((s, a) => s + a.payment.amount, 0), sub: `${paid.length} عملية دفع`, color: '#12b5a5', money: true }
    ].map(statCard).join('');
    animateCounts($('#reportStats'));

    const days = [];
    for (let d = parseISO(from); toISO(d) <= to; d = addDays(d, 1)) days.push(toISO(d));
    let items;
    if (days.length <= 31) {
        items = days.map(iso => {
            const dl = list.filter(a => a.date === iso);
            return { label: fmtDate(iso, { day: 'numeric', month: 'numeric' }), value: dl.length, tip: `${fmtDate(iso, { weekday: 'long', day: 'numeric', month: 'short' })}: ${dl.length} حجز · ${dl.filter(a => a.status === 'completed').length} مكتملة${isHoliday(iso) ? ' · عطلة' : ''}` };
        });
    } else {
        items = [];
        for (let i = 0; i < days.length; i += 7) {
            const chunk = days.slice(i, i + 7);
            const dl = list.filter(a => chunk.includes(a.date));
            items.push({ label: fmtDate(chunk[0], { day: 'numeric', month: 'numeric' }), value: dl.length, tip: `أسبوع ${fmtDate(chunk[0], { day: 'numeric', month: 'short' })}: ${dl.length} حجز · ${dl.filter(a => a.status === 'completed').length} مكتملة` });
        }
    }
    renderBarChart($('#reportChart'), items);

    const pays = list.filter(a => a.payment);
    renderStack($('#payStatusBreak'), Object.entries(PAY_STATUS).map(([k, s]) => {
        const it = pays.filter(a => a.payment.status === k);
        return { label: s.label, icon: s.icon, color: s.color, count: it.length, value: it.reduce((x, a) => x + a.payment.amount, 0) };
    }), true);
    renderHBars($('#methodBreak'), Object.entries(METHODS).map(([k, m]) => {
        const v = paid.filter(a => a.payment.method === k).reduce((s, a) => s + a.payment.amount, 0);
        return { label: m.label, color: m.color, value: v, text: fmtMoney(v) };
    }));

    const rows = perfRows(list);
    $('#perfList').innerHTML = rows.length ? rows.map((r, i) => `
        <tr style="--i:${i}">
            <td><div class="pt-cell"><span class="pt-avatar">${docIcon(r.d)}</span><div><strong>${esc(r.d.name)}</strong><small>${r.d.specialty}${r.link && r.link.status === 'removed' ? ' · سابق' : ''}</small></div></div></td>
            <td><b>${r.total}</b></td>
            <td>${r.completed}</td>
            <td>${r.cancelled}</td>
            <td>${r.noshow}</td>
            <td><div class="rate-bar"><div class="hbar-track"><i style="background:${r.rate >= 80 ? '#16a34a' : r.rate >= 60 ? '#f59e0b' : '#e5484d'}" data-w="${r.rate}"></i></div><b>${r.rate}%</b></div></td>
            <td><b>${fmtMoney(r.revenue)}</b></td>
        </tr>`).join('') : '<tr class="table-empty"><td colspan="7"><div class="empty-state"><div class="empty-icon">📊</div><h3>لا توجد بيانات في هذه الفترة</h3></div></td></tr>';
    requestAnimationFrame(() => requestAnimationFrame(() => {
        $$('#perfList .hbar-track i').forEach(i => { i.style.width = i.dataset.w + '%'; });
    }));
}

function exportReport() {
    const [from, to] = reportRange();
    const list = D().appts.filter(a => a.date >= from && a.date <= to);
    if (!list.length) { toast('لا توجد بيانات للتصدير', 'error'); return; }
    const rows = [['الطبيب', 'الاختصاص', 'الحجوزات', 'المكتملة', 'الملغاة', 'لم يحضر', 'نسبة الإنجاز', 'الإيرادات']];
    perfRows(list).forEach(r => rows.push([r.d.name, r.d.specialty, r.total, r.completed, r.cancelled, r.noshow, r.rate + '%', r.revenue]));
    const csv = '﻿' + rows.map(r => r.map(v => `"${String(v).replace(/"/g, '""')}"`).join(',')).join('\n');
    const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
    const a = document.createElement('a');
    a.href = url; a.download = `تقرير-${CLINIC.name}-${from}-${to}.csv`;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    toast('تم تصدير تقرير أداء الأطباء', 'success');
}


/* =================== الأحداث العامة =================== */
function handleAction(act, id) {
    switch (act) {
        case 'denied': denied(); break;
        case 'account': openAccount(); break;
        case 'doc-view': openDoctorDrawer(id); break;
        case 'doc-schedule': closeDrawer(); go('schedule'); setTimeout(() => {
            const row = $(`[data-cell^="${id}|"]`);
            if (row) { row.closest('tr').scrollIntoView({ behavior: 'smooth', block: 'center' }); $$(`[data-cell^="${id}|"]`).forEach(c => c.classList.add('flash')); }
        }, 400); break;
        case 'doc-fee': can('doctors.manage') ? openFeeModal(id) : denied(); break;
        case 'doc-remove': can('doctors.manage') ? openRemoveModal(id) : denied(); break;
        case 'req-cancel':
            if (!can('doctors.manage')) { denied(); break; }
            confirmDialog({ title: 'إلغاء طلب الانضمام؟', text: `سيتم سحب الطلب المرسل إلى ${docInfo(id).name}.`, ok: 'إلغاء الطلب', danger: true, icon: '📨' })
                .then(ok => {
                    if (!ok) return;
                    const l = getLink(id);
                    l.status = 'cancelled'; l.respondedAt = Date.now(); l.note = 'سحبت العيادة الطلب';
                    saveData(); renderDoctors(); updateBadges();
                    toast('تم إلغاء الطلب', 'success');
                });
            break;
        case 'req-resend': can('doctors.manage') ? openAddDoctor(id) : denied(); break;
    }
}

document.addEventListener('click', e => {
    const inModal = e.target.closest('#modal');

    const pg = e.target.closest('[data-pg]');
    if (pg && !pg.disabled) { state.pages[pg.dataset.pg] = Number(pg.dataset.to); renderApptTable(); return; }

    const nav = e.target.closest('a[data-page], [data-go]');
    if (nav) {
        e.preventDefault();
        if (inModal) closeModal();
        closeDrawer();
        go(nav.dataset.page || nav.dataset.go);
        return;
    }

    const act = e.target.closest('[data-act]');
    if (act && !act.disabled) {
        if (inModal) closeModal();
        handleAction(act.dataset.act, act.dataset.id);
    }
});

document.addEventListener('pointerdown', e => {
    const b = e.target.closest('.btn');
    if (!b || b.disabled) return;
    const r = b.getBoundingClientRect();
    const size = Math.max(r.width, r.height);
    const s = document.createElement('span');
    s.className = 'ripple';
    s.style.width = s.style.height = size + 'px';
    s.style.left = (e.clientX - r.left - size / 2) + 'px';
    s.style.top = (e.clientY - r.top - size / 2) + 'px';
    b.appendChild(s);
    setTimeout(() => s.remove(), 650);
});

function bindApp() {
    const modal = $('#modal');
    modal.addEventListener('click', e => {
        if (e.target === modal || e.target.closest('[data-close-modal]')) { closeModal(); return; }
        const c = e.target.closest('[data-confirm]');
        if (c && modalResolver) {
            const r = modalResolver;
            modalResolver = null;
            closeModal();
            r(c.dataset.confirm === 'yes');
        }
        const pick = e.target.closest('[data-pick]');
        if (pick) {
            $$('.dir-item', modal).forEach(x => x.classList.toggle('selected', x === pick));
            const input = $('input[name=doctor]', modal);
            input.value = pick.dataset.pick;
            setError(input, '');
        }
        const fee = e.target.closest('[data-fee]');
        if (fee) { const i = $('input[name=fee]', modal); i.value = fee.dataset.fee; setError(i, ''); }
        if (e.target.closest('#modalLogout')) { closeModal(); setTimeout(logout, 300); }
    });
    $('#modalBody').addEventListener('submit', e => {
        e.preventDefault();
        const id = e.target.id;
        if (id === 'addDocForm') submitAddDoctor(e.target);
        if (id === 'feeForm') submitFee(e.target);
        if (id === 'removeForm') submitRemove(e.target);
        if (id === 'shiftForm') submitShift(e.target);
    });
    $('#modalBody').addEventListener('input', e => {
        if (e.target.id === 'dirSearch') {
            const q = normalize(e.target.value.trim());
            $$('.dir-item').forEach(x => { x.hidden = q && !x.dataset.search.includes(q); });
            return;
        }
        const g = e.target.closest('.form-group.has-error');
        if (g) setError(e.target.closest('.day-pick') || e.target, '');
    });
    $('#modalBody').addEventListener('change', e => {
        if (e.target.name === 'reason') setError($('.reason-list'), '');
        if (e.target.name === 'days') setError($('.day-pick'), '');
        if (e.target.name === 'ack') setError(e.target, '');
        if (e.target.name === 'works') $('#shiftTimes').style.opacity = e.target.checked ? 1 : .4;
    });

    $('#drawer').addEventListener('click', e => {
        if (e.target === $('#drawer') || e.target.closest('[data-close-drawer]')) closeDrawer();
    });

    $('#menuToggle').addEventListener('click', () => document.body.classList.toggle('sidebar-open'));
    $('#sidebarOverlay').addEventListener('click', () => document.body.classList.remove('sidebar-open'));
    $('#profileChip').addEventListener('click', openAccount);

    $('#notifBtn').addEventListener('click', e => {
        e.stopPropagation();
        const panel = $('#notifPanel');
        panel.classList.toggle('open');
        if (panel.classList.contains('open')) {
            setTimeout(() => { D().notifs.forEach(n => { n.unread = false; }); saveData(); $('#notifCount').hidden = true; }, 1200);
        } else renderNotifs();
    });
    $('#clearNotifs').addEventListener('click', () => { D().notifs = []; saveData(); renderNotifs(); });
    document.addEventListener('click', e => {
        if (!e.target.closest('.notif-wrap') && $('#notifPanel').classList.contains('open')) {
            $('#notifPanel').classList.remove('open');
            renderNotifs();
        }
    });

    $('#paySeg').addEventListener('click', e => {
        const b = e.target.closest('[data-range]');
        if (!b) return;
        state.payRange = b.dataset.range;
        $$('#paySeg button').forEach(x => x.classList.toggle('active', x === b));
        renderPaySummary();
    });

    $('#logoutBtn').addEventListener('click', logout);
    $('#resetData').addEventListener('click', async () => {
        const ok = await confirmDialog({ title: 'إعادة ضبط البيانات؟', text: 'سيتم حذف جميع التغييرات وإعادة إنشاء البيانات التجريبية.', ok: 'إعادة الضبط', danger: true, icon: '↺' });
        if (!ok) return;
        state.timers.forEach(clearTimeout);
        state.timers = [];
        state.data = CLINIC.reqId ? generateEmptyData(state.session) : generateData();
        state.hoursDraft = null;
        saveData();
        renderNotifs();
        renderPage();
        toast('تمت إعادة ضبط البيانات التجريبية', 'success');
    });

    window.addEventListener('scroll', () => $('#topbar').classList.toggle('scrolled', window.scrollY > 8), { passive: true });
    window.addEventListener('resize', moveIndicator);
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(moveIndicator);

    document.addEventListener('keydown', e => {
        if (e.key !== 'Escape') return;
        if ($('#modal').classList.contains('open')) closeModal();
        else if ($('#drawer').classList.contains('open')) closeDrawer();
        else { $('#notifPanel').classList.remove('open'); document.body.classList.remove('sidebar-open'); }
    });

    bindDoctors();
    bindAppointments();
    bindSchedule();
    bindReports();
    bindChartTips();
}


/* =================== التشغيل =================== */
let secCounter = 0;
function tick() {
    $('#liveClock').textContent = new Intl.DateTimeFormat('ar-u-nu-latn', { hour: '2-digit', minute: '2-digit', second: '2-digit' }).format(new Date());
    if (!state.session) return;
    secCounter++;
    if ($('#simToggle').checked) {
        if (secCounter % 12 === 0) tickQueues();
        if (secCounter % 35 === 0) simulateBooking();
    }
    if (secCounter % 5 === 0 && state.page === 'queue') $('#queueUpdated').textContent = `آخر تحديث: ${timeAgo(state.lastQueueUpdate)}`;
}

function init() {
    bindLogin();
    bindApp();
    const s = rawGet('scClinic_session') || rawGet('scClinic_session', sessionStorage);
    let ok = false;
    if (s && ACCOUNTS[s.email]) ok = true;
    else if (s && s.reqId) {
        // جلسة عيادة مسجّلة: نتأكد أن الحساب ما زال مفعّلاً من الإدارة
        const req = (rawGet('smartClinic_clinicRequests') || []).find(r => r.reqId === s.reqId);
        ok = !!req && !registeredStatus(req).msg;
        if (!ok) rawDel('scClinic_session');
    }
    if (ok) enterApp(s);
    else showLogin();
    setInterval(tick, 1000);
    tick();
    window.__clinicBooted = true;
}

function hideLoader() {
    if (!window.__clinicBooted) return; // إبقاء رسالة الخطأ ظاهرة إن فشل التشغيل
    const l = $('#pageLoader');
    if (l) l.classList.add('hide');
    moveIndicator();
}
window.addEventListener('load', () => setTimeout(hideLoader, 300));
setTimeout(hideLoader, 2500);

init();
hideLoader();
